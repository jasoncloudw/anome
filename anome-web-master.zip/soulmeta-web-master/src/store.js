import { createStore } from 'vuex'
import axios from 'axios'
export default createStore({
    state () {
        return {
            soon: false,
            waitBuyPage: false,
            waitCastingPage: false,
            waitBatchCastingPage: false,
            invitor: '',
            signMessage: '', // 签名
            boxType: 0,
            casteInfo: {
                type: 0,
                img: '',
                contInfo: '',
                soulNum: 1,
                linkType: 0,
                casteNum: 0,
                file: null
            },
            soulmetaList: [],
            monsterList: [],
            fishList: [],
            myAddr: '',
            chainId: '',
            walletType: 'eth',
            lastChange: 0,
            rabbitCardMap: {}
        }
    },
    mutations: {
        setSoon (state, soon) {
            state.soon = soon
        },
        setWaitBuyPage (state, wait) {
            state.waitBuyPage = wait
        },
        setWaitCastingPage (state, wait) {
            state.waitCastingPage = wait
        },
        BATCH_CASTRING_PAGE (state, wait) {
            state.waitBatchCastingPage = wait
        },
        setCasteInfo (state, info) {
            state.casteInfo = info
        },
        setBoxType (state, type) {
            state.boxType = type
        },
        setInvitor (state, addr) {
            state.invitor = addr
        },
        setSignMessage (state, id) {
            state.signMessage = id
        },
        setSoulmetaList(state, souls) {
            state.soulmetaList = souls
        },
        setMonsterList(state, kaka) {
            state.monsterList = kaka
        },
        setFishList(state, fish) {
            state.fishList = fish
        },

        setWallet (state, { myAddr, chainId, lastChange }) {
            state.myAddr = myAddr
            state.chainId = chainId
            state.lastChange = lastChange
        },
        setWalletType (state, walletType) {
            state.walletType = walletType
        },
        setRabbitCardMap (state, cardMap) {
            state.rabbitCardMap = cardMap
        }
    },
    actions: {
        async initEther ({ dispatch, commit, state }) {
            if (!window.ethereum && window.BinanceChain) {
                window.ethereum = window.BinanceChain
            }
            let curAddr = window.ethereum.selectedAddress || window.ethereum.address || ''
            try {
                const flag = window.ethereum && (
                    (curAddr.toLowerCase() !== state.myAddr.toLowerCase())
                    || (window.ethereum.chainId !== state.chainId)
                )
                if (flag) {
                    const lastChange = new Date().getTime()
                    commit('setWallet', {
                        myAddr: curAddr,
                        chainId: window.ethereum.chainId,
                        lastChange: lastChange
                    })
                }
            } catch (e) {
                console.log(e)
            }
            setTimeout(() => {
                dispatch('initEther')
            }, 2000)
        },
        async fetchCardList ({ state, commit }) {
            let link = ''
            const chainId = window.ethereum && +window.ethereum.chainId
            if (chainId === 97) {
                link = 'https://test.kakausa.io'
            } else {
                link = 'https://kakausa.io'
            }
            let res = await axios.get(link + '/api/special-cards?limit=1000')
            if (!res.data.code) {
                const rabbitCardMap = {}
                res.data.data.list.forEach(item => {
                    if (item.card_id === 110001) {
                        rabbitCardMap[item.card_no] = item
                    }
                })
                commit('setRabbitCardMap', rabbitCardMap)
            }
        }
    }
})
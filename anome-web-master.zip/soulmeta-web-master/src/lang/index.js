import en from './en'
import cn from './cn'
import jp from './jp'
import kr from './kr'
import es from './es'
import vl from './vl'
import lt from './lt'
import pt from './pt'
import ptBr from './pt'


export default {
  en,
  cn,
  jp,
  kr,
  es,
  vl,
  lt,
  pt,
  ptBr
}

import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: '/',
            name: 'home',
            component: () => import('./view/home.vue')
        },
        {
            path: '/mint',
            name: 'mint',
            component: () => import('./view/mint.vue')
        },
        {
            path: '/account',
            name: 'account',
            component: () => import('./view/account.vue')
        },
        {
            path: '/nft-detail',
            name: 'nftDetail',
            component: () => import('./view/nft-detail.vue')
        },
        {
            path: '/success-page',
            name: 'successPage',
            component: () => import('./view/success-page.vue')
        },
        {
            path: '/casting',
            name: 'casting',
            component: () => import('./view/casting.vue')
        }
        ,
        {
            path: '/frog-clan',
            name: 'frog',
            component: () => import('./view/frog-clan.vue')
        },
        {
            path: '/frog-comm-dtl',
            name: 'frog-comm-dtl',
            component: () => import('./view/frog-comm-dtl.vue')
        },
        {
            path: '/advert',
            name: 'advert',
            component: () => import('./view/advert.vue')
        },
        {
            path: '/game-plaza',
            name: 'game-plaza',
            component: () => import('./view/game-plaza.vue')
        },
        {
            path: '/nft-marketplace',
            name: 'nft-marketplace',
            redirect:'/nft-marketplace/summonBeast',
            component: () => import('./view/nft-marketplace.vue'),
            children:[
                {
                    path: 'summonBeast',
                    name: 'summonBeast',
                    component: () => import('./view/summon-beast.vue'),
                },
                {
                    path: 'nft-mall',
                    name: 'nft-mall',
                    component: () => import('./view/nft-mall.vue'),
                }
                
            ]
        },
        {
            path: '/mall-product-detail/:id',
            name: 'mall-product-detail',
            component: () => import('./view/mall-product-detail.vue')
        },
        {
            path: '/crypotd-frog',
            name: 'crypotd-frog',
            component: () => import('./view/crypotd-frog.vue')
        },
        {
            path: '/guide',
            name: 'guide',
            component: () => import('./view/guide.vue')
        },
        {
            path: '/games-lobby',
            name: 'games-lobby',
            component: () => import('./view/airdrop-plaza.vue')
        },        
        {
            path: '/fightpage',
            name: 'fightpage',
            component: () => import('./view/fightpage.vue')
        },  
        {
            path: '/nftFight',
            name: 'nft-fight',
            component: () => import('./view/nft-fight.vue')
        },        
        {
            path: '/batch-success-page/:quantity',
            name: 'batch-success-page',
            component: () => import('./view/batch-success-page.vue')
        },
        {
            path: '/customizationNFT',
            name: 'customizationNFT',
            component: () => import('./view/customizationNFT.vue')
        }, 
        {       
            path: '/time-bank',
            name: 'time-bank',
            component: () => import('./view/time-bank.vue')
        },
        {
            path: '/hunters-guild',
            name: 'hunters-guild',
            component: () => import('./view/games/hunters-guild.vue')
        },
        {
            path: '/2dnft-fight',
            name: '2dnft-fight',
            component: () => import('./view/games/2dnft-fight.vue')
        },
        {
            path: '/chaebol',
            name: 'chaebol',
            component: () => import('./view/chaebol.vue')
        },
        {
            path: '/404',
            name: 'NotFound',
            component: () => import('@/view/error.vue')
        },
        {
            path: '/:pathMatch(.*)',
            redirect: '/404'
        }
        
    ]
})

export default router

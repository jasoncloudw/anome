<template>
  <header class="header lg:w-200 xl:w-300 w-9/10 mx-auto">
    <div class="hidden lg:flex items-center justify-between">
      <router-link to="/"><img class="h-14" src="https://static.soulmeta.io/web/img/home/logo.webp" alt="" /></router-link>
      <div class="w-4/5 flex items-center justify-between">
        <div v-for="(nav, index) in navList" :key="nav.name" class="py-6 mx-2 text-xl cursor-pointer" :class="{ hidden: index === 0 || index === 1 }">
          <div class="w-full relative menu-item h-20 flex items-center" @click="toLink(nav)">
            {{ nav.name }}
            <div class="menu-item-child absolute z-99 top-20 left-1/2 -translate-x-1/2 bg-[#242424] rounded-sm" :class="[nav.childs.length ? 'is-active' : '']">
              <div
                class="flex items-center border-b border-[#505050]"
                v-for="(child, i) in nav.childs"
                :key="child.path"
                :to="child.path"
                :class="{ 'border-b-0': i === nav.childs.length - 1 }"
                @click="toLink(child)"
              >
                {{ child.name }}
              </div>
            </div>
          </div>
          <div :class="[{ actived: nav.path === $route.path }]"></div>
        </div>
      </div>
      <img v-if="!myAddr" class="w-7" src="https://static.soulmeta.io/web/img/home/user.webp" alt="" />
      <router-link to="/account" v-else class="text-xl">{{ myAddr }}</router-link>
    </div>

    <div class="py-5 flex lg:hidden justify-center items-center relative">
      <div class="w-full flex items-center justify-center">
        <img class="h-7 sm:h-10 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
        <!-- <img class="h-3" src="https://static.soulmeta.io/web/img/home/heder_til.webp" alt=""> -->
        <div class="font-semibold sm:text-xl">SOULMETA</div>
      </div>

      <img
        class="w-7 sm:w-10 absolute top-1/2 -translate-y-2/4 right-0"
        src="https://static.soulmeta.io/web/img/home/heder_icon.webp"
        alt=""
        @click="mobile = true"
      />
    </div>

    <div v-if="mobile && lang" class="nav-bg w-full h-full overflow-y-auto fixed top-0 left-0 z-999 bg-244">
      <div>
        <div class="m-5 flex items-center">
          <img class="w-3" src="https://static.soulmeta.io/web/img/home/return_icon.webp" alt="" @click="mobile = false" />
          <div class="w-full pr-7">
            <div class="w-full flex items-center justify-center">
              <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
              <div class="font-semibold sm:text-xl">SOULMETA</div>
            </div>
          </div>
        </div>
        <img src="https://static.soulmeta.io/web/img/header/mobile/banner.webp" alt="" />
      </div>
      <div class="border-black border-t border-2 rounded-3xl relative -top-6 bg-black">
        <div class="w-9/10 mx-auto py-2">
          <div v-for="nav in navList" :key="nav.name">
            <div class="m-menu-item" @click="toLink(nav)">
              <div
                class="w-full flex items-center justify-between relative z-99 bg-white mt-7 rounded-xl cursor-pointer py-2 px-5 box-border"
                :class="[nav.showChilds ? 'item-is-active' : '']"
              >
                <span class="text-black">{{ nav.name }}</span>
                <div class="w-auto h-14 absolute bottom-0 right-0">
                  <img class="w-auto h-full" :src="'https://static.soulmeta.io/web/img/header/mobile/nav' + nav.id + '.webp'" alt="" />
                  <img
                    v-if="nav.childs.length"
                    class="w-4 h-auto absolute left-1/3 bottom-4"
                    src="https://static.soulmeta.io/web/img/header/mobile/r-w-arrow.webp"
                    alt=""
                  />
                </div>
              </div>
              <div class="m-menu-item-child w-full bg-white rounded-sm" :class="[nav.showChilds ? 'is-active' : '']">
                <div class="flex items-center justify-between" v-for="child in nav.childs" :key="child.path">
                  <div class="text-black" @click="toLink(child)">
                    {{ child.name }}
                  </div>
                </div>
                <i class=""></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: "Header",
  inject: ["reload"],
  data() {
    return {
      daoShow: false,
      mobile: false,
      navList: [],
      isShowLangSel: false,
      langImg: "cn_icon",
      expandNavbar: false,
    };
  },
  computed: {
    myAddr() {
      let str;
      if (this && this.$store.state.myAddr) {
        str = this.$store.state.myAddr;
        str = str.substring(0, 4) + ".." + str.substring(str.length - 4);
      } else {
        str = "WALLET";
      }
      return str;
    },
    lang() {
      return this.$i18n.locale;
    },
  },
  watch: {
    "$i18n.locale"(lang) {
      this.initNav();
    },
    myAddr(address) {
      this.reload();
    },
  },
  methods: {
    toLink(nav) {
      if (this.mobile && nav.childs.length) {
        this.navList.forEach((item, index, self) => {
          if (nav.id === item.id) {
            self[index].showChilds = !self[index].showChilds;
          }
        });
        return;
      }
      if (!this.mobile && nav.childs.length) return;
      if (!nav.path && !nav.isTarget) {
        this.$store.commit("setSoon", true);
        return;
      }
      if (nav.isTarget) {
        window.open(nav.path, true);
      } else {
        this.$router.push(nav.path);
      }
      this.mobile = false;
    },
    changeLange(type) {
      this.langImg = type;
      this.isShowLangSel = false;
    },
    initNav() {
      let enList = ['cn', 'es', 'vl', 'lt'];

      this.navList = [
        {
          id: 2,
          path: "/account",
          name: this.$t("navbar.nav2"),
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 1,
          path: "/",
          name: this.$t("navbar.nav1"),
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 3,
          path: "/nft-marketplace",
          name: this.$t("navbar.nav3"),
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 4,
          path: "/advert",
          name: this.$t("navbar.nav4"),
          // path: "/airdrop-plaza",
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 5,
          path: "/frog-clan",
          name: this.$t("navbar.nav5"),
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 6,
          path: "",
          name: this.$t("navbar.nav6"),
          isTarget: false,
          showChilds: false,
          childs: [
            {
              path: "/games-lobby",
              name: this.$t("navbar.nav13"),
              isTarget: false,
              showChilds: false,
              childs: [],
            },
            {
              path: "/game-plaza",
              name: this.$t("navbar.nav12"),
              isTarget: false,
              showChilds: false,
              childs: [],
            },
            {
              path: "/hunters-guild",
              name: this.$t("navbar.nav14"),
              isTarget: false,
              showChilds: false,
              childs: [],
            },
            {
              path: "/2dnft-fight", //https://2dnft.soulmeta.io/
              name: this.$t("navbar.nav15"),
              isTarget: false,
              showChilds: false,
              childs: [],
            }
            
          ],
        },
        {
          id: 7,
          path: "/chaebol",
          name: "CryptoD.Frog",
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 9,
          path: "/time-bank",
          name: this.$t("navbar.nav7"),
          isTarget: false,
          showChilds: false,
          childs: [],
        },
        {
          id: 8,
          path: "",
          name: this.$t("navbar.nav8"),
          isTarget: false,
          showChilds: false,
          childs: [
            {
              path: "https://static.soulmeta.io/web/other/soulmeta_whitepaper_m_" + (enList.includes(this.$i18n.locale) ? "en" : this.$i18n.locale) + ".pdf",
              name: this.$t("navbar.nav8-1"),
              isTarget: true,
              showChilds: false,
              childs: [],
            },
            {
              path: "https://static.soulmeta.io/web/other/soulmeta_audit_soul_token.pdf",
              name: this.$t("navbar.nav8-2"),
              isTarget: true,
              showChilds: false,
              childs: [],
            },
            {
              path: "/guide",
              name: this.$t("navbar.nav8-3"),
              isTarget: false,
              showChilds: false,
              childs: [],
            },
          ],
        },
      ];
    },
  },
  created() {
    this.initNav();
  },
};
</script>

<style scoped lang="scss">
.actived {
  position: relative;
}
.actived::after {
  content: "";
  width: 100px;
  height: 3px;
  display: block;
  position: absolute;
  left: 0;
  bottom: 0;
  background-color: #f1213b;
  border-radius: 2px;
}

.header {
  .header-fiexd {
    z-index: 999;
  }
}
.nav-bg {
  background: #000;
}

.arrow-right {
  content: "";
  height: 12px;
  width: 12px;
  border-color: #000;
  border-style: solid;
  border-width: 2px 2px 0 0;
  transform: rotate(45deg);
}

.arrow-bottom {
  content: "";
  height: 12px;
  width: 12px;
  border-color: #000;
  border-style: solid;
  border-width: 2px 2px 0 0;
  transform: rotate(135deg);
}

.menu-item-child {
  display: none;
}

.menu-item {
  &:hover {
    color: #ffffff;

    .menu-item-child {
      display: block;
      > div {
        min-width: 220px;
        height: 40px;
        padding: 20px 16px;
        display: flex;
        align-items: center;
        line-height: 1;
      }
      > div:hover {
        background-color: #fff;
        color: #000;
        opacity: 0.2;
      }
    }
    .is-active {
      padding: 10px 0;
    }
  }
}

.m-menu-item-child {
  display: none;
}

.m-menu-item {
  .item-is-active {
    box-shadow: 0px 6px 14px 0px rgba(0, 0, 0, 0.2);
  }
  .m-menu-item-child {
    border-bottom-left-radius: 14px;
    border-bottom-right-radius: 14px;
    padding: 20px 20px;
    > div {
      height: 40px;
    }
    i {
      display: block;
      width: 0;
      height: 0;
      border-left: 10px solid transparent;
      border-right: 10px solid transparent;
      border-top: 0;
      border-bottom: 10px solid black;
      border-radius: 2px;
      margin: 0 auto;
    }
  }
  .is-active {
    display: block;
    margin-top: -10px;
    padding-top: 24px;
  }
}
</style>

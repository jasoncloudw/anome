<template>
    <div class="p-3 px-5 rounded-xl xl:text-xl font-bold z-999 md:text-lg fixed top-20 left-1/2 transform -translate-x-1/2 text-F9F bg-orange bg-opacity-70">
        Coming Soon...
    </div>
</template>

<script>
    export default {
        name: 'ComingSoon',
        data() {
            return {
                timer: null
            }
        },
        mounted () {
            this.timer = setInterval(() => {
                if (this.$store.state.soon) {
                    this.$store.commit('setSoon', false)
                    clearInterval(this.timer)
                }
            }, 2000)
        },
    }
</script>

<style lang="scss" scoped>
</style>

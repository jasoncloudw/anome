<template>
	<div v-if="$i18n.locale" class="mintPage w-full h-full fixed top-0 left-0 z-100 bg-black">
		<div class="w-9/10 mx-auto">
			<h2 class="text-center text-2xl md:text-3xl font-semibold py-10 md:mt-20">{{ $t('caste.cas10') }}...</h2>
			<p v-if="$i18n.locale" class="text-sm md:text-xl text-center whitespace-pre-wrap">
				{{ $t('caste.cas11') + userInfo.casteNum + $t('caste.cas12') + userInfo.casteNum + $t('caste.cas13') }}
			</p>
			<div class="text-center pt-10 md:p-0 flex justify-center">
				<img class="w-72 md:w-124 h-72 md:h-auto" src="https://static.soulmeta.io/web/img/home/waitImg2.gif" />
			</div>
		</div>
	</div>
</template>
<script>
export default {
	name: "pay",
	data() {
		return {
			timer: null,
			userInfo: {}
		}
	},
	computed: {
		lang () {
			return this.$i18n.locale
		}
	},
	mounted() {
		this.userInfo = this.$store.state.casteInfo
	},
}
</script>

<style scoped lang="scss">
.mintPage {
	background: #000;
}
</style>

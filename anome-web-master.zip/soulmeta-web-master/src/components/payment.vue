<template>
  <div
    v-if="$i18n.locale"
    class="mintPage w-full h-full fixed top-0 left-0 z-100 bg-black"
  >
    <div class="w-9/10 mx-auto">
      <h2 class="text-center text-2xl md:text-3xl font-semibold py-10 md:mt-20">
        {{ $t("box.box1") }}...
      </h2>
      <p class="text-sm md:text-xl text-center whitespace-pre-wrap">
        {{ $t("box.box2") }}
      </p>
      <div class="text-center pt-10 md:p-0 flex justify-center">
        <img
          class="w-72 md:w-124 h-72 md:h-auto"
          src="https://static.soulmeta.io/web/img/home/waitImg.gif"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "payment",
  data() {
    return {
      timer: null,
    };
  },
  computed: {
    lang() {
      return this.$i18n.locale;
    },
  },
  mounted() {},
};
</script>

<style scoped lang='scss'>
.mintPage {
  background: black;
}
</style>
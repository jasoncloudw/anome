<template>
  <div class="mintPage w-full h-full fixed top-0 left-0 z-100 bg-black">
    <div class="w-10/12 md:w-1/3 mx-auto">
      <h2 class="text-center text-2xl md:text-3xl font-semibold mt-14 md:mt-20 text-F02">{{ $t("box.box3") }}...</h2>
      <div class="text-center flex justify-center">
        <img class="w-full md:w-124" src="https://static.soulmeta.io/web/img/home/batch-of-blind-box-wait.gif" />
      </div>
      <p class="text-sm md:text-xl text-left whitespace-pre-wrap mt-4">
        {{ $t("box.box4") }}
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "batch-payment",
  data() {
    return {};
  },
  computed: {},
  mounted() {},
};
</script>

<style scoped lang="scss">
.mintPage {
  background: black;
}
</style>

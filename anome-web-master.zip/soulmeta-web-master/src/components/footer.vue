<template>
  <div class="">
    <div class="lg:w-200 xl:w-300 w-9/10 mx-auto pt-10 md:pt-20 pb-20">
      <div class="">
        <div v-if="lang" class="w-full font-semibold text-center md:text-3xl">
          {{ $t("fter.fter1") }}
        </div>
        <img class="mb-5 md:mb-6 md:mt-2.5 w-full" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />
        <div class="grid grid-cols-4 md:grid-cols-6 xl:grid-cols-7 gap-4 xl:gap-8">
          <div v-for="item in partnerList" :key="item.key" class="rounded-full">
            <a :href="item.href" target="blank">
              <img class="w-full h-auto rounded-lg" :src="'https://static.soulmeta.io/web/img/home/partner' + item.key + '.webp'" alt="" />
            </a>
          </div>
        </div>
      </div>
      <div class="mt-3 md:mt-20">
        <div class="w-full font-semibold text-center md:text-3xl">
          {{ $t("fter.fter2") }}
        </div>
        <img class="mb-5 md:mb-9 md:mt-2.5 w-full" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />
        <div class="flex flex-wrap justify-around">
          <div v-for="item in gamList" :key="item.key" class="w-8 sm:w-12 xl:w-16 mb-3 rounded-full">
            <a :href="item.href" target="blank">
              <img class="w-full sm:w-12 xl:w-16 rounded-lg" :src="'https://static.soulmeta.io/web/img/home/link' + item.key + '.webp'" alt="" />
            </a>
          </div>
          <div class="w-8 sm:w-12 xl:w-16 mb-3 rounded-full">
            <a href="https://www.youtube.com/channel/UCBl7T4-WQvfyFETeORfZJZA" target="blank">
              <img class="w-full rounded-lg" :src="'https://static.soulmeta.io/web/img/home/link' + 5 + '.webp'" alt="" />
            </a>
          </div>
          <div class="w-8 sm:w-12 xl:w-16 mb-3 rounded-full">
            <a href="https://medium.com/@soulmeta" target="blank">
              <img class="w-full rounded-lg" :src="'https://static.soulmeta.io/web/img/home/link' + 6 + '.webp'" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "footer-v2",
  data() {
    return {
      partnerList: [
        // { key: 1, href: 'https://daomaker.com/' },
        { key: 2, href: "https://www.binance.com/en/nft/home" },
        { key: 4, href: "https://dodoex.io/zh/en" },
        { key: 6, href: "https://www.tokenpocket.pro/" },
        // { key: 7, href: 'https://coin98.com/wallet' },
        { key: 8, href: "https://bitkeep.com/" },
        { key: 12, href: "https://pancakeswap.finance/" },
        { key: 3, href: "https://au21.capital/" },
        // { key: 5, href: "https://hoo.com/" },
        { key: 10, href: "https://chain.link/" },
        { key: 13, href: "https://www.hyperpay.me/" },
        { key: 9, href: 'https://www.polygon.com/' },
        { key: 11, href: 'https://www.cube.network' },
        { key: 14, href: 'https://bit.store/' },
        { key: 15, href: 'https://encentive.io/' },
        { key: 16, href: 'https://onto.app/' },
        { key: 17, href: 'http://seektiger.com/' },
        { key: 18, href: 'https://www.sinso.io' },
        { key: 19, href: 'https://www.bibox.com' },
        { key: 20, href: 'https://apenft.io/' },
        { key: 21, href: 'https://tron.network/' },
        { key: 22, href: 'https://en.plugchain.info/' },
      ],

      gamList: [
        { key: 1, href: "https://t.me/soulmeta" },
        { key: 2, href: "https://twitter.com/SOULMETAVERSE" },
        { key: 3, href: "https://www.facebook.com" },
        { key: 4, href: "https://discord.gg/soulmeta" },
      ],
    };
  },
  computed: {
    lang() {
      return this.$i18n.locale;
    },
  },
  methods: {},
};
</script>

<style lang="scss" scoped></style>

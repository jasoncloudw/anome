var unityInstance2 = null;
export function canvas_3dnft_html() {
    var container = document.querySelector("#unity-container");
    var canvas = document.querySelector("#unity-canvas");
    var loadingBar = document.querySelector("#unity-loading-bar");
    var progressBarFull = document.querySelector("#unity-progress-bar-full");
    var fullscreenButton = document.querySelector("#unity-fullscreen-button");
    var warningBanner = document.querySelector("#unity-warning");
  
    // Shows a temporary message banner/ribbon for a few seconds, or
    // a permanent error message on top of the canvas if type=='error'.
    // If type=='warning', a yellow highlight color is used.
    // Modify or remove this function to customize the visually presented
    // way that non-critical warnings and error messages are presented to the
    // user.
    function unityShowBanner(msg, type) {
      function updateBannerVisibility() {
        warningBanner.style.display = warningBanner.children.length ? "block" : "none";
      }
      var div = document.createElement("div");
      div.innerHTML = msg;
      warningBanner.appendChild(div);
      if (type == "error") div.style = "background: red; padding: 10px;";
      else {
        if (type == "warning") div.style = "background: yellow; padding: 10px;";
        setTimeout(function () {
          warningBanner.removeChild(div);
          updateBannerVisibility();
        }, 5000);
      }
      updateBannerVisibility();
    }
  
    var buildUrl = "https://static.soulmeta.io/web/3dnft-web/Build";
    var loaderUrl = buildUrl + "/FinalBuild.loader.js";
    var config = {
      dataUrl: buildUrl + "/FinalBuild.data.unityweb",
      frameworkUrl: buildUrl + "/FinalBuild.framework.js.unityweb",
      codeUrl: buildUrl + "/FinalBuild.wasm.unityweb",
      streamingAssetsUrl: "StreamingAssets",
      companyName: "SoulMeta",
      productName: "3DNFT",
      productVersion: "0.1",
      showBanner: unityShowBanner,
    };
  
    // By default Unity keeps WebGL canvas render target size matched with
    // the DOM size of the canvas element (scaled by window.devicePixelRatio)
    // Set this to false if you want to decouple this synchronization from
    // happening inside the engine, and you would instead like to size up
    // the canvas DOM size and WebGL render target sizes yourself.
    // config.matchWebGLToCanvasSize = false;
  
    if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
      container.className = "unity-mobile";
      // Avoid draining fillrate performance on mobile devices,
      // and default/override low DPI mode on mobile browsers.
      config.devicePixelRatio = 1;
    } else {
      canvas.style.width = "100%";
      canvas.style.height = "100%";
    }
  
    var script = document.createElement("script");
    script.src = loaderUrl;
    script.onload = () => {
      createUnityInstance(canvas, config, (progress) => {
        progressBarFull.style.width = 100 * progress + "%";
      })
        .then((unityInstance) => {
          loadingBar.style.display = "none";
          fullscreenButton.onclick = () => {
            unityInstance.SetFullscreen(1);
          };
          if (/Android/i.test(navigator.userAgent)) {
            unityInstance.SendMessage("Manager", "LoadTheScene", "1");
          } else if (/iPhone/i.test(navigator.userAgent)) {
            unityInstance.SendMessage("Manager", "LoadTheScene", "1");
          } else {
            unityInstance.SendMessage("Manager", "LoadTheScene", "0");
          }
          unityInstance2 = unityInstance
        })
        .catch((message) => {
          alert(message);
        });
    };
    document.body.appendChild(script);
  
    loadingBar.style.display = "block";
}


export function close_3dnft_html() {
  return unityInstance2
}
 
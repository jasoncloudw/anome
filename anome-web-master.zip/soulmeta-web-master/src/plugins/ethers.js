import { ethers } from 'ethers'
import { prodAddrs, testAddrs, abi } from '../contracts/abi'
export async function getEther(env = 'prod') {
    let provider
    let myAddr
    if (window.BinanceChain) {
        provider = new ethers.providers.Web3Provider(window.BinanceChain)
        await window.BinanceChain.enable()
    } else if (window.ethereum) {
        provider = new ethers.providers.Web3Provider(window.ethereum)
        await window.ethereum.enable()
        myAddr = window.ethereum.address
    } else {
        return null
    }
    const signer = provider.getSigner()
    const rpcProvider = new ethers.providers.JsonRpcProvider('https://data-seed-prebsc-1-s1.binance.org:8545/')

    let envAddrs = ''
    let myGasPrice = null
    let network = {
        '56': {
            envAddrs: prodAddrs,
            myGasPrice: ethers.utils.parseUnits('5.001', 9)
        },
        '97': {
            envAddrs: testAddrs,
            myGasPrice: ethers.utils.parseUnits('10.001', 9)
        },
        // '66': {
        //     envAddrs: oktAddrs,
        //     myGasPrice: ethers.utils.parseUnits('5.001', 9)
        // },
        // '65': {
        //     envAddrs: oktTestAddrs,
        //     myGasPrice: ethers.utils.parseUnits('10.001', 9)
        // },
        // '1': {
        //     envAddrs: ethProdAddrs,
        //     myGasPrice: null
        // }
    }
    const chainId = +window.ethereum.chainId || '56'
    envAddrs = network[chainId].envAddrs
    myGasPrice = network[chainId].myGasPrice

    const MyContracts = {
        soul: new ethers.Contract(envAddrs.soul, abi.soulAbi, signer),
        soul1155: new ethers.Contract(envAddrs.soul1155, abi.soul1155Abi, signer),
        soul721: new ethers.Contract(envAddrs.soul721, abi.soul721Abi, signer),
        usdt: new ethers.Contract(envAddrs.usdt, abi.usdtAbi, signer),
        caste: new ethers.Contract(envAddrs.caste, abi.casteAbi, signer),
        fishNft: new ethers.Contract(envAddrs.fishNft721, abi.erc721Abi, signer),
        rbaNft: new ethers.Contract(envAddrs.rba721, abi.erc721Abi, signer),
        rabbit: new ethers.Contract(envAddrs.rabbit, abi.erc721Abi, signer),
        pond: new ethers.Contract(envAddrs.pond, abi.pondAbi, signer),
        medal: new ethers.Contract(envAddrs.medal, abi.pondAbi, signer),
        team: new ethers.Contract(envAddrs.team, abi.teamAbi, signer),
        release: new ethers.Contract(envAddrs.release, abi.releaseAbi, signer),
        releaseRabbit: new ethers.Contract(envAddrs.releaseRabbit, abi.releaseRabbitAbi, signer),
        knight: new ethers.Contract(envAddrs.knight, abi.knightAbi, signer),
        bonus: new ethers.Contract(envAddrs.bonus, abi.bonusAbi, signer),
        lp: new ethers.Contract(envAddrs.lp, abi.usdtAbi, signer),
        pancakeLp: new ethers.Contract(envAddrs.pancakeLp, abi.usdtAbi, signer),
        store: new ethers.Contract(envAddrs.store, abi.storeAbi, signer),
        controller: new ethers.Contract(envAddrs.controller, abi.controllerAbi, signer),
        propCore: new ethers.Contract(envAddrs.propCore, abi.propCoreAbi, signer),
        prop1155: new ethers.Contract(envAddrs.prop1155, abi.prop1155Abi, signer),
        soulMinter721: new ethers.Contract(envAddrs.soulMinter721, abi.soulMinter721Abi, signer),
        soul3dnft: new ethers.Contract(envAddrs.soul3dnft, abi.soul3dnftAbi, signer),
        timeBankNft: new ethers.Contract(envAddrs.timeBankNft, abi.timeBankNftAbi, signer),
        timeBank: new ethers.Contract(envAddrs.timeBank, abi.timeBankAbi, signer),
        timeBankRate: new ethers.Contract(envAddrs.timeBankRate, abi.timeBankRateAbi, signer),
        sm3d: new ethers.Contract(envAddrs.sm3d, abi.soul3dnftAbi, signer),
        socialWelfare: new ethers.Contract(envAddrs.socialWelfare, abi.socialWelfareAbi, signer),
        guessFist: new ethers.Contract(envAddrs.guessFist, abi.guessFistAbi, signer),
        gameTotal: new ethers.Contract(envAddrs.gameTotal, abi.gametotalAbi, signer),
        fishpondNFT: new ethers.Contract(envAddrs.fishpondnft, abi.fishpondnftAbi, signer),
        router: new ethers.Contract(envAddrs.router, abi.routerAbi, signer),
        dividend: new ethers.Contract(envAddrs.dividend, abi.dividendAbi, signer),
        chaebolnft:new ethers.Contract(envAddrs.chaebolnft,abi.chaebolnftAbi,signer),
        offlineTeam:new ethers.Contract(envAddrs.offlineTeam,abi.offlineTeamAbi,signer),
        onlineTeam:new ethers.Contract(envAddrs.onlineTeam,abi.onlineTeamAbi,signer),
        businessTeam:new ethers.Contract(envAddrs.businessTeam,abi.businessTeamAbi,signer),
        privateTeam:new ethers.Contract(envAddrs.privateTeam,abi.privateTeamAbi,signer),
        soulToken: new ethers.Contract(envAddrs.soulToken, abi.soultokenAbi, signer),   
        random: new ethers.Contract(envAddrs.random, abi.randomAbi, signer),   
        worldCup: new ethers.Contract(envAddrs.worldCup, abi.worldcupAbi, signer), 
        worldcupViewer: new ethers.Contract(envAddrs.worldcupViewer, abi.worldcupViewerAbi, signer), 
        soulReceive:new ethers.Contract(envAddrs.soulReceive,abi.soulReceiveAbi,signer),
        s2dNft:new ethers.Contract(envAddrs.s2dNft,abi.s2dNftAbi,signer),
        s2dNftSale:new ethers.Contract(envAddrs.s2dNftSale,abi.s2dNftSaleAbi,signer),   
        kakaChain:new ethers.Contract(envAddrs.kaka,abi.kakaAbi,signer),
        stiChain:new ethers.Contract(envAddrs.sti,abi.stiAbi,signer),
        iziChain:new ethers.Contract(envAddrs.izi,abi.iziAbi,signer),
        fistChain:new ethers.Contract(envAddrs.fist,abi.fistAbi,signer),
        gmtChain:new ethers.Contract(envAddrs.gmt,abi.gmtAbi,signer),
    }
    if (!myAddr) myAddr = await signer.getAddress()

    return {
        myAddr,
        ...ethers,
        provider,
        signer,
        rpcProvider,
        c: MyContracts,
        gasPrice: myGasPrice
    }
}

const MyEthers = {}
MyEthers.install = function (app, options) {
    app.config.globalProperties.getEther = getEther()
}

export default MyEthers
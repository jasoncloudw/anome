function date2WeekDay (date) {
    var weekDay = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    return weekDay[date.getDay()]
}
function date2WeekDayUTC (date) {
    var weekDay = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    return weekDay[date.getUTCDay()]
}

export function dateFormat (timeStamp, format) {
    if (timeStamp <= 10000000000) timeStamp = timeStamp * 1000
    let date = new Date(timeStamp)
    var dateObj = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'h+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds(),
        'q+': Math.floor((date.getMonth() + 3) / 3),
        'S+': date.getMilliseconds(),
        'w+': date2WeekDay(date)
    }
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
    }
    for (var k in dateObj) {
        if (new RegExp('(' + k + ')').test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? dateObj[k] : ('00' + dateObj[k]).substr(('' + dateObj[k]).length))
        }
    }
    return format
}

export function dateFormatUTC (timeStamp, format) {
    if (timeStamp <= 10000000000) timeStamp = timeStamp * 1000
    let date = new Date(timeStamp)
    var dateObj = {
        'M+': date.getUTCMonth() + 1,
        'd+': date.getUTCDate(),
        'h+': date.getUTCHours(),
        'm+': date.getUTCMinutes(),
        's+': date.getUTCSeconds(),
        'q+': Math.floor((date.getUTCMonth() + 3) / 3),
        'S+': date.getUTCMilliseconds(),
        'w+': date2WeekDayUTC(date)
    }
    if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (date.getUTCFullYear() + '').substr(4 - RegExp.$1.length))
    }
    for (var k in dateObj) {
        if (new RegExp('(' + k + ')').test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length === 1 ? dateObj[k] : ('00' + dateObj[k]).substr(('' + dateObj[k]).length))
        }
    }
    return format
}

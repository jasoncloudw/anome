'use strict'
// import {createApp} from 'vue'
// import App from '../app.vue'
// const app = createApp(App)

const IMG_PATH = 'https://image.kakanft.com/web/cards-mini/'
const IMG_PATHA = 'https://image.kakanft.com/web/cards/'
const IMG_RABBIT2 = 'https://image.kakanft.com/nft/kaka-rabbit-tp/'

const _utils = {
    getIdList () {
        const ids = []
        for (let i = 10001; i <= 10110; i++) {
            ids.push(i)
        }
        for (let i = 20001; i <= 20026; i++) {
            ids.push(i)
        }
        for (let i = 30001; i <= 30010; i++) {
            ids.push(i)
        }
        return ids
    },
    getRabbits2 (id) {
        return IMG_RABBIT2 + id + '.png'
    },
    getAlbum (id) {
        return IMG_PATHA + id + 'A.png'
    },
    getAlbumMini (id) {
        return IMG_PATH + id + 'A.png'
    },
    getWalletType () {
        if (!window.ethereum) {
            return 'no'
        } else if (window.ethereum.isImToken) {
            return 'imtoken'
        } else if (window.ethereum.isTokenPocket) {
            return 'tokenpocket'
        } else if (window.ethereum.rpcUrl && window.ethereum.rpcUrl.indexOf('bitkeep') !== -1) {
            return 'bitkeep'
        } else if (window.ethereum.isMetaMask && window.ethereum._metamask) {
            return 'metamask'
        } else {
            return 'unknown'
        }
    },
    toHex (BN) {
        return '0x' + BN.toHexString().slice(2).padStart(64, '0')
    }
}

const Utils = {}

Utils.install = function (app, options) {
    app.config.globalProperties.$utils = _utils
}
// app.use(Utils)
export default Utils

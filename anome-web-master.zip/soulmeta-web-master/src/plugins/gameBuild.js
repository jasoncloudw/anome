import axios from "axios";
var unitypaygame = null;
export function mallAnimation(roomId, url, myaddress, that, combatId) {
  // gamfun()
  var container = document.querySelector("#unity-container");
  var canvas = document.querySelector("#unity-canvas");
  var loadingBar = document.querySelector("#unity-loading-bar");
  var progressBarFull = document.querySelector("#unity-progress-bar-full");
  var fullscreenButton = document.querySelector("#unity-fullscreen-button");
  var warningBanner = document.querySelector("#unity-warning");

  // Shows a temporary message banner/ribbon for a few seconds, or
  // a permanent error message on top of the canvas if type=='error'.
  // If type=='warning', a yellow highlight color is used.
  // Modify or remove this function to customize the visually presented
  // way that non-critical warnings and error messages are presented to the
  // user.
  function unityShowBanner(msg, type) {
    function updateBannerVisibility() {
      warningBanner.style.display = warningBanner.children.length ? 'block' : 'none';
    }
    var div = document.createElement('div');
    div.innerHTML = msg;
    warningBanner.appendChild(div);
    if (type == 'error') div.style = 'background: red; padding: 10px;';
    else {
      if (type == 'warning') div.style = 'background: yellow; padding: 10px;';
      setTimeout(function () {
        warningBanner.removeChild(div);
        updateBannerVisibility();
      }, 5000);
    }
    updateBannerVisibility();
  }
  var config = ''
  var loaderUrl = ''
  var buildUrl = "https://static.soulmeta.io/web/game-mora/Build";
  if (/iPhone|Android/i.test(navigator.userAgent)) {
    var loaderUrl = buildUrl + "/MonsterUnityWebMobile.loader.js";
    var config = {
      dataUrl: buildUrl + "/MonsterUnityWebMobile.data.unityweb",
      frameworkUrl: buildUrl + "/MonsterUnityWebMobile.framework.js.unityweb",
      codeUrl: buildUrl + "/MonsterUnityWebMobile.wasm.unityweb",
      streamingAssetsUrl: "StreamingAssets",
      companyName: "DefaultCompany",
      // productName: "My project",
      productVersion: "0.1",
      showBanner: unityShowBanner,
      matchWebGLToCanvasSize: false
    };
  } else {
    var loaderUrl = buildUrl + "/MonsterUnityWeb.loader.js";
    var config = {
      dataUrl: buildUrl + "/MonsterUnityWeb.data.unityweb",
      frameworkUrl: buildUrl + "/MonsterUnityWeb.framework.js.unityweb",
      codeUrl: buildUrl + "/MonsterUnityWeb.wasm.unityweb",
      streamingAssetsUrl: "StreamingAssets",
      companyName: "DefaultCompany",
      // productName: "My project",
      productVersion: "0.1",
      showBanner: unityShowBanner,
    };
  }


  // By default Unity keeps WebGL canvas render target size matched with
  // the DOM size of the canvas element (scaled by window.devicePixelRatio)
  // Set this to false if you want to decouple this synchronization from
  // happening inside the engine, and you would instead like to size up
  // the canvas DOM size and WebGL render target sizes yourself.
  // config.matchWebGLToCanvasSize = false;
  if (/iPhone/i.test(navigator.userAgent)) {
    that.$message.error(that.$t("gameslobby.msg13"));
    setTimeout(() => {
      that.gameendto()
    }, 3000);
    return
  }
  if (/iPhone|Android/i.test(navigator.userAgent)) {
    // Mobile device style: fill the whole browser client area with the game canvas:

    var meta = document.createElement('meta');
    meta.name = 'viewport';
    meta.content = 'width=device-width, height=device-height, initial-scale=1.0, user-scalable=no, shrink-to-fit=yes';
    document.getElementsByTagName('head')[0].appendChild(meta);
    container.className = "unity-mobile";

    // To lower canvas resolution on mobile devices to gain some
    // performance, uncomment the following line:
    config.devicePixelRatio = 1;

    canvas.style.width = window.innerHeight + 'px';
    canvas.style.height = window.innerWidth + 'px';
    canvas.style.transform = 'rotate(90deg)'
    canvas.style.transformOrigin = window.innerWidth / 2 + 'px'
    // unityShowBanner('WebGL builds are not supported on mobile devices.');
  } else {
    // Desktop style: Render the game canvas in a window that can be maximized to fullscreen:

    canvas.style.width = '100%';
    canvas.style.height = '100vh';
  }

  loadingBar.style.display = "block";

  var script = document.createElement("script");
  script.src = loaderUrl;
  script.onload = () => {
    createUnityInstance(canvas, config, (progress) => {
      progressBarFull.style.width = 100 * progress + "%";
    }).then((unityInstance) => {
      loadingBar.style.display = "none";
      fullscreenButton.onclick = () => {
        unityInstance.SetFullscreen(1);
      };
      that.loading = false
      that.playtime = setInterval(() => {
        axios.post("/3dnft-rps-api/isCombatStart", {
          roomId: parseInt(roomId),
          combatId: parseInt(combatId)
        }, {
          headers: {
            "Content-Type": "application/json",
          },
        }).then(e => {
          if (e.data.result == 1) {
            clearInterval(that.playtime);
            // 玩家一出拳      
            let player1Rps = e.data.player1_rps.split('').toString().replace(/,/g, "_")
            // 玩家一出拳   
            let player2Rps = e.data.player2_rps.split('').toString().replace(/,/g, "_")
            let player1Address = e.data.player1
            let player2Address = e.data.player2
            let watcher = myaddress == e.data.player1 ? "0" : '1'
            let soulbEN = e.data.winBet / Math.pow(10, that.selectSortList[e.data.payType-1].dec)+' '+that.selectSortList[e.data.payType-1].name
            unityInstance.SendMessage('GameManager', 'InitAll', JSON.stringify({
              leftID: e.data.player1_tokeId,
              rightID: e.data.player2_tokeId,
              leftWalletAddress: player1Address,
              rightWalletAddress: player2Address,
              watcher: watcher,
              soul: soulbEN
            }));
            unityInstance.SendMessage('GameManager', 'UploadFightList', JSON.stringify({
              side: "0",
              data: player1Rps
            }));
            unityInstance.SendMessage('GameManager', 'UploadFightList', JSON.stringify({
              side: "1",
              data: player2Rps
            }));
          } else if (e.data.result == 2) {
            that.$message.error(that.$t("gameslobby.msg4"));
            clearInterval(that.playtime);
            that.dogfallfun(roomId, (e.data.bet) / Math.pow(10, 18),e.data.payType==0?2:e.data.payType)
          }
        }).catch(f => {
          clearInterval(that.playtime);
        })
      }, 5000);
      window.gameended = function name(params) {
        // that.gameendto()
        that.$router.replace({
          name: "games-lobby",
        })  
      }
      unitypaygame = unityInstance
    }).catch((message) => {
      alert(message);
    });
  };
  document.body.appendChild(script);

}
export function close_playgame() {
  return unitypaygame
}
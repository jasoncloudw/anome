export const inputAmount = function (num, n) {
  if (/[^\d.]/.test(num)) return "";
  if (num.indexOf(".") === -1) return num;

  if (num.includes(".", num.indexOf(".") + 1)) {
    return num.slice(0, num.lastIndexOf("."));
  }

  if (!n) n = 2;
  let arrStr = num.split('.');
  if (arrStr[1].length > n) {
    return arrStr[0] + '.' + arrStr[1].slice(0, n);
  }

  return num;
};

export const sliceDecimals = function (data, n) {
  if (!n) n = 2;
  if (+data === 0) return 0 + "." + "0".repeat(n);
  if (!+data || data === Infinity || data === -Infinity) return "--";
  let arrStr = data.toString().split(".");
  if (arrStr[0] == data) return +data + "." + "0".repeat(n);

  if (arrStr[1].length > n) {
    return arrStr[0] + "." + arrStr[1].slice(0, n);
  } else return arrStr[0] + "." + arrStr[1].padEnd(n, "0");
}
//数字添加逗号分隔符 
export const numberFilter = function (value,cut = 2) {
  //value为我们传进来的数据 比如  145775.422346
  //cut 为需要保留的小数位数  -1为清空小数 0为保留全部位数的小数 传入多少即为多少 不传默认保留两位小数 传进来多少就截取多少
  //数据校验  
  if (parseFloat(value).toString() == 'NaN') return '0.00'
  // 将数值截取
  let num = value.toString().split('.')
  let zs = num[0]
  let xs = num[1]
  // 整数部分处理，增加,
  const intPartFormat = zs.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
  if (xs != null) {
    if(cut == 0){
      return intPartFormat + '.' + xs
    }else if(cut == -1){
      return intPartFormat
    }else{
      return intPartFormat +'.' + xs.substr(0,cut)
    }
  } else {
    return intPartFormat
  }
}

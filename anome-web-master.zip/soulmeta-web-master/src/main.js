// import VConsole from 'vconsole';
// const vconsole = new VConsole()

import { createApp } from 'vue'
import App from './app.vue'
import './index.css'

import Ethers from './plugins/ethers'
import Axios from './plugins/axios'
import Utils from './plugins/utils'
import Router from './router.js'
import Store from './store.js'
import i18n from './lang/i18n'
import ElementPlus from 'element-plus';
import VueClipboard from 'vue-clipboard2'
import 'element-plus/dist/index.css'
// import 'swiper/css';
import 'swiper/js/swiper.min'
import 'swiper/css/swiper.min.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import Directives from "./plugins/directives";

// import Vconsole from 'vconsole'
// const vConsole = new Vconsole()

const app = createApp(App)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
  }
app.use(Axios)
app.use(Ethers)
app.use(Utils)
app.use(Router)
app.use(Store)
app.use(i18n)
app.use(ElementPlus)
app.use(VueClipboard)
// app.use(vConsole)
app.use(Directives)
app.mount('#app')

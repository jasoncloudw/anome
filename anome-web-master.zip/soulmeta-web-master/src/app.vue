<template>
  <div class="h-full">
    <router-view v-if="isRouterAlive" class=""></router-view>
    <Soon v-if="soon"></Soon>
    <Pay v-if="buyPage"></Pay>
    <Payment v-if="castingPage"></Payment>
    <BatchPayment v-if="batchCastingPage"></BatchPayment>
  </div>
</template>

<script>
import Soon from "./components/coming-soon.vue";
import Pay from "./components/pay.vue";
import Payment from "./components/payment.vue";
import BatchPayment from "./components/batch-payment.vue";
export default {
  components: { Soon, Pay, Payment, BatchPayment },
  provide() {
    return {
      reload: this.reload,
    };
  },
  data() {
    return {
      isRouterAlive: true,
    };
  },
  computed: {
    soon() {
      return this.$store.state.soon;
    },
    buyPage() {
      return this.$store.state.waitBuyPage;
    },
    castingPage() {
      return this.$store.state.waitCastingPage;
    },
    batchCastingPage() {
      return this.$store.state.waitBatchCastingPage;
    },
  },
  async created() {
    this.$store.dispatch("initEther");
    this.$store.dispatch("fetchCardList");
  },
  mounted() {},
  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(function () {
        this.isRouterAlive = true;
      });
    },
  },
};
</script>

<style>
.el-drawer.ltr, .el-drawer.rtl{
  background: url("https://static.soulmeta.io/web/img/game-mora/w-openrecord.webp") no-repeat center/100% 100%;
  top: calc(50% - 185px) !important;
  height: 370px !important;
  /* height: 50% !important;
  margin-top: 25%; */
}
</style>

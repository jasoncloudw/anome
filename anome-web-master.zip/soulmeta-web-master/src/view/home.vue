<template>
  <div v-loading="loading" class="bg">
    <Header />
    <div class="lg:w-200 xl:w-300 w-9/10 mx-auto">
      <div class="grid grid-cols-8 gap-4 px-4 md:px-40">
        <div v-for="(item, index) in langList" :key="item" class="rounded-full cursor-pointer mx-auto" @click="changeLang(item)">
          <img
            class="w-7 md:w-16 rounded-full"
            :class="[lang === item ? 'border-2 border-solid border-yellow-400' : 'border-0']"
            :src="'https://static.soulmeta.io/web/img/home/lang' + (index + 1) + '.webp'"
            alt=""
          />
        </div>
      </div>
      <div class="mt-5 md:mt-10 mb-5 text-sm md:text-xl text-center">
        <div>{{ $t("home.home1") }}</div>
        <div class="md:text-2xl">0.00000029%</div>
        <div>{{ $t("home.home2") }}</div>
      </div>
      <div class="w-full swp-bg" v-if="isMobile">
        <div class="flex items-center relative">
          <div class="swiper-container">
            <div class="swiper-wrapper">
              <div class="swiper-slide" v-for="(item, index) in myCards" :key="index">
                <div class="w-full" :class="{ 'cursor-pointer': item.path }" @click="toLink(item)">
                  <img class="w-full rounded-3xl" :src="'https://static.soulmeta.io/web/img/home/swiper' + item.image + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <el-carousel type="card" indicator-position="none" arrow="never" v-else>
        <div class="h-24 md:h-50 lg:h-58 xl:h-78 2xl:80">
          <el-carousel-item v-for="item in myCards" :key="item.key">
            <div class="w-full" :class="{ 'cursor-pointer': item.path }" @click="toLink(item)">
              <img
                class="w-full rounded-3xl"
                :src="'https://static.soulmeta.io/web/img/home/swiper' + item.image + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'"
                alt=""
              />
            </div>
          </el-carousel-item>
        </div>
      </el-carousel>
      <img class="w-full mt-5 xl:mt-16" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />

      <div class="mt-5 xl:mt-16" v-if="isMobile">
        <div class="p-2 sm:p-4 md:p-10 xl:p-14 flex items-center justify-between caste-bg rounded-2xl">
          <div class="relative mr-1 cursor-pointer" @click="buyBox(2)">
            <img class="w-41 sm:w-60 md:w-80 xl:w-124" :src="'https://static.soulmeta.io/web/img/home/man_img' + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
            <!-- <div class="w-full text-sm text-center absolute bottom-1 font-semibold">寻找一位男士</div> -->
          </div>
          <div class="relative cursor-pointer" @click="buyBox(1)">
            <img class="w-41 sm:w-60 md:w-80 xl:w-124" :src="'https://static.soulmeta.io/web/img/home/woman_img' + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
            <!-- <div class="w-full text-sm text-center absolute bottom-1 font-semibold">寻找一位女士</div> -->
          </div>
        </div>
        <div v-show="buyBtnShow" class="mt-4 md:mt-8 xl:mt-16 flex justify-around">
          <div class="w-max mx-auto p-1 md:p-3 px-2 rounded-lg text-center cursor-pointer bg-F02" @click="toBuy(1)">
            {{ gender === 2 ? $t("home.home3-1") : $t("home.home3-2") }}
          </div>
          <div
            class="w-max mx-auto p-1 md:p-3 px-2 rounded-lg text-center cursor-pointer"
            :class="propsNum > 0 ? 'bg-F02' : 'bg-gray-400'"
            @click="toBatchOfBuy"
          >
            {{ $t("home.home4") }}
          </div>
        </div>
        <div class="mt-5 md:mt-8 xl:mt-16 p-2 sm:p-4 md:p-10 xl:p-14 flex items-center justify-between caste-bg rounded-2xl">
          <div class="relative mr-1 cursor-pointer" @click="toSelectIdentity(2)">
            <img class="w-41 sm:w-60 md:w-80 xl:w-124" :src="'https://static.soulmeta.io/web/img/home/man_box' + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
            <div class="w-full text-sm text-center absolute bottom-1">
              <!-- <div class="font-semibold">铸造男士NFT</div> -->
            </div>
          </div>
          <div class="relative cursor-pointer" @click="toSelectIdentity(1)">
            <img class="w-41 sm:w-60 md:w-80 xl:w-124" :src="'https://static.soulmeta.io/web/img/home/woman_box' + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
            <div class="w-full text-sm text-center absolute bottom-1">
              <!-- <div class="font-semibold">铸造女士NFT</div> -->
            </div>
          </div>
        </div>
      </div>
      <div class="mt-5 xl:mt-16 pb-4 relative" v-else>
        <div class="w-full flex justify-between">
          <div class="w-1/2 px-10">
            <img src="https://static.soulmeta.io/web/img/home/open_blind_box.webp" alt="" />
            <div class="flex items-center justify-center mt-14">
              <div class="blind-box-btn flex items-center justify-center w-64 h-11 bg-F02 mx-auto rounded-lg cursor-pointer" @click="toShowGenderBox('single')">
                <img class="w-5 h-auto mr-2.5" src="https://static.soulmeta.io/web/img/home/single.webp" alt="" />
                <span>{{ $t("home.home24") }}</span>
              </div>
              <div
                class="blind-box-btn flex items-center justify-center w-32 h-11 mx-auto rounded-lg cursor-pointer"
                :class="propsNum > 0 ? 'bg-F02' : 'bg-gray-400'"
                @click="toShowGenderBox('batch')"
              >
                <img class="w-5 h-auto mr-2.5" src="https://static.soulmeta.io/web/img/home/batch.webp" alt="" />
                <span class="uppercase">{{ $t("home.home4") }} </span>
              </div>
            </div>
          </div>
          <div class="w-1/2 px-10">
            <img src="https://static.soulmeta.io/web/img/home/mint_blind_box.webp" alt="" />
            <div class="blind-box-btn flex items-center justify-center w-72 h-11 bg-F02 mx-auto rounded-lg mt-14 cursor-pointer" @click="toSelectIdentity(0)">
              <img class="w-5 h-auto mr-2.5" src="https://static.soulmeta.io/web/img/home/mint.webp" alt="" />
              <span> {{ $t("home.home21") }} </span>
            </div>
          </div>
        </div>
      </div>

      <div v-if="canInvitor" class="caste-bg rounded-2xl py-5 md:py-10 mt-10 md:mt-20">
        <div class="mb-2 text-center md:text-xl text-yellow-200">
          {{ $t("home.home9") }}
        </div>
        <div class="">
          <img class="w-4 mx-auto mb-1" src="https://static.soulmeta.io/web/img/soulH/b_icon.webp" alt="" />
          <div class="flex justify-center items-center break-all px-5 md:px-10">
            <div class="text-xs md:text-xl text-yellow-200">
              {{ this.inviteLink }}
            </div>
            <img class="w-5 ml-2 cursor-pointer" src="https://static.soulmeta.io/web/img/soulH/copy_icon.webp" alt="" @click="doCopy" />
          </div>
        </div>
        <div class="mt-3 text-xs md:text-xl text-center">
          {{ $t("home.home10") }}
        </div>
      </div>

      <div class="mt-10 md:mt-14 xl:mt-20 relative md:flex md:justify-center">
        <img class="w-full cursor-pointer" src="https://static.soulmeta.io/web/img/home/soul_shop.webp" alt="" @click="this.$store.commit('setSoon', true)" />
      </div>
      <div class="mt-10 md:mt-14 xl:mt-20 p-8 md:p-12 xl:p-16 rule-bg rounded-2xl">
        <div class="mb-2 font-semibold text-center md:text-2xl">
          {{ $t("home.home5") }}
        </div>
        <div class="text-xs md:text-xl" :class="lang === 'cn' ? 'text-justify' : ''">
          {{ $t("home.home6") }}
        </div>
        <div class="mb-2 font-semibold mt-8 md:mt-16 text-center md:text-2xl">
          {{ $t("home.home7") }}
        </div>
        <div class="text-xs md:text-xl" :class="lang === 'cn' ? 'text-justify' : ''">
          {{ $t("home.home8") }}
        </div>
      </div>

      <div class="mt-10 md:mt-14 xl:mt-20">
        <div class="text-center font-semibold md:text-3xl">
          {{ $t("home.home11") }}
        </div>
        <img class="mt-1 md:mt-2.5" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />
        <div class="pt-10 md:pt-16 xl:pt-32 relative md:flex md:justify-center">
          <img class="md:w-9/12" :src="'https://static.soulmeta.io/web/img/home/pieChart' + '_' + (lang === 'ptBr' ? 'pt' : lang) + '.webp'" alt="" />
        </div>
      </div>

      <div class="mt-10 md:mt-14 xl:mt-20">
        <div class="text-center font-semibold md:text-3xl">
          {{ $t("home.home12") }}
        </div>
        <img class="mt-1 md:mt-2.5 mb-8 md:mb-12" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />
        <div class="pl-3 mb-3 md:mb-4 rounded-full bg-E72 md:leading-7 md:text-center">2022</div>
        <div class="w-full max-h-72 md:max-h-full overflow-y-auto overflow-x-hidden md:mb-12">
          <div class="mb-3 md:mb-4 text-xs md:text-base flex items-start whitespace-pre-wrap text-gray">
            <!-- <img class="w-3 mr-3" src="/img/soulH/icon.webp" alt=""> -->
            <span class="font-semibold">Q2</span>
            <br />{{ $t("home.home13") }}
          </div>
          <div class="mb-3 md:mb-4 text-xs md:text-base flex items-start whitespace-pre-wrap text-gray">
            <span class="font-semibold">Q3</span>
            <br />{{ $t("home.home14") }}
          </div>
          <div class="mb-3 md:mb-4 text-xs md:text-base flex items-start whitespace-pre-wrap text-gray">
            <span class="font-semibold">Q4</span>
            <br />{{ $t("home.home15") }}
          </div>
        </div>
        <div class="my-3 md:mb-4 pl-3 rounded-full bg-E72 md:leading-7 md:text-center">2023</div>
        <div class="w-full max-h-72 md:max-h-full overflow-y-auto overflow-x-hidden">
          <div class="mb-3 md:mb-4 text-xs md:text-base flex items-start whitespace-pre-wrap text-gray">
            <span class="font-semibold">Q1</span>
            <br />{{ $t("home.home16") }}
          </div>
          <div class="mb-3 md:mb-4 text-xs md:text-base flex items-start whitespace-pre-wrap text-gray">
            <span class="font-semibold">Q2</span>
            <br />{{ $t("home.home17") }}
          </div>
        </div>
      </div>
    </div>
    <Footer />
    <!-- batch of buy box -->
    <div class="fixed inset-0 z-50 bg-black bg-opacity-70" v-show="showBatchBox">
      <div
        class="bg-black absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-9/10 md:w-124 border rounded-xl border-red-500 bg-opacity-70 m-auto px-3 md:px-6 py-4 md:py-10"
      >
        <img
          class="w-3 md:w-4 absolute top-4 right-4 cursor-pointer"
          src="https://static.soulmeta.io/web/img/home/close.webp"
          alt=""
          @click="showBatchBox = false"
        />

        <p class="text-xs md:text-xl text-center">{{ $t("home.home19") }}</p>

        <div class="w-full px-0 flex flex-wrap justify-center text-center mt-2 md:mt-4">
          <div
            v-for="item in batchQuantityList"
            :key="item.id"
            class="w-1/3 h-6 md:h-10 mt-2.5 md:mt-5 mx-2 xl:mx-2.5 flex items-center justify-center rounded-full cursor-pointer relative"
            :class="currentSelectPropId === item.id ? 'bg-F02' : 'bg-707'"
            @click="selectPropId(item)"
          >
            <div class="text-xs md:text-base">{{ item.key }}</div>
            <sub class="absolute right-2 -bottom-2">{{ $t("home.home27") }}: {{ item.num }}</sub>
          </div>
          <div
            class="blind-box-btn w-1/3 flex items-center justify-center py-1 md:py-2 rounded-lg cursor-pointer bg-F02 text-xs md:text-xl mt-6 md:mt-10"
            @click="toBuy(2)"
          >
            {{ $t("home.home20") }}
          </div>
        </div>
      </div>
    </div>

    <!-- select blind box gender -->
    <div class="fixed inset-0 z-50 bg-black bg-opacity-70" v-show="showGenderBox">
      <div
        class="bg-[#252525] absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 rounded-xl flex items-center justify-center px-10 py-14 cursor-pointer"
      >
        <div class="blind-box-btn flex items-center justify-center w-40 h-11 bg-F02 mx-auto rounded-lg mr-10" @click="selectGenderBox(2)">
          <img class="w-5 h-auto mr-2.5" src="https://static.soulmeta.io/web/img/home/man.webp" alt="" />
          <span>{{ $t("home.home22") }}</span>
        </div>
        <div class="blind-box-btn flex items-center justify-center w-40 h-11 bg-F02 mx-auto rounded-lg cursor-pointer" @click="selectGenderBox(1)">
          <img class="w-5 h-auto mr-2.5" src="https://static.soulmeta.io/web/img/home/woman.webp" alt="" />
          <span>{{ $t("home.home23") }}</span>
        </div>
        <img class="w-4 absolute top-3 right-3 cursor-pointer" src="https://static.soulmeta.io/web/img/home/close.webp" alt="" @click="showGenderBox = false" />
      </div>
    </div>

    <!-- Casting Blind Box Identity -->
    <div class="fixed inset-0 z-50 bg-black bg-opacity-70" v-show="showMintBox">
      <div
        class="bg-black absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-9/10 md:w-160 border rounded-lg border-red-500 bg-opacity-70 m-auto px-2 md:px-12 py-4 md:py-12"
      >
        <img
          class="w-3 md:w-4 absolute top-4 right-4 cursor-pointer"
          src="https://static.soulmeta.io/web/img/home/close.webp"
          alt=""
          @click="showMintBox = false"
        />
        <div class="flex items-center justify-center">
          <div class="">
            <div>
              <img class="w-auto h-24 md:h-48 mx-auto" src="https://static.soulmeta.io/web/img/home/3d-citizen.webp" alt="" />
              <div class="relative">
                <img src="https://static.soulmeta.io/web/img/home/citizen-bg.webp" alt="" />
                <div class="absolute top-0 left-0 w-full h-full text-[#000] pl-[35%] flex items-center text-xs md:text-sm">
                  {{ $t("home.home29") }}
                </div>
              </div>
            </div>
            <div class="text-xs md:text-base px-2 h-14 flex items-center">
              {{ $t("home.home30") }}
            </div>
            <div
              class="blind-box-btn flex items-center justify-center w-32 h-8 md:w-40 md:h-11 mt-1 bg-F02 mx-auto rounded-lg uppercase cursor-pointer"
              @click="toCasting('3dcitizen')"
            >
              {{ $t("caste.cas4") }}
            </div>
          </div>
          <div class="red-cloumn-line mx-2 md:mx-10 h-72"></div>
          <div>
            <div class="">
              <img class="w-auto h-24 md:h-48 mx-auto" src="https://static.soulmeta.io/web/img/home/civilian.webp" alt="" />
              <div class="relative">
                <img src="https://static.soulmeta.io/web/img/home/civilian-bg.webp" alt="" />
                <div class="absolute top-0 left-0 w-full h-full text-[#000] pl-[35%] flex items-center text-xs md:text-sm">
                  {{ $t("home.home28") }}
                </div>
              </div>
            </div>
            <div class="text-xs md:text-base px-2 h-14 flex items-center">
              {{ $t("home.home32") }}
            </div>
            <div
              class="blind-box-btn flex items-center justify-center w-32 h-8 md:w-40 md:h-11 mt-1 bg-F02 mx-auto rounded-lg uppercase cursor-pointer"
              @click="toCasting('civilian')"
            >
              {{ $t("caste.cas4") }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
import Swiper from "swiper";
import { getEther } from "@/plugins/ethers";
export default {
  name: "soulHome",
  components: { Header, Footer },
  data() {
    return {
      loading: false,
      canInvitor: false,
      langList: ["en", "kr", "cn", "jp", "es", "vl", "lt", "pt", "ptBr", "", "", "", "", "", "", ""],
      swiper: null,
      myCards: [
        { key: 1, image: 1, path: "/advert", isTarget: false },
        // { key: 2, image: 2, path: "", isTarget: false },
        { key: 3, image: 3, path: "", isTarget: false },
        // { key: 4, image: 4, path: "https://official.light-houses.io/", isTarget: true },
        { key: 5, image: 5, path: "", isTarget: false },
        { key: 6, image: 6, path: "", isTarget: false },
        { key: 7, image: 7, path: "", isTarget: false },
      ],
      buyBtnShow: false,
      gender: 0,
      // approvedUsdt: false,
      invitor: "",
      signMessage: "",
      listenOn: false,
      inviteLink: "",
      showBatchBox: false,
      propsNum: 0,
      showGenderBox: false,
      openBlindBoxType: "",
      allowBatchOpenNum: 0,
      batchQuantityList: [],
      currentSelectPropId: 0,
      batchQuantity: 0,
      showMintBox: false,
    };
  },
  computed: {
    myAddr() {
      let str;
      if (this && this.$store.state.myAddr) {
        str = this.$store.state.myAddr;
        str = str.substring(0, 5) + "..." + str.substring(str.length - 5);
      } else {
        str = "WALLET";
      }
      return str;
    },
    lang() {
      return this.$i18n.locale;
    },
    isMobile() {
      if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) return true;
    },
  },
  methods: {
    toLink(item) {
      if (item.isTarget) {
        window.open(item.path, true);
      } else {
        this.$router.push(item.path);
      }
    },
    changeLang(lang) {
      if (!lang) {
        this.$store.commit("setSoon", true);
        return;
      }
      this.isMobile && this.swiper.destroy();
      this.swiperHome();
      this.$i18n.locale = lang;
    },
    toSelectIdentity(gender) {
      this.gender = gender;
      this.toCasting('civilian');
      // this.showMintBox = true;
    },
    async toCasting(identity) {
      if (identity === "3dcitizen") {
        let balanceOf = await this.eth.c.sm3d.balanceOf(this.eth.myAddr);
        if (balanceOf.eq(0)) {
          this.$message.error(this.$t("msg.msg19"));
          return;
        }
      }

      if (this.gender) {
        this.$store.commit("setBoxType", this.gender);
        this.$router.push({
          path: "/casting",
          query: {
            gender: this.gender,
            identity,
          },
        });
      } else {
        this.$router.push({
          path: "/casting",
          query: {
            identity,
          },
        });
      }
    },
    buyBox(gender) {
      this.gender = gender;
      this.buyBtnShow = !this.buyBtnShow;
    },
    toShowGenderBox(type) {
      if (type === "batch" && !this.propsNum) {
        this.$message.error(this.$t("home.home26"));
      } else {
        this.openBlindBoxType = type;
        this.showGenderBox = !this.showGenderBox;
      }
    },
    selectGenderBox(type) {
      this.gender = type;
      this.showGenderBox = false;
      if (this.openBlindBoxType === "batch") {
        this.toBatchOfBuy();
      } else {
        this.toBuy(1);
      }
    },
    async selectPropId(data) {
      let propsNum = await this.eth.c.prop1155.balanceOf(this.eth.myAddr, data.id);

      if (propsNum.eq(0)) return;
      this.currentSelectPropId = data.id;
      this.batchQuantity = data.key;
    },
    async toBatchOfBuy() {
      if (this.propsNum) {
        this.showBatchBox = true;
      } else {
        this.$message.error(this.$t("home.home26"));
      }
    },
    async openSucc(tokenId) {
      window.localStorage.setItem("soulBox", tokenId);
      try {
        this.signMessage = await this.eth.signer.signMessage("Sign to your Meta Soul, Token ID: " + String(tokenId) + ".");
        this.$store.commit("setSignMessage", this.signMessage);
        this.$router.push({
          path: "/success-page",
          query: {
            type: 1,
            gender: this.gender,
            tokenId: tokenId,
          },
        });
      } catch (error) {}
      this.$store.commit("setWaitCastingPage", false);
    },
    listenEvent(events) {
      events.forEach((ele) => {
        if (ele.event && ele.event === "Extract") {
          this.openSucc(parseInt(ele.topics[3]));
        }
      });
    },
    async toBuy(type) {
      // 查盲盒数量
      // let boxSums = 0;
      // if (!parseInt(boxSums)) {
      //   this.$message.error(this.$t("msg.msg1"));
      //   return;
      // }

      if (this.invitor === this.eth.myAddr) {
        this.$message.error(this.$t("msg.msg2"));
        return;
      }

      let rewards = await this.eth.c.controller.referWallet(this.eth.myAddr);
      let referralRewards = parseInt(this.eth.utils.formatEther(rewards));
      let balance = await this.eth.c.usdt.balanceOf(this.eth.myAddr);
      let usdtBalance = parseInt(this.eth.utils.formatEther(balance));

      if (
        (type === 1 && referralRewards < 4 && usdtBalance < 4) ||
        (type === 2 && referralRewards < this.batchQuantity * 4 && usdtBalance < this.batchQuantity * 4)
      ) {
        this.$message.error(this.$t("msg.msg3"));
        return;
      }

      if (type === 1) {
        let allowance = await this.eth.c.usdt.allowance(this.eth.myAddr, this.eth.c.controller.address);
        if (allowance.eq(0)) {
          try {
            this.$store.commit("setWaitCastingPage", true);
            let approve = await this.eth.c.usdt.approve(this.eth.c.controller.address, this.eth.constants.MaxUint256);
            await approve.wait();
            this.singleOfBuy();
          } catch (err) {
            this.showGenderBox = false;
            this.$store.commit("setWaitCastingPage", false);
          }
        } else {
          this.showGenderBox = false;

          this.singleOfBuy();
        }
      }

      if (type === 2) {
        this.$store.commit("BATCH_CASTRING_PAGE", true);

        let prop1155ApproveStatus = await this.eth.c.prop1155.isApprovedForAll(this.eth.myAddr, this.eth.c.propCore.address);

        if (!prop1155ApproveStatus) {
          try {
            let approve = await this.eth.c.prop1155.setApprovalForAll(this.eth.c.propCore.address, true);
            await approve.wait();
          } catch {
            this.showBatchBox = false;
            this.$store.commit("BATCH_CASTRING_PAGE", false);
            return;
          }
        }

        let approveStatus = await this.eth.c.usdt.allowance(this.eth.myAddr, this.eth.c.controller.address);
        if (!parseInt(approveStatus)) {
          try {
            let approve = await this.eth.c.usdt.approve(this.eth.c.controller.address, this.eth.constants.MaxUint256);
            await approve.wait();
          } catch {
            this.showBatchBox = false;
            this.$store.commit("BATCH_CASTRING_PAGE", false);
            return;
          }
        }
        this.batchOfBuy();
      }
    },
    async singleOfBuy() {
      try {
        this.$store.commit("setWaitCastingPage", true);
        let res = await this.eth.c.router.drawBox(this.eth.myAddr, 1, this.gender, 1, this.invitor ? this.invitor : this.eth.constants.AddressZero, {
          gasLimit: 800000,
        });
        res = await res.wait();
        await this.listenEvent(res.events);
      } catch (e) {
        console.log("e", e);
        this.$store.commit("setWaitCastingPage", false);
      }
    },
    async batchOfBuy() {
      try {
        this.$store.commit("BATCH_CASTRING_PAGE", true);
        let res = await this.eth.c.propCore.propBatchBox(
          1,
          this.gender,
          this.currentSelectPropId,
          this.invitor ? this.invitor : this.eth.constants.AddressZero,
          {
            gasLimit: "4000000",
          }
        );
        res = await res.wait();
        this.showBatchBox = false;
        this.$router.push(`/batch-success-page/${this.batchQuantity}`);
        this.$store.commit("BATCH_CASTRING_PAGE", false);
      } catch (e) {
        console.log("e", e);
        this.showBatchBox = false;
        this.$store.commit("BATCH_CASTRING_PAGE", false);
      }
    },

    async doCopy() {
      this.$copyText(this.inviteLink).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },
    swiperHome() {
      //调用延迟加载 $nextTick

      this.$nextTick(() => {
        this.swiper = new Swiper(".swiper-container", {
          observer: true,
          observeParents: true,
          // loop: true,
          speed: 1200,
          autoplay: {
            autoplay: false,
            disableOnInteraction: false,
          },
          // navigation: {
          //     nextEl: '.swiper-button-next',
          //     prevEl: '.swiper-button-prev',
          // }
        });
      });
    },
    async getPropNum() {
      let propIdList = [2, 3];
      let filterList = [];

      for (let i = 0; i < propIdList.length; i++) {
        let { times } = await this.eth.c.propCore.propEffect(propIdList[i]);
        let propsNum = await this.eth.c.prop1155.balanceOf(this.eth.myAddr, propIdList[i]);

        let prop = {
          id: propIdList[i],
          key: times.toNumber(),
          num: propsNum.toNumber(),
        };

        this.batchQuantityList.push(prop);
        this.propsNum += propsNum.toNumber();

        if (propsNum.gt(0)) {
          filterList.push(prop);
        }
      }

      let defaultKey = filterList.sort((a, b) => b - a)[0];
      this.currentSelectPropId = defaultKey?.id;
      this.batchQuantity = defaultKey?.key;
    },
  },
  async created() {
    if (this.$route.query.invitor) {
      window.sessionStorage.setItem("invitor", this.$route.query.invitor);
      this.$router.push("/advert");
    }

    this.invitor = window.sessionStorage.getItem("invitor");
    this.eth = await getEther();
    if (this.eth) {
      let balance721 = await this.eth.c.soul721.balanceOf(this.eth.myAddr);
      let balance1155 = await this.eth.c.soul1155.itemBalanceOf(this.eth.myAddr);
      let invitorBind = await this.eth.c.controller.referrers(this.eth.myAddr);
      if (parseInt(invitorBind) || parseInt(balance721) || parseInt(balance1155)) {
        this.canInvitor = true;
        this.inviteLink = window.location.origin + window.location.pathname + "?invitor=" + this.eth.myAddr;
      }
    }

    this.getPropNum();
  },
  mounted() {
    this.swiperHome();
    // 清空铸造时的用户信息
    this.$store.commit("setCasteInfo", {
      type: 0,
      img: "",
      contInfo: "",
      soulNum: 1,
      linkType: 0,
      casteNum: 0,
      file: null,
    });
    window.localStorage.setItem("soulBox", 0);
  },
};
</script>

<style lang="scss" scoped>
.bg {
  background: black;
}
.caste-bg {
  background-image: linear-gradient(to right, #e93b4d, #4f3b90);
}

.rule-bg {
  background-color: #f1213b;
}
.input-bg {
  background-image: linear-gradient(to right, #ff0000, #220000);
}

.prev {
  @apply left-0;
}
.next {
  @apply right-0;
}
.prev,
.next {
  @apply w-4 h-full top-0 mt-0;
}

.blind-box-btn {
  box-shadow: 0 2px 0 #fff;
}

:deep(.el-carousel__mask) {
  opacity: 0.25;
  background-color: black;
  height: 100%;
  border-radius: 1.5rem;
  :hover {
    opacity: 0;
  }
}
:deep(.el-carousel__container) {
  height: 100%;
}
</style>

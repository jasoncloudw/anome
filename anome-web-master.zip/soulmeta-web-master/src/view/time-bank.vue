<template>
  <div class="bg-black min-h-full">
    <Header />
    <div class="lg:w-200 xl:w-300 w-9/10 mx-auto pt-10 pb-4 md:pb-24">
      <img class="w-full h-auto" src="https://static.soulmeta.io/web/img/time-bank/banner.webp" alt="" />
      <div class="mt-2 md:mt-4 leading-6 md:leading-8 text-xs md:text-xl max-h-48 overflow-y-scroll c-scrollbar">
        <div>
          <p>{{ $t("timebank.bank29") }}</p>
          <p>{{ $t("timebank.bank30") }}</p>
          <p>{{ $t("timebank.bank31") }}</p>
          <p>{{ $t("timebank.bank32") }}</p>
          <p>{{ $t("timebank.bank33") }}</p>
        </div>
        <div class="mt-5">
          <p>{{ $t("timebank.how_to_participate.title") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_1") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_2") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_3") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_4") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_5") }}</p>
          <p>{{ $t("timebank.how_to_participate.c_6") }}</p>
        </div>
      </div>
      <div class="flex items-start justify-center mt-10 md:mt-20">
        <img class="w-auto h-20 md:h-44" src="https://static.soulmeta.io/web/img/time-bank/hand.webp" alt="" />
        <div class="text-base md:text-3xl mt-4 md:mt-8">{{ $t("timebank.bank1") }}</div>
      </div>
      <div class="-mt-10 md:-mt-20">
        <div class="relative rounded-lg overflow-hidden">
          <div class="h-14 md:h-24 flex items-center justify-between px-4 md:px-24 bg-7f0 text-sm md:text-2xl">
            <div>{{ $t("timebank.bank2") }}:</div>
            <div>
              <span>{{ totalPledge }}</span>
              <span class="text-xs md:text-base ml-2">SOUL</span>
            </div>
          </div>
          <div
            class="h-14 md:h-24 flex items-center justify-between px-4 md:px-24 bg-7f0 text-sm md:text-2xl border-t md:border-t-2 border-b md:border-b-2 border-black"
          >
            <div>{{ $t("timebank.bank3") }}:</div>
            <div>
              <span>{{ remainingTotalRewards }}</span>
              <span class="text-xs md:text-base ml-2">SOUL</span>
            </div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between px-4 md:px-24 bg-7f0 text-sm md:text-2xl">
            <div>{{ $t("timebank.bank4") }}:</div>
            <div>
              <span>{{ estimatedTotalIncome }}</span>
              <span class="text-xs md:text-base ml-2">SOUL</span>
            </div>
          </div>
          <img class="w-auto h-full absolute top-0 right-0 z-10" src="https://static.soulmeta.io/web/img/time-bank/wallet.webp" alt="" />
        </div>
      </div>
      <div class="text-xs md:text-base xl:text-xl mt-2">
        <p>{{ $t("timebank.bank45") }}</p>
        <p>{{ $t("timebank.bank46") }} 0xBe1399934bE5EfEd588778895d92b56841986040</p>
        <p>{{ $t("timebank.bank47") }} 0x8d454fb28f46c850eD5ecc7B48D36B6D8058fB30</p>
      </div>
      <div class="mt-8 md:mt-16">
        <div class="h-16 md:h-28 flex items-center justify-between px-4 md:px-24 text-sm md:text-2xl bg-300 border-b md:border-b-2 border-black rounded-t-lg">
          <div class="capitalize">{{ $t("timebank.bank5") }}</div>
          <div class="flex items-center">
            <el-input class="rounded-xl text-sm md:text-2xl lock-amount" v-model.trim="lockAmount" placeholder="" @input="handleLockAmount" />
            <span class="ml-2 md:ml-4 whitespace-nowrap cursor-pointer" @click="lockAmount = soulBalance">{{ $t("timebank.bank6") }}</span>
          </div>
        </div>
        <div class="h-16 md:h-28 flex items-center justify-between px-4 md:px-24 text-sm md:text-2xl bg-300 border-b md:border-b-2 border-black">
          <div>{{ $t("timebank.bank7") }}</div>
          <div>
            <span>{{ soulBalance }}</span>
            <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
          </div>
        </div>
        <div class="h-16 md:h-28 flex items-center justify-between px-4 md:px-24 text-sm md:text-2xl bg-300 border-b md:border-b-2 border-black">
          <div>{{ $t("timebank.bank8") }}</div>
          <div class="relative">
            <div
              class="w-32 md:w-60 h-10 md:h-14 bg-[#131313] flex items-center justify-between rounded px-2 md:px-4 cursor-pointer"
              @click="expandDays = !expandDays"
            >
              <div class="md:text-xl">{{ postPledgeData.day }} {{ $t("timebank.bank21") }}</div>
              <div class="arrow-bottom"></div>
            </div>
            <ul v-show="expandDays" class="absolute top-10 md:top-14 z-10 w-full bg-[#00000080] md:text-xl py-1 md:py-2">
              <li v-for="item in daysList" :key="item.day" class="px-4 h-8 md:h-12 flex items-center cursor-pointer" @click="selectCycle(item)">
                {{ item.day }} {{ $t("timebank.bank21") }}
              </li>
            </ul>
          </div>
        </div>
        <div class="h-16 md:h-28 flex items-center justify-between px-4 md:px-24 text-sm md:text-2xl bg-300 rounded-b-lg">
          <div>APR @SOUL</div>
          <div class="bg-[#FFB836] rounded px-4 md:px-6 py-1 md:py-2.5">{{ postPledgeData.rate }}%</div>
        </div>
      </div>
      <div
        class="w-40 md:w-72 h-8 md:h-14 btn-bg mt-8 md:mt-14 flex items-center justify-center text-sm md:text-xl xl:text-2xl mx-auto uppercase cursor-pointer"
        v-loading="pledgeBtnLoading"
        @click="toPledge"
      >
        {{ $t("timebank.bank9") }}
      </div>
      <div class="uppercase mt-8 md:mt-14">
        <h2 class="text-base md:text-xl xl:text-3xl font-bold text-center">{{ $t("timebank.bank48") }}</h2>
        <div class="flex items-center justify-between border border-[#f0213b] rounded-full h-8 md:h-16 mt-3 md:mt-10">
          <el-input v-model.number="input_3dnft" class="input_3dnft h-full" :placeholder="$t('timebank.bank49')"> </el-input>
          <div class="bg-F02 w-24 md:w-40 h-full rounded-full flex items-center justify-center text-xs md:text-xl cursor-pointer" @click="search3dnftQuantity">
            {{ $t("timebank.bank50") }}
          </div>
        </div>
      </div>
      <div v-if="_3dnftQuantity">
        <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
          <div>3DNFT TOKEN ID</div>
          <div class="text-xs md:text-2xl break-all max-w-1/2">{{ _3dnftId }}</div>
        </div>
        <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
          <div>{{ $t("timebank.bank51") }}</div>
          <div class="text-xs md:text-2xl break-all max-w-1/2">{{ _3dnftQuantity }}</div>
        </div>
      </div>
      <template v-if="pledgeList.length">
        <div class="flex items-center justify-center mt-4 md:mt-16">
          <img class="w-auto h-20 md:h-40 relative z-10" src="https://static.soulmeta.io/web/img/time-bank/3dnft-symbol.webp" alt="" />
          <div class="text-base md:text-3xl -ml-4">{{ $t("timebank.bank12") }}</div>
        </div>
        <div class="relative mt-2 md:mt-8">
          <img class="w-full h-auto" src="https://static.soulmeta.io/web/img/time-bank/lock-bg.webp" alt="" />
          <div class="w-full md:w-4/5 grid grid-cols-3 gap-2 absolute top-1/2 -translate-x-1/2 left-1/2 -translate-y-1/2 z-10 text-center px-6 md:px-0">
            <div>
              <div class="text-xs md:text-base capitalize">{{ $t("timebank.bank14") }}</div>
              <div class="text-sm md:text-4xl font-bold mt-2 md:mt-10">{{ totalLockAmount }}</div>
              <div class="text-xs md:text-2xl mt-1 md:mt-4">SOUL</div>
            </div>
            <div>
              <div class="text-xs md:text-base capitalize">{{ $t("timebank.bank41") }}</div>
              <div class="text-sm md:text-4xl font-bold mt-2 md:mt-10">{{ totalReciAmount }}</div>
              <div class="text-xs md:text-2xl mt-1 md:mt-4">SOUL</div>
            </div>
            <div>
              <div class="text-xs md:text-base capitalize">{{ $t("timebank.bank22") }}</div>
              <div class="text-sm md:text-4xl font-bold mt-2 md:mt-10">{{ totalAvailableAmount }}</div>
              <div class="text-xs md:text-2xl mt-1 md:mt-4">SOUL</div>
            </div>
          </div>
        </div>
        <div
          class="w-50 md:w-86 h-8 md:h-14 btn-bg mt-7 md:mt-14 flex items-center justify-center text-sm md:text-xl xl:text-2xl mx-auto uppercase cursor-pointer leading-4 text-center"
          v-loading="getAllRewaBtnLoading"
          @click="getAllRewards"
        >
          {{ $t("timebank.bank11") }}
        </div>
        <ul class="w-full flex items-center py-4 md:py-8 mt-4 md:mt-8 overflow-x-scroll custom-scrollbar">
          <li
            class="flex items-center px-3 md:px-6 py-4 md:py-8 mr-4 md:mr-12 cursor-pointer min-w-60 md:min-w-96"
            :class="[actived === index ? 'active-border-bg' : 'border-bg', index === pledgeList.length - 1 ? 'mr-0 md:mr-0' : '']"
            v-for="(item, index) in pledgeList"
            :key="item.id"
            @click="changeTab(index)"
          >
            <img
              v-if="actived === index"
              class="w-14 md:w-28 h-auto mr-3 md:mr-6"
              src="https://static.soulmeta.io/web/img/time-bank/active-tx-logo.webp"
              alt=""
            />
            <img v-else class="w-14 md:w-28 h-auto mr-3 md:mr-6" src="https://static.soulmeta.io/web/img/time-bank/tx-logo.webp" alt="" />

            <div class="mr-6 md:mr-12">
              <div class="text-xs md:text-xl">{{ $t("timebank.bank23") }}</div>
              <div class="text-xs md:text-base">{{ item.depsositTime }}</div>
              <div class="text-xs md:text-xl whitespace-nowrap">{{ $t("timebank.bank24") }}</div>
              <div class="text-xs md:text-base">{{ item.amount }} SOUL</div>
            </div>
          </li>
        </ul>
        <div class="bg-black relative z-10">
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank13") }}</div>
            <div class="text-xs md:text-2xl break-all max-w-1/2">{{ pledgeData.id }}</div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank40") }}</div>
            <div>
              <span class="font-blod">{{ pledgeData.amount }}</span>
              <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
            </div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank15") }}</div>
            <div>
              <span class="font-blod">{{ pledgeData.accRewards }}</span>
              <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
            </div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank16") }}</div>
            <div>
              <span class="font-blod">{{ pledgeData.dailyRewards }}</span>
              <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
            </div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank17") }}</div>
            <div>
              <span class="font-blod">{{ pledgeData.receivedRewardeds }}</span>
              <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
            </div>
          </div>
          <div class="h-14 md:h-24 flex items-center justify-between text-sm md:text-2xl border-b md:border-b-2 border-222">
            <div>{{ $t("timebank.bank18") }}</div>
            <div>
              <span class="font-blod">{{ pledgeData.availableRewardeds }}</span>
              <span class="text-xs md:text-base ml-1 md:ml-2">SOUL</span>
            </div>
          </div>
        </div>
        <div class="relative flex items-center justify-between xl:block mt-8 md:mt-20">
          <div
            class="w-32 md:w-64 h-8 md:h-14 btn-bg xl:mt-20 flex items-center justify-center text-sm md:text-xl xl:text-2xl xl:mx-auto uppercase cursor-pointer text-center leading-4"
            v-loading="getRewaBtnLoading"
            @click="getRewards"
          >
            {{ $t("timebank.bank19") }}
          </div>
          <div class="flex items-center xl:absolute top-0 right-0">
            <div class="text-xm md:text-4xl font-bold">{{ countDown }}</div>
            <div
              class="w-24 md:w-44 h-8 md:h-14 flex items-center justify-center text-sm md:text-xl xl:text-2xl mx-auto uppercase ml-3 md:ml-10 cursor-pointer"
              :class="[allowWithdraw ? 'btn-bg ' : 'gray-btn-bg']"
              v-loading="withdrawBtnLoading"
              @click="withdraw"
            >
              {{ $t("timebank.bank20") }}
            </div>
          </div>
        </div>
      </template>
    </div>
    <div class="relative">
      <div class="soulmeta-bg hidden lg:block w-[100%] absolute left-0 top-72 text-center py-10 text-[#431E15]">{{ $t("timebank.bank26") }}</div>
      <div class="relative">
        <img class="lg:w-200 xl:w-300 w-9/10 mx-auto relative z-10" src="https://static.soulmeta.io/web/img/time-bank/soulmeta.webp" alt="" />
        <img
          class="lg:w-200 xl:w-300 w-9/10 mx-auto h-[480px] md:h-auto -mt-24 md:-mt-60 xl:-mt-88"
          src="https://static.soulmeta.io/web/img/time-bank/soulmeta-border.webp"
          alt=""
        />
        <div class="w-4/5 lg:w-3/5 xl:w-4/5 2xl:w-3/5 absolute top-1/3 md:top-1/2 z-10 left-1/2 -translate-x-1/2 text-center">
          <div class="mt-0 md:mt-10 xl:mt-20">
            <div class="text-xs md:text-2xl">{{ $t("timebank.bank52") }}</div>
            <div class="relative mt-2">
              <img class="h-8 md:h-12 xl:h-20 w-auto mx-auto" src="https://static.soulmeta.io/web/img/time-bank/amount_bg.webp" alt="" />
              <div class="w-full h-full absolute top-0 left-0 flex items-center justify-center">
                <span class="text-base md:text-xl xl:text-4xl 2xl:text-6xl">{{ socialTotalAmount }}</span>
                <span class="text-xs md:text-base ml-2">USDT</span>
              </div>
            </div>
          </div>
          <!-- <div class="flex item-center justify-center mt-1 xl:mt-8">
            <div class="bg-F02 w-6 md:w-10 h-6 md:h-10 text-base md:text-2xl rounded flex items-center justify-center">00</div>
            <div class="w-6 md:w-8 h-6 md:h-10 text-base md:text-2xl rounded flex items-center justify-center">:</div>
            <div class="bg-F02 w-6 md:w-10 h-6 md:h-10 text-base md:text-2xl rounded flex items-center justify-center">00</div>
            <div class="w-6 md:w-8 h-6 md:h-10 text-base md:text-2xl rounded flex items-center justify-center">:</div>
            <div class="bg-F02 w-6 md:w-10 h-6 md:h-10 text-base md:text-2xl rounded flex items-center justify-center">00</div>
          </div> -->
          <div class="text-base md:text-xl xl:text-2xl mt-1 md:mt-4">{{ $t("timebank.bank26") }}</div>
          <div class="text-xs md:text-base xl:text-xl text-left mt-0 md:mt-2 xl:mt-6">
            <p>
              {{ $t("timebank.bank28-1") }}
            </p>
            <p>
              {{ $t("timebank.bank28-2") }}
            </p>
            <p>
              {{ $t("timebank.bank28-3") }}
            </p>
          </div>
        </div>

        <div class="absolute left-1/2 -translate-x-1/2 bottom-0 w-3/5 md:w-1/3" v-if="_3dnftTokenIdList.length">
          <img src="https://static.soulmeta.io/web/img/time-bank/soulmeta_btn.webp" alt="" />
          <div class="flex items-center justify-center absolute top-0 left-0 w-full h-full text-center text-xs md:text-xl xl:texl-2xl">
            <div class="w-1/2 capitalize">
              {{ $t("timebank.bank53") }} <span class="xl:text-3xl ml-1 md:ml-2">{{ socialUserReciAmount }}</span>
            </div>
            <div class="w-1/2 capitalize">
              {{ $t("timebank.bank54") }} <span class="xl:text-3xl ml-1 md:ml-2">{{ socialUserAvaiAmount }}</span>
            </div>
          </div>
        </div>
      </div>
      <div
        class="w-32 md:w-48 xl:w-60 h-8 md:h-12 xl:h-14 mt-4 xl:mt-10 flex items-center justify-center text-sm md:text-xl xl:text-2xl xl:mx-auto uppercase cursor-pointer mx-auto"
        :class="[!all3dnftActivation || socialReceiveStatus ? 'btn-bg ' : 'gray-btn-bg']"
        v-loading="socialReciBtnLoading"
        v-if="_3dnftTokenIdList.length"
        @click="receiveSocialAmount"
      >
        {{ all3dnftActivation ? $t("timebank.bank27") : $t("timebank.bank55") }}
      </div>
    </div>
    <Footer />
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import Footer from "@/components/footer.vue";
import { getEther } from "@/plugins/ethers";
import { inputAmount, sliceDecimals } from "@/plugins/handleAmount";
import { dateFormat } from "@/plugins/formatTime";

export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      totalPledge: 0,
      remainingTotalRewards: 0,
      estimatedTotalIncome: 0,
      lockAmount: "",
      expandDays: false,
      postPledgeData: {},
      daysList: [],
      timer: null,
      countDown: 0,
      allowWithdraw: false,
      soulBalance: 0,
      pledgeList: [],
      pledgeData: {},
      totalLockAmount: 0,
      totalReciAmount: 0,
      totalAvailableAmount: 0,
      actived: 0,
      pledgeBtnLoading: false,
      getRewaBtnLoading: false,
      getAllRewaBtnLoading: false,
      withdrawBtnLoading: false,
      balanceOf3dnft: 0,
      input_3dnft: "",
      _3dnftId: 0,
      _3dnftQuantity: 0,
      all3dnftActivation: false, // 是否都为激活
      socialTotalAmount: 0,
      socialUserReciAmount: 0,
      socialUserAvaiAmount: 0,
      socialReciBtnLoading: false,
      _3dnftTokenIdList: [],
      socialReceiveStatus: false, // 是否可领取
    };
  },
  async created() {
    this.eth = await getEther();
    await this.initData();
    await this.getData();
    await this.getSocialData();
  },
  unmounted() {
    clearInterval(this.timer);
  },
  methods: {
    async initData() {
      this.daysList = [
        {
          day: 90,
          rate: 20,
          value: 1,
        },
        {
          day: 180,
          rate: 40,
          value: 2,
        },
      ];
      this.balanceOf3dnft = await this.eth.c.sm3d.balanceOf(this.eth.myAddr);
      if (this.balanceOf3dnft.gt(0)) {
        this.daysList.push({
          day: 365,
          rate: 60,
          value: 3,
        });
      }
      this.postPledgeData = this.daysList[0];

      let tokenIdList = [];
      for (let i = 0; i < this.balanceOf3dnft; i++) {
        let tokenId = await this.eth.c.sm3d.tokenOfOwnerByIndex(this.eth.myAddr, i);
        tokenIdList.push(tokenId.toNumber());
      }
      this._3dnftTokenIdList = tokenIdList;
    },
    async updata() {
      clearInterval(this.timer);
      await this.getData();
    },
    async getData() {
      let utils = this.eth.utils;

      {
        let sBalance = await this.eth.c.soul.balanceOf(this.eth.myAddr);
        this.soulBalance = sliceDecimals(this.eth.utils.formatEther(sBalance), 6);

        let { totalRate, totalStakeNum } = await this.eth.c.timeBank.timeBankInfo();
        this.totalPledge = sliceDecimals(utils.formatEther(totalStakeNum), 6);
        this.estimatedTotalIncome = sliceDecimals(utils.formatEther(totalRate), 6);

        let soulBankBalance = await this.eth.c.soul.balanceOf(this.eth.c.timeBankRate.address);
        this.remainingTotalRewards = sliceDecimals(utils.formatEther(soulBankBalance.sub(totalRate)), 6);
      }

      {
        let balanceOf721 = await this.eth.c.timeBankNft.balanceOf(this.eth.myAddr);
        if (balanceOf721.eq(0)) return;

        let tempPledgeList = [];
        let totalLockAmount = 0;
        let totalReciAmount = utils.parseEther("0");
        let totalAvailableAmount = utils.parseEther("0");

        for (let i = 0; i < balanceOf721; i++) {
          let tokenId = await this.eth.c.timeBankNft.tokenOfOwnerByIndex(this.eth.myAddr, i);

          let stakeData = await this.eth.c.timeBank.stakeInfo(tokenId);
          let annualized = await this.eth.c.timeBank.annualizedInfo(stakeData.mode);
          let receivedRewardeds = await this.eth.c.timeBank.playerRewarded(tokenId);
          let currDays = this.daysList.find((item) => item.value === stakeData.mode);

          let aviRewardeds = utils
            .parseUnits(String(parseInt(Date.now() / 1000)), 0)
            .sub(stakeData.lastRewardTime)
            .mul(annualized.rate.mul(stakeData.amount.div(utils.parseEther("1.0"))));

          let totalRewards = annualized.period.mul(annualized.rate.mul(stakeData.amount.div(utils.parseEther("1.0"))));
          let accRewards = totalRewards.sub(aviRewardeds).sub(receivedRewardeds);

          let stakeInfo = {
            id: stakeData.tokenId.toNumber(),
            amount: utils.formatEther(stakeData.amount),
            accRewards: sliceDecimals(utils.formatEther(accRewards), 6),
            dailyRewards: sliceDecimals(86400 * utils.formatEther(annualized.rate) * utils.formatEther(stakeData.amount), 6),
            receivedRewardeds: sliceDecimals(utils.formatEther(receivedRewardeds), 6),
            availableRewardeds: sliceDecimals(utils.formatEther(aviRewardeds), 6),
            deadline: stakeData.deadline.toNumber() * 1000,
            depsositTime: dateFormat(stakeData.deadline.toNumber() * 1000 - currDays.day * 24 * 60 * 60 * 1000, "YYYY-MM-dd hh:mm:ss"),
          };

          totalLockAmount += 1 * stakeInfo.amount;
          totalReciAmount = totalReciAmount.add(receivedRewardeds);
          totalAvailableAmount = totalAvailableAmount.add(aviRewardeds);

          tempPledgeList.push(stakeInfo);
        }

        this.totalLockAmount = totalLockAmount;
        this.totalReciAmount = sliceDecimals(utils.formatEther(totalReciAmount), 6);
        this.totalAvailableAmount = sliceDecimals(utils.formatEther(totalAvailableAmount), 6);
        this.pledgeList = tempPledgeList;
        this.pledgeData = this.pledgeList[this.actived];
        this.withdrawCountDown(this.pledgeData.deadline);
      }
    },
    async receiveSocialAmount() {
      if (this.all3dnftActivation && !this.socialReceiveStatus) return;

      this.socialReciBtnLoading = true;
      let _3dnftActivatedList = [];
      let _3dnftInactivatedList = [];

      for (let i = 0; i < this._3dnftTokenIdList.length; i++) {
        let { receiveDay } = await this.eth.c.socialWelfare.userData(this._3dnftTokenIdList[i]);

        if (receiveDay.isZero()) {
          _3dnftInactivatedList.push(this._3dnftTokenIdList[i]);
        } else {
          _3dnftActivatedList.push(this._3dnftTokenIdList[i]);
        }
      }


      if (this.all3dnftActivation) {
        try {
          let res = await this.eth.c.socialWelfare.userReceive(_3dnftActivatedList);
          await res.wait();
          await this.getSocialData();
        } catch (e) {
          this.socialReciBtnLoading = false;
        }
      } else {
        try {
          let res = await this.eth.c.socialWelfare.activation(_3dnftInactivatedList);
          await res.wait();
          await this.getSocialData();
        } catch (e) {
          this.socialReciBtnLoading = false;
        }
      }
      this.socialReciBtnLoading = false;
    },
    async getSocialData() {
      let { todayTotal, canClaim } = await this.eth.c.socialWelfare.welfareData();
      this.socialTotalAmount = sliceDecimals(this.eth.utils.formatEther(todayTotal));

      let userTotalReciAmount = this.eth.BigNumber.from(0);
      let userTotalAvaiAmount = this.eth.BigNumber.from(0);
      let userTotalReceiveDay = this.eth.BigNumber.from(0);
      let socialReceiveStatus = false;
      let _3dnftActivatedList = [];
      let _3dnftInactivatedList = [];

      for (let i = 0; i < this._3dnftTokenIdList.length; i++) {
        let { receiveDay, totalAmount, currentShare } = await this.eth.c.socialWelfare.userData(this._3dnftTokenIdList[i]);

        userTotalReciAmount = userTotalReciAmount.add(totalAmount);

        userTotalReceiveDay = userTotalReceiveDay.add(receiveDay);

        if (parseInt(Date.now() / (24 * 60 * 60 * 1000)) > receiveDay.toNumber()) {
          socialReceiveStatus = true;
        }

        if (receiveDay.isZero()) {
          _3dnftInactivatedList.push(this._3dnftTokenIdList[i]);
        } else {
          userTotalAvaiAmount = userTotalAvaiAmount.add(canClaim.sub(currentShare));
          _3dnftActivatedList.push(this._3dnftTokenIdList[i]);
        }
      }

      this.socialUserReciAmount = sliceDecimals(this.eth.utils.formatEther(userTotalReciAmount));
      this.socialUserAvaiAmount = sliceDecimals(this.eth.utils.formatEther(userTotalAvaiAmount));
      this.socialReceiveStatus = socialReceiveStatus;
      this.all3dnftActivation = !_3dnftInactivatedList.length;
    },
    withdrawCountDown(endTime) {
      const day = 1000 * 60 * 60 * 24;
      const formatTime = (t) => String(parseInt(t)).padStart(2, "0");
      this.timer = setInterval(() => {
        const t = endTime - Date.now();
        if (t <= 0) {
          this.countDown = "00 : 00 : 00";
          clearInterval(this.timer);
          this.allowWithdraw = true;
          return;
        }
        const d = parseInt(t / day);
        const h = formatTime((t % day) / (1000 * 60 * 60));
        const m = formatTime((t % (1000 * 60 * 60)) / (1000 * 60));
        const s = formatTime((t % (1000 * 60)) / 1000);
        this.countDown = d > 0 ? `${d} ${this.$t("common.day")} ` : `${h} : ${m} : ${s}`;
      }, 1000);
    },
    handleLockAmount() {
      if (Number(this.lockAmount) > Number(this.soulBalance)) {
        this.lockAmount = this.soulBalance;
        return;
      }
      this.lockAmount = inputAmount(this.lockAmount, 6);
    },
    selectCycle(data) {
      this.postPledgeData = data;
      this.expandDays = false;
    },
    changeTab(index) {
      this.actived = index;
      this.pledgeData = this.pledgeList[this.actived];
      clearInterval(this.timer);
      this.withdrawCountDown(this.pledgeData.deadline);
    },
    async toPledge() {
      if (+this.lockAmount < 10) {
        this.$message.error(this.$t("timebank.bank42"));
        return;
      }

      let limitNum = this.lockAmount * (this.postPledgeData.day / 365) * (this.postPledgeData.rate / 100);
      if (limitNum > +this.remainingTotalRewards) {
        this.$message.error(this.$t("timebank.bank43"));
        return;
      }

      let limit3dnftNum = 0;
      for (let i = 0; i < this.balanceOf3dnft; i++) {
        let tokenId = await this.eth.c.soul3dnft.tokenOfOwnerByIndex(this.eth.myAddr, i);
        let times = await this.eth.c.timeBank.a3dNftMor(tokenId);
        limit3dnftNum += +this.eth.utils.formatEther(times);
      }

      let remainingNum = this.balanceOf3dnft.toNumber() * 500 - limit3dnftNum;
      if (+this.postPledgeData.value === 3 && +this.lockAmount > remainingNum) {
        this.$message.error(this.$t("timebank.bank44"));
        return;
      }

      this.pledgeBtnLoading = true;

      let soulApprove = await this.eth.c.soul.allowance(this.eth.myAddr, this.eth.c.timeBank.address);
      if (soulApprove.eq(0)) {
        try {
          let approve = await this.eth.c.soul.approve(this.eth.c.timeBank.address, this.eth.constants.MaxUint256);
          await approve.wait();
        } catch (e) {
          this.pledgeBtnLoading = false;
        }
      }
      try {
        let res = await this.eth.c.timeBank.deposit(this.postPledgeData.value, this.eth.utils.parseEther(this.lockAmount));
        await res.wait();
        this.lockAmount = "";
        this.updata();
      } catch (e) {
        this.pledgeBtnLoading = false;
      }
      this.pledgeBtnLoading = false;
    },
    async getRewards() {
      this.getRewaBtnLoading = true;
      try {
        let res = await this.eth.c.timeBankRate.getReward(this.eth.myAddr, this.pledgeData.id);
        await res.wait();
        this.updata();
      } catch (e) {
        this.getRewaBtnLoading = false;
      }
      this.getRewaBtnLoading = false;
    },
    async getAllRewards() {
      this.getAllRewaBtnLoading = true;

      try {
        let ids = this.pledgeList.map((item) => item.id);
        let res = await this.eth.c.timeBankRate.batchGetReward(this.eth.myAddr, ids);
        await res.wait();
        this.updata();
      } catch (e) {
        this.getAllRewaBtnLoading = false;
      }
      this.getAllRewaBtnLoading = false;
    },
    async withdraw() {
      if (!this.allowWithdraw) return;
      this.withdrawBtnLoading = true;
      let nftApproveStatus = await this.eth.c.timeBankNft.isApprovedForAll(this.eth.myAddr, this.eth.c.timeBank.address);
      if (!nftApproveStatus) {
        try {
          let approve = await this.eth.c.timeBankNft.setApprovalForAll(this.eth.c.timeBank.address, true);
          await approve.wait();
        } catch (e) {
          this.withdrawBtnLoading = false;
        }
      }

      try {
        let res = await this.eth.c.timeBank.extract(this.pledgeData.id);
        await res.wait();
        this.actived = 0;
        this.allowWithdraw = false;
        this.updata();
      } catch (e) {
        this.withdrawBtnLoading = false;
      }
      this.withdrawBtnLoading = false;
    },
    async search3dnftQuantity() {
      let quantity = await this.eth.c.timeBank.a3dNftMor(this.input_3dnft);
      this._3dnftId = this.input_3dnft;
      this._3dnftQuantity = this.eth.utils.formatEther(quantity);
    },
  },
};
</script>

<style lang="scss" scoped>
.btn-bg {
  background: url("https://static.soulmeta.io/web/img/time-bank/btn-bg.webp") no-repeat;
  background-size: 100% 100%;
}

.gray-btn-bg {
  background: url("https://static.soulmeta.io/web/img/time-bank/gray-btn-bg.webp") no-repeat;
  background-size: 100% 100%;
}

.lock-amount {
  :deep(.el-input__inner) {
    width: 180px;
    height: 52px;
    font-size: 24px;
    color: #000;
  }
}

:deep(.el-input__wrapper.is-focus) {
  box-shadow: none;
}

.arrow-bottom {
  content: "";
  height: 12px;
  width: 12px;
  border-color: #fff;
  border-style: solid;
  border-width: 2px 2px 0 0;
  transform: rotate(135deg);
}

.active-border-bg {
  background: url("https://static.soulmeta.io/web/img/time-bank/active-border-bg.webp") no-repeat;
  background-size: 100% 100%;
}

.border-bg {
  background: url("https://static.soulmeta.io/web/img/time-bank/border-bg.webp") no-repeat;
  background-size: 100% 100%;
}

.custom-scrollbar {
  &::-webkit-scrollbar {
    width: 0;
    height: 6px;
  }
  &::-webkit-scrollbar-track {
    background-color: #444444;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #fff;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
}

.c-scrollbar {
  &::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  &::-webkit-scrollbar-track {
    background-color: #484848;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #fff;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
}

.soulmeta-bg {
  background: url("https://static.soulmeta.io/web/img/time-bank/soulmeta-bg.webp") no-repeat;
  background-size: 100% 100%;
  font-size: 118px;
}

.el-input {
  --el-input-focus-border-color: transparent;
  --el-input-hover-border-color: transparent;
}

.input_3dnft.el-input {
  --el-input-border-color: transparent;
  --el-input-bg-color: transparent;
  :deep(.el-input__inner) {
    height: 100%;
    font-size: 22px;
    padding-left: 2rem;
  }
}

@media (max-width: 1600px) {
  .soulmeta-bg {
    font-size: 102px;
  }
}

@media (max-width: 1420px) {
  .soulmeta-bg {
    font-size: 80px;
  }
}

@media (max-width: 768px) {
  .arrow-bottom {
    height: 8px;
    width: 8px;
  }

  .lock-amount {
    :deep(.el-input__inner) {
      width: 90px;
      height: 32px;
      font-size: 14px;
      color: #000;
    }
  }
  .input_3dnft.el-input {
    :deep(.el-input__inner) {
      font-size: 12px;
      padding-left: 0.4rem;
    }
  }
}
</style>

<template>
  <div v-loading="loading" class="bg min-h-full pb-20">
    <Header class="hidden md:block" />

    <div class="lg:w-200 xl:w-300 w-9/10 mx-auto relative">
      <div class="py-5 flex md:hidden justify-between items-center">
        <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.replace('/')" />
        <div class="w-full pr-7 flex justify-center">
          <div class="w-full flex items-center justify-center">
            <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            <div class="font-semibold">SOULMETA</div>
          </div>
        </div>
      </div>
      <div class="w-full mx-auto lg:flex items-center md:mt-20">
        <div class="w-full lg:w-1/2 xl:pr-10">
          <div class="img-bg p-4 md:p-8 rounded-2xl flex flex-col items-center justify-center relative w-full lg:w-full mx-auto" :class="type === 1 ? '' : ''">
            <div v-if="type === 2" class="mb-2 md:mb-4 text-2xl font-semibold">
              {{ $t("succ.succ1") }}
            </div>
            <img v-if="userInfo.img" class="w-full rounded-2xl h-auto md:max-h-3/4" :src="userInfo.img" alt="" />
            <img v-else class="rounded-2xl md:max-h-full" src="https://static.soulmeta.io/web/img/caste/no_img.webp" alt="" />
            <div v-if="!userInfo.contInfo" class="w-full absolute">
              <div class="w-52 p-4 ml-auto">
                <div class="whitespace-pre-wrap">{{ $t("succ.succ2") }}</div>
                <div class="text-xs">{{ $t("succ.succ3") }}</div>
              </div>
            </div>
            <img class="w-12 md:w-16 absolute -bottom-3 -right-2" src="https://static.soulmeta.io/web/img/caste/logo.png" alt="" />
          </div>
        </div>
        <div class="md:mt-20 lg:mt-0 lg:w-1/2 lg:pl-10">
          <div v-if="userInfo.contInfo" class="w-9/10 mx-auto px-10 overflow-x-auto py-3 mt-5 text-sm md:text-2xl copy-bor text-center relative rounded-full">
            {{ userInfo.contInfo }}
            <img
              v-if="type === 1"
              class="w-5 md:w-7 absolute right-2 top-1/2 transform -translate-y-1/2 cursor-pointer"
              src="https://static.soulmeta.io/web/img/acc/copy.webp"
              alt=""
              @click="doCopy"
            />
            <div class="absolute left-2 top-1/2 transform -translate-y-1/2">
              <img class="w-7 md:w-10" :src="'https://static.soulmeta.io/web/img/caste/link' + userInfo.linkType + '.webp'" alt="" />
            </div>
          </div>

          <div v-if="type === 2" class="mt-10 text-3xl md:text-6xl text-center flex justify-center">
            ×
            <div class="mx-2 maxfont-semibold text-F02">
              {{ casteNum }}
            </div>
            <div class="">NFT</div>
          </div>

          <div class="mt-10 text-sm md:text-xl">
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            {{ type === 1 ? (gender === 2 ? $t("succ.succ4") : $t("succ.succ5")) : $t("succ.succ8") }}
          </div>

          <div v-if="type === 1" class="mt-10 xl:mt-20 flex justify-around items-center">
            <div
              class="w-2/5 text-center text-sm md:text-base xl:text-xl font-semibold rounded-lg leading-8 bg-E72 md:py-2 xl:py-4 cursor-pointer"
              @click="buy"
            >
              {{ $t("succ.succ6") }}
            </div>
            <div
              class="w-2/5 text-center text-sm md:text-base xl:text-xl font-semibold rounded-lg leading-8 bg-E72 md:py-2 xl:py-4 cursor-pointer"
              @click="$router.replace('/account')"
            >
              {{ $t("succ.succ7") }}
            </div>
            <!-- <img class="w-24 mt-10 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/btn_img.webp" alt="" @click="$router.replace('/account')"> -->
          </div>
          <div v-else class="mt-10 flex justify-around items-center">
            <div class="w-full text-center text-xl font-semibold rounded-lg leading-10 bg-E72 md:py-2 cursor-pointer" @click="$router.replace('/account')">
              {{ $t("succ.succ7") }}
            </div>
            <!-- <img class="w-32" src="https://static.soulmeta.io/web/img/succ/acc_img.webp" alt="" @click="$router.replace('/account')"> -->
          </div>
        </div>
      </div>
    </div>
    <Footer class="hidden sm:block" />
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import Footer from "@/components/footer.vue";
import { getEther } from "@/plugins/ethers";
export default {
  name: "success-page",
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      loading: false,
      type: 1,
      userInfo: {
        type: 0,
        img: "",
        contInfo: "",
        soulNum: 0,
        linkType: 0,
        casteNum: 0,
      },
      gender: 2,
      casteNum: 0,
      tokenId: 0,
    };
  },
  methods: {
    doCopy() {
      this.$copyText(this.userInfo.contInfo).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },
    async openSucc(tokenId) {
      window.localStorage.setItem("soulBox", tokenId);
      this.tokenId = tokenId;
      try {
        this.signMessage = await this.eth.signer.signMessage("Sign to your Meta Soul, Token ID: " + String(tokenId) + ".");
        this.$store.commit("setSignMessage", this.signMessage);
        this.loading = true;
        this.getUserInfo();
      } catch (error) {}
      this.$store.commit("setWaitCastingPage", false);
    },

    listenEvent(events) {
      events.forEach((ele) => {
        if (ele.event && ele.event === "Extract") {
          this.openSucc(parseInt(ele.topics[3]));
        }
      });
    },

    async buy() {
      // let boxSums = await this.eth.c.caste.totalBlindBox();
      // if (!parseInt(boxSums)) {
      //   this.$message.error(this.$t("msg.msg1"));
      //   return;
      // }

      if (this.invitor === this.eth.myAddr) {
        this.$message.error(this.$t("msg.msg2"));
        return;
      }

      let rewards = await this.eth.c.controller.referWallet(this.eth.myAddr);
      let referralRewards = parseInt(this.eth.utils.formatEther(rewards));

      let balance = await this.eth.c.usdt.balanceOf(this.eth.myAddr);
      if (parseInt(this.eth.utils.formatEther(balance)) < 4 && referralRewards < 4) {
        this.$message.error(this.$t("msg.msg3"));
        return;
      }

      let allowance = await this.eth.c.usdt.allowance(this.eth.myAddr, this.eth.c.controller.address);
      if (allowance.eq(0)) {
        let approve = await this.eth.c.usdt.approve(this.eth.c.controller.address, this.eth.constants.MaxUint256);
        await approve.wait();
      }

      try {
        this.$store.commit("setWaitCastingPage", true);

        let res = await this.eth.c.router.drawBox(this.eth.myAddr, 1, this.gender, 1, this.invitor ? this.invitor : this.eth.constants.AddressZero, {
          gasLimit: 800000,
        });
        res = await res.wait();

        await this.listenEvent(res.events);
      } catch (error) {
        console.log(error);
        this.loading = false;
        this.$store.commit("setWaitCastingPage", false);
      }
    },

    async getUserInfo() {
      this.loading = true;
      let timer = null;

      let data = {
        token_id: this.tokenId,
        address: this.eth.myAddr,
        signature: this.$store.state.signMessage,
      };
      let res = await this.$axios.post("/api/soul/get_nft", JSON.stringify(data));
      if (res.status === 200 && res.data.resultCode === 0) {
        this.userInfo = this.$store.state.casteInfo;
        this.userInfo.img = res.data.data.img_url;
        this.userInfo.contInfo = res.data.data.information;
        this.userInfo.linkType = res.data.data.contact_type;
      } else if (res.data.resultCode === -2) {
        this.userInfo.img = "";
        this.userInfo.contInfo = "";
      }

      timer = setTimeout(() => {
        this.loading = false;
        clearTimeout(timer);
      }, 2000);
    },
  },
  async created() {
    this.eth = await getEther();
    this.type = Number(this.$route.query.type);
    this.gender = this.$route.query.gender;
    this.casteNum = Number(this.$route.query.casteNum);

    if (this.type === 2 && this.$store.state.casteInfo.img) {
      this.userInfo = this.$store.state.casteInfo;
    } else if (this.type === 1 && this.$store.state.signMessage) {
      this.tokenId = Number(this.$route.query.tokenId);
      this.getUserInfo();
    } else {
      this.$router.push("/");
    }
  },
};
</script>

<style lang="scss" scoped>
.bg {
  background: #000;
}
.img-bg {
  background: linear-gradient(to right bottom, #4f3990, #d83b55);
}
.copy-bor {
  background-image: linear-gradient(to right, #a981f0, #fb8696);
}
</style>

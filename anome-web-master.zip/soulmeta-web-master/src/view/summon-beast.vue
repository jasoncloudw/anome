<template>
  <div class="bg-black min-h-full">
    <div class="w-full">
      <img  class="w-full" src="https://static.soulmeta.io/web/img/summonbeast/wbeast_back.webp" alt="" srcset="" />
      <div class="w-full selectimg  overflow-hidden">
        <div class="w-full max-w-[1200px] mx-auto scrollstr">
          <div class="overflow-x-auto flex scrollstr">
            <div
              class="flex-none lg:py-5 lg:px-8 sm:py-3 sm:px-5 px-4 py-2 lg:mx-10 mx-2 sm:mx-4 first:ml-0 last:mr-0"
              :class="index == selectindex?'selectbg':''"
              v-for="(item, index) in pledgelist"
              @click="selectindex=index"
              :key="index"
            ><img class="lg:w-16 sm:w-12 w-10" :src="'https://static.soulmeta.io/web/img/summonbeast/wbeast-constellationname'+item.id+'.webp'" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="backimg w-full">
      <div class="max-w-[1200px] mx-auto overflow-hidden px-4">        
        <div class="w-1/2 h-full float-left relative">
          <div class="inline-block absolute lg:top-32 sm:top-24 top-16">
            <span class="lg:text-5xl sm:text-3xl text-xl font-bold text-white tracking-[.1em]">{{pledgelist[selectindex].name}}</span>
            <img class="w-1/2 lg:mt-4 sm:mt-2 mt-1 h-2" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-line.webp" alt="">  
          </div>
          <img class="w-3/5 lg:ml-20 lg:mt-20 sm:ml-12 sm:mt-12 ml-6 mt-6"  :src="'https://static.soulmeta.io/web/img/summonbeast/wbeast-constellationlogo'+selectindex+'.webp'" alt="">
          <div class="w-full lg:pt-32 sm:pt-28 pt-16">
            <p class="font-bold tracking-[.1em] mb-4 lg:text-xl sm:text-lg text-sm">{{$t("summon.msg1")}}</p>
            <div class="lg:w-48 sm:w-32 w-5/12 float-left text-center lg:leading-lh-3.5  sm:leading-lh-3  leading-9 lg:text-2xl sm:text-xl text-sm font-bold rounded-lg cursor-pointer" :class="selecrleft==0?'sele':'nosele'" @click="selecrleft=0">LP</div>
            <div class="w-1/12 block sm:hidden float-left h-1"></div>
            <div class="lg:w-48 sm:w-32 w-5/12 float-left text-center lg:leading-lh-3.5  sm:leading-lh-3  leading-9 lg:text-2xl sm:text-xl text-sm font-bold rounded-lg cursor-pointer sm:ml-4 lg:ml-8" :class="selecrleft==1?'sele':'nosele'" @click="selecrleft=1">NFT</div>
          </div>
        </div>
        <div class="w-1/2 float-left">
          <img class="lg:w-124 sm:w-96 w-4/5 lg:pt-28 sm:pt-16 pt-8 float-right" :src="'https://static.soulmeta.io/web/img/summonbeast/wbeast-constellationbanner'+selectindex+'.webp'" alt="">
        </div>
      </div>
      <div class="max-w-[1200px] mx-auto">
          <div class="relative lg:h-12 h-10 w-40 mx-auto lg:my-10 sm:my-6 my-4">
              <h5 class="text-center lg:text-2xl text-xl font-bold">{{$t("summon.msg2")}}</h5>
              <img class="lg:w-20 w-16 absolute lg:left-10 left-12 bottom-0" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-line.webp" alt="">
          </div>
          <div class="sm:w-1/2 w-4/5 mx-auto sm:h-12 h-10 relative" v-show="selecrleft==0">
            <img class="w-6 absolute sm:top-3 top-2 left-4" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-inputimg.webp" alt="">
            <input type="text" class="w-full sm:h-12 h-10 pl-12  outline-none text-white rounded-full text-lg" style="background-color: #272727">
          </div>
          <div v-show="selecrleft==1" class="lg:p-12 sm:p-8 p-4 pt-0 rounded-lg" style="background:rgba(0,0,0,0.3);">
            <div class="h-12 mb-4 pt-4 w-full">
              <img class="h-8 float-right" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-checkall.webp" alt="">
              <img class="h-8 float-right" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-loop.webp" alt="">
            </div>
            <div class="overflow-auto rounded-lg lg:max-h-128 max-h-108 scrollstrh w-full">
              <div class="lg:w-1/5 sm:w-1/4 w-1/3 pb-4 pr-4 float-left relative" v-for="item in pledgelist" :key='item.id' @click="item.select=!item.select">
              <img v-show="!item.select" class="lg:w-8 sm:w-6 w-6 absolute lg:top-4 lg:right-8 sm:top-4 sm:right-8 top-2 right-6" src="https://static.soulmeta.io/web/img/summonbeast/webast-noselected.webp" alt="">
              <img v-show="item.select"  class="lg:w-8 sm:w-6 w-6 absolute lg:top-4 lg:right-8 sm:top-4 sm:right-8 top-2 right-6" src="https://static.soulmeta.io/web/img/summonbeast/webast-selected.webp" alt="">
                <img :src="'https://static.soulmeta.io/web/img/summonbeast/wbeast-constellationbanner'+item.id+'.webp'" alt="">
              </div>
            </div>
          </div>
           <div class="sm:w-1/2 w-4/5 sm:pt-10 pt-6 mx-auto overflow-hidden">      
           <div class="w-1/2 float-left  pr-2"> 
              <div class="w-full float-left text-center lg:leading-lh-3.5  sm:leading-lh-3  leading-9 lg:text-2xl sm:text-xl text-sm font-bold rounded-lg cursor-pointer sele">{{$t("summon.msg2")}}</div>
              </div>   
           <div class="w-1/2 float-left  pl-2"> 
              <div class="w-full float-left text-center lg:leading-lh-3.5  sm:leading-lh-3  leading-9 lg:text-2xl sm:text-xl text-sm font-bold rounded-lg cursor-pointer nosele">{{$t("summon.msg3")}}</div>
              </div>               
            </div>  
            <div class="p-4 lg:mt-10">
              <div class="databack  relative py-4 sm:py-6 lg:py-10 mt-5 overflow-hidden">
                <div class="w-1/2 float-left">
                    <span class="lg:text-4xl sm:text-2xl text-lg font-bold text-center block">0</span>
                    <img class="mx-auto sm:h-4 h-3" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-circle1.webp" alt="">
                    <h6 class="lg:text-xl text-sm sm:font-bold text-center block sm:tracking-[.1em] font-mono">{{$t("summon.msg7")}}</h6>
                </div>
                <div class="w-1/2 float-left">
                    <span class="lg:text-4xl sm:text-2xl text-lg font-bold text-center block">0</span>
                    <img class="mx-auto sm:h-4 h-3" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-circle2.webp" alt="">
                    <h6 class="lg:text-xl text-sm sm:font-bold text-center block sm:tracking-[.1em] font-mono">{{$t("summon.msg8")}}</h6>
                </div>
                <img class="w-1 absolute left-1/2 top-1/2 " style="transform: translate(0, -50%);" src="https://static.soulmeta.io/web/img/summonbeast/webast-databackline.webp" alt="">
              </div>
              <div class="databack  relative py-4 sm:py-6 lg:py-10 mt-5 overflow-hidden">
                <div class="w-1/2 float-left">
                    <span class="lg:text-4xl sm:text-2xl text-lg font-bold text-center block">0</span>
                    <img class="mx-auto sm:h-4 h-3" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-circle3.webp" alt="">
                    <h6 class="lg:text-xl text-sm sm:font-bold text-center block sm:tracking-[.1em] font-mono">{{$t("summon.msg5")}}</h6>
                </div>
                <div class="w-1/2 float-left">
                    <span class="lg:text-4xl sm:text-2xl text-lg font-bold text-center block">0</span>
                    <img class="mx-auto sm:h-4 h-3" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-circle4.webp" alt="">
                    <h6 class="lg:text-xl text-sm sm:font-bold text-center block sm:tracking-[.1em] font-mono">{{$t("summon.msg6")}}</h6>
                </div>
                <img class="w-1 absolute left-1/2 top-1/2 " style="transform: translate(0, -50%);" src="https://static.soulmeta.io/web/img/summonbeast/webast-databackline.webp" alt="">
              </div>
              
           <div class="sm:w-1/2 w-4/5 sm:pt-10 pt-6 mx-auto overflow-hidden">      
           <div class="w-1/2 mx-auto"> 
              <div class="w-full float-left text-center lg:leading-lh-3.5  sm:leading-lh-3  leading-9 lg:text-2xl sm:text-xl text-sm font-bold rounded-lg cursor-pointer sele">{{$t("summon.msg4")}}</div>
              </div>                 
            </div> 
              <div class="w-full lg:pb-40 sm:pb-20 pb-10 mt-10">
                <div class="relative lg:h-12 h-10 w-40 mx-auto lg:my-10 sm:my-6 my-4">
                    <h5 class="text-center lg:text-2xl text-xl font-bold">{{$t("summon.msg9")}}</h5>
                    <img class="lg:w-20 w-16 absolute lg:left-10 left-12 bottom-0" src="https://static.soulmeta.io/web/img/summonbeast/wbeast-line.webp" alt="">
                </div>
                <div class="bg-black lg:p-20 sm:p-8 p-6 w-full lg:mt-10 sm:mt-8 mt-6 rounded-lg">
                    <div class="overflow-y-auto max-h-64 scrollstrred">
                        <p class="w-full lg:leading-8 leading-7 lg:text-xl text-sm">{{$t("summon.msg10")}}</p>
                        <p class="w-full lg:leading-8 leading-7 lg:text-xl text-sm">{{$t("summon.msg11")}}</p>
                        <p class="w-full lg:leading-8 leading-7 lg:text-xl text-sm">{{$t("summon.msg12")}}</p>
                        <p class="w-full lg:leading-8 leading-7 lg:text-xl text-sm">{{$t("summon.msg13")}}</p>
                  </div>
                </div>
              </div>
            </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss"></style>

<script>
export default {
  data() {
    return {
      selectindex:0,
      selecrleft:0,
      pledgelist:[
        {id:0,select:false,name:this.$t("summon.constellation1")},
        {id:1,select:false,name:this.$t("summon.constellation2")},
        {id:2,select:false,name:this.$t("summon.constellation3")},
        {id:3,select:false,name:this.$t("summon.constellation4")},
        {id:4,select:false,name:this.$t("summon.constellation5")},
        {id:5,select:false,name:this.$t("summon.constellation6")},
        {id:6,select:false,name:this.$t("summon.constellation7")},
        {id:7,select:false,name:this.$t("summon.constellation8")},
        {id:8,select:false,name:this.$t("summon.constellation9")},
        {id:9,select:false,name:this.$t("summon.constellation10")},
        {id:10,select:false,name:this.$t("summon.constellation11")},
        {id:11,select:false,name:this.$t("summon.constellation12")},
      ]
    };
  },
};
</script>
<style scoped>
.backimg {
  background: url("https://static.soulmeta.io/web/img/summonbeast/wbeast-back2.webp") no-repeat center/100% 100%;
}
.selectimg {
  background: url("https://static.soulmeta.io/web/img/summonbeast/wbeast-select.webp") no-repeat center/100% 100%;
}
.databack{
  background: url("https://static.soulmeta.io/web/img/summonbeast/webast-databack.webp") no-repeat center/100% 100%;
}
.scrollstr::-webkit-scrollbar {
  height: 4px;
}
.scrollstrh::-webkit-scrollbar,.scrollstrred::-webkit-scrollbar {
  width: 4px;
}
.scrollstr::-webkit-scrollbar-thumb{
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 5px rgba(255, 255, 255, 1);
  background: #ffffff;
}
.scrollstrred::-webkit-scrollbar-thumb{
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 5px rgba(225, 48, 57, 1);
  background: #e02d5a;
}
.scrollstr::-webkit-scrollbar-trackm,.scrollstr::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 1);
  background: #000000;
}
.scrollstrh::-webkit-scrollbar-thumb {
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 5px rgba(255, 255, 255, 1);
  background: #acacac;
}
.scrollstrh::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 1);
  background: #000000;
}
.selectbg{
  background: linear-gradient(to bottom, #f0213b, #e8136c);
}
.nosele{
  border: 1px solid #ffffff;
  border-radius: 10px;
}
.sele{
  background: linear-gradient(to bottom, #f0213b, #e8136c);
  border-radius: 10px;
  padding: 1px;
}
</style>

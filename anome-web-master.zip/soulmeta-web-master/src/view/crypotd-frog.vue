<template>
  <div class="game-plaza bg-black min-h-full">
    <div class="w-full lg:w-200 xl:w-300 mx-auto pb-10">
      <div class="flex items-center">
        <img
          class="w-3 absolute left-[5%] block lg:hidden z-10"
          src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
          alt=""
          @click="$router.back()"
        />
        <Header class="block" />
      </div>
      <div class="w-2/3 lg:w-160 mx-auto lg:my-20 my-8">
        <div class="w-full bg-scroll back-img">
          <img
            class="w-full lg:p-12 md:p-8 sm:p-6 p-p25"
            src="https://static.soulmeta.io/web/img/home/maskgroup.webp"
            alt=""
          />
        </div>
      </div>
      <div class="md:max-w-lg max-w-xs mx-auto flex items-center md:my-10 my-4 justify-center">
        <div>
          <img
            class="w-10 h-10 md:h-20 md:w-20 cursor-pointer"
            src="https://static.soulmeta.io/web/img/home/cryptorenext.webp"
            alt="ChitChat Logo"
          />
        </div>
        <div class="md:px-8 px-4 m-0 grow">
          <p class="text-center text-F02 text-xl md:text-3xl font-extrabold">
            CryptoD.frog
          </p>
        </div>
        <div>
          <img
            class="w-10 h-10 md:h-20 md:w-20 cursor-pointer"
            src="https://static.soulmeta.io/web/img/home/groupprevious.webp"
            alt="ChitChat Logo"
          />
        </div>
      </div>
      <div class="cryptoreinfo mdh-16 h-10 md:my-20 w-4/5 md:w-10/12 mx-auto my-10" >
        <div class="w-3/6 text-center float-left">
          <span
            class="inline-block text-center md:text-lg text-sm font-medium relative md:top-8 top-4 md:pl-9 pl-4"
            >{{$t("guide.price")}}：0.05ETH<img
              class="absolute md:-top-1 -top-0.5 md:-left-2 -left-1 md:w-5 w-3"
              src="https://static.soulmeta.io/web/img/home/cryptoreeth.webp"
              alt=""
          /></span>
        </div>
        <div class="w-3/6 text-center float-left">
          <span
            class="inline-block text-center md:text-lg text-sm font-medium relative md:top-8 top-4 md:pl-9 pl-4"
            >{{$t("guide.qty")}}：100<img
              class="absolute md:-top-1 top-0.5 md:-left-3 -left-1.5 md:w-9 w-4"
              src="https://static.soulmeta.io/web/img/home/cryptoreico.webp"
              alt=""
          /></span>
        </div>
      </div>
      <div class="md:w-96 w-1/2 mx-auto relative">
        <img
          class="md:w-24 w-12 md:h-24 h-12 absolute md:-top-2 -top-1 md:-left-8 -left-4 cursor-pointer"
          src="https://static.soulmeta.io/web/img/home/cryptoreduce.webp"
          @click="add(-100)"
          alt=""
        />
        <input type="text"  class="text-center block addback md:h-20 h-10 md:leading-lh-5 leading-10 md:text-4xl font-medium outline-none w-full" maxlength="10" v-model.number="num">
        <img
          class="md:w-24 w-12 md:h-24 h-12 absolute md:-top-2 -top-1 md:-right-8 -right-4 cursor-pointer"
          src="https://static.soulmeta.io/web/img/home/cryptoreadd.webp"
          @click="add(100)"
          alt=""
        />
      </div>
      <div class="md:mt-20 mt-10">        
        <span class="mx-auto md:w-64 md:leading-lh-4 cursor-not-allowed w-40 md:h-16 h-10 block bg-[#a7a7a7] rounded-lg md:text-3xl text-xl leading-10 text-center"  @click="$store.commit('setSoon', true)">{{$t("guide.mint")}}</span>
      </div>
    </div>

    <Footer />
  </div>
</template>

<style scoped lang="scss"></style>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
export default {
  components: { Header, Footer },

  data() {
    return {
      num:100,
      timeout:null
    };
  },
  methods:{
    add(e){
      if(e == '-100' &&this.num<101) {
        return
      }
      this.num+=e
    },
    handleChangeName (value) {
      if (value === '') {
        return false;
      }
      console.log(1)
      this.num=Math.round(value/100)*100
    }
  },
  watch: {
  'num': {    
    handler(e,f) {
      if(e<0){
        e=-e
      }
       clearTimeout(this.timeout)
        this.timeout = setTimeout(() => {
        this.handleChangeName(e)
      }, 1000)
    }
  }
  },
};
</script>
<style scoped>
.back-img {
  background: url(" https://static.soulmeta.io/web/img/home/group.webp") no-repeat center/100% 100%;
}
.cryptoreinfo {
  background: url("https://static.soulmeta.io/web/img/home/cryptoreinfo.webp") no-repeat center/100% 100%;
}
.addback {
  background: url("https://static.soulmeta.io/web/img/home/groupback.webp") no-repeat center/100% 100%;
}
.d1 {
  display: flex;
  align-items: center;
  text-align: center;
}
</style>

<template>
	<div class="game-plaza bg-black min-h-full">
		<div class="w-full lg:w-200 xl:w-300 mx-auto pb-10">
			<div class="flex items-center">
				<img
					class="w-3 absolute left-[5%] block lg:hidden z-10"
					src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
					alt=""
					@click="$router.back()"
				/>
				<Header class="block" />
			</div>
		</div>
		<div>
			<div class=" w-[290px] h-[85px] xl:w-[1110px] xl:h-[232px] mx-auto bg-[url('https://static.soulmeta.io/web/img/chaebol/chaebolHeader.webp')] lg:mb-10 mb-5" style="background-size:100% 100%"></div>
            <div class="w-full h-[240px] md:h-[400px] xl:h-[520px] 2xl:h-[690px] bg-[url('https://static.soulmeta.io/web/img/chaebol/gudongwa.webp')]" style="background-size:100% 100%"></div>
		</div>
        <div class="w-full bg-[url(https://static.soulmeta.io/web/img/chaebol/ReceivingRulesBg.webp)] " style="background-size:100% 100%">
            <div class="w-[320px]  xl:w-[1210px]  mx-auto  flex flex-col items-center">
            <h3 v-if="false"><b class="text-xl md:text-3xl">Shareholder Pool Income</b></h3>
            <p v-if="false" class="text-2xl md:text-3xl lg:text-4xl w-auto text-[#F0213B]" style="font-family:PingFang SC-Regular">{{ShareholderPoolIncome}}<span class="text-xs md:text-base tetx-white">USDT</span></p>
            <div class="lg:w-280 md:w-180 w-screen md:px-0 px-3 flex justify-around flex-wrap  items-center mt-2 md:mt-8 lg:mt-20">
                <div class="w-full  py-10 md:py-16">
                    <p class="text-base lg:text-4xl font-bold  pb-2 md:pb-5 text-center"><span>{{$t('chaebol.RulesTitle')}}</span></p>
                    <p class="text-xs md:text-base lg:text-base">{{$t('chaebol.rules1')}}</p>
                    <p class="text-xs md:text-base lg:text-base">{{$t('chaebol.rules2')}}</p>
                    <p class="text-xs md:text-base lg:text-base">{{$t('chaebol.rules3')}}</p>
                    <p class="text-xs md:text-base lg:text-base">{{$t('chaebol.rules4')}}</p>
                    <p class="text-xs md:text-base lg:text-base">{{$t('chaebol.rules5')}}</p>
                </div>
                <div class="w-full ">
                    <img src="https://static.soulmeta.io/web/img/chaebol/ReceivingRules.webp" alt="" class="w-full h-full">
                </div>
            </div>
            <div class="lg:w-280 md:w-180 w-screen md:px-0 px-3 flex justify-around items-center mt-2 md:mt-8 lg:mt-20" >
                 <div class="w-[180px] md:w-[400px] lg:w-[600px] h-[200px] lg:h-[400px] overflow-auto flex justify-around flex-wrap items-center wawa" v-if="NFTgrounpId1.length>0">
                    <img :src="img[index]" alt="" class="w-[70px] h-[70px] md:w-[120px] md:h-[120px] lg:w-[210px] lg:h-[200px] mb-2 rounded-xl lg:mb-5 md:rounded-2xl lg:rounded-3xl" :class="selete_NFT[index+1] ? 'border-4 border-solid border-blue-400' : ''" v-for="(i,index) in NFTgrounpId1" :key="i" @click="selectNFT(index+1)" >
                    <div  class="w-[80px] lg:w-[210px] lg:h-[200px]  overflow-hidden" v-if="NFTgrounpId1.length % 2 !== 0"></div>
                </div>
                 <div class="w-[180px] md:w-[400px] lg:w-[600px] h-[200px] lg:h-[400px]  flex items-center justify-center  wawa" v-else>
                     <span class="text-base md:text-xl lg:text-2xl font-bold">{{$t('chaebol.msg1')}}</span>
                 </div>
                <div class="w-[190px] lg:w-[350px] sm:ml-2  py-16">
                    <p class="text-base md:text-xl lg:text-2xl font-bold flex justify-start items-center ReceivingRules pb-2 md:pb-5">{{$t('chaebol.CryptoD')}}</p>
                    <div class="w-full ">
                        <button class="mr-5 w-[74px] h-[26px] md:w-[83px] md:h-[30px] lg:w-[116px] lg:h-[34px] lg:mr-10 border-none text-xs md:text-sm lg:text-base px-2 py-1 lg:px-5 lg:py-1 rounded cursor-pointer" :class="NFTgrounpId1.length>0  ? 'bg-[#F0213B] ' : 'bg-[#9ca3af]'" :disabled="NFTgrounpId1.length>0 ? false : true"  @click="pledegFrog">
                            <el-icon  v-if="PLEDEG_loading" class="is-loading  w-4  h-4" >
								<Loading />
							</el-icon>
                            <span v-else>{{$t('chaebol.PLEDEG')}}</span>
                        </button>
                        <button class="w-[74px] h-[26px] md:w-[83px] md:h-[30px] lg:w-[116px] lg:h-[34px] border border-solid border-[#F0213B] text-xs md:text-sm lg:text-base px-2 py-1 lg:px-5 lg:py-1 text-[#F0213B] rounded cursor-pointer"  @click="extractFrog">
                             <el-icon  v-if="EXTRACT_loading" class="is-loading  w-4  h-4" >
								<Loading />
							</el-icon>
                            <span v-else>{{$t('chaebol.EXTRACT')}}</span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="lg:w-240 md:w-144 w-screen flex justify-around items-center md:px-0 px-3 pt-2 md:pt-8 lg:pt-20 relative">
                <div class="w-full sm:ml-2 md:pb-16 pb-10 md:flex md:justify-between justify-center">
                    <div class="text-sm lg:text-2xl font-bold flex justify-between items-center">{{$t('chaebol.Available')}}：<span class="text-[#F0213B] px-1">{{userInfo.Available}}<span class="text-xs md:text-sm tetx-white">USDT</span></span></div>
                    <div class="text-sm lg:text-2xl font-bold flex justify-between items-center py-8">{{$t('chaebol.Accumulated')}}：<span class="text-[#F0213B] px-1">{{userInfo.cumulative}}<span class="text-xs md:text-sm tetx-white">USDT</span></span></div>
                </div>
                <button class=" border-none text-xs md:text-sm lg:text-base px-2 py-1 lg:px-5 lg:py-1  rounded cursor-pointer absolute bottom-0" :class="Number(userInfo.Available) > 0 ? 'bg-[#F0213B] ' : 'bg-[#9ca3af]'" :disabled="Number(userInfo.Available) > 0 ? false : true" @click="getUserBonu('dividend')">{{$t('chaebol.RECEIVE')}}</button>
            </div>
            <img src="https://static.soulmeta.io/web/img/chaebol/Line1.webp" alt="" class="w-full mt-6" >
            <div v-for="(value,key) in TeamPools" :key="value">
                <div class="md:w-full w-screen flex justify-around items-center  md:px-0 px-3 pt-8 pb-14 md:pb-16 lg:pt-20 relative mt-10" v-if="value.show">
                <div  class="text-base lg:tetx-4xl  absolute top-0 lg:top-16 flex flex-col items-center">
                    <h1 class=" lg:mb-2">{{value.text}}</h1>
                    <img src="https://static.soulmeta.io/web/img/chaebol/Line2.webp" alt="" class="w-10 lg:w-[80px]">
                </div>
                <div class="w-1/2 md:w-[400px]  lg:w-[600px] h-[135px] md:h-[230px] lg:h-[400px] flex justify-center items-center relative">
                    <img src="https://static.soulmeta.io/web/img/chaebol/received.webp" alt="" class="w-[180px] h-[120px] md:w-full md:h-full lg:w-[450px] lg:h-[300px] my-[5px] " >
                    <div class="absolute bottom-0 md:bottom-8 lg:bottom-16 text-center">
                        <p class="text-xs md:text-base lg:text-xl">{{$t('chaebol.Accumulated')}}</p>
                        <p class="text-xl md:text-2xl lg:text-4xl pt-3">{{value.cumulative}}</p>
                    </div>
                </div>
                    <img src="https://static.soulmeta.io/web/img/chaebol/Line3.webp" alt="" class="h-[80px] lg:h-[150px]">
                <div class="w-1/2 md:w-[400px]  lg:w-[600px] h-[135px] md:h-[230px] lg:h-[400px] flex justify-center items-center relative">
                    <img src="https://static.soulmeta.io/web/img/chaebol/Can Receive.webp" alt="" class="w-[180px] h-[120px] md:w-full md:h-full lg:w-[450px] lg:h-[300px] my-[5px] " >
                   <div class="absolute bottom-0 md:bottom-8 lg:bottom-16 text-center">
                        <p class="text-xs md:text-base lg:text-xl">{{$t('chaebol.Available')}}</p>
                        <p class="text-xl md:text-2xl lg:text-4xl pt-3">{{value.Available}}</p>
                    </div>
                </div>
                <button class="border-none text-xs md:text-sm lg:text-base px-2 py-1 lg:px-5 lg:py-1 rounded absolute bottom-0 cursor-pointer" :class="Number(value.Available) > 0 ? 'bg-[#F0213B] ' : 'bg-[#9ca3af]'" :disabled="Number(value.Available) > 0 ? false : true" @click="getUserBonu(key)">{{$t('chaebol.RECEIVE')}}</button>
                </div>
            </div>
        </div>
    </div>
	<Footer />
	</div>
</template>

<script>
import Footer from "@/components/footer.vue"
import Header from "@/components/header.vue"
import { getEther } from "@/plugins/ethers"
// import {ElLoading} from 'element-plus'
export default {
	name: "chaebol",
	components: { Header, Footer },
    data(){
        return {
            formatNum:Math.pow(10,18),
            userInfo:{},
            selete_NFT:{},
            ShareholderPoolIncome:0.00,
            NFTgrounpIds:[],
            TeamPools: {
                Marketing_team:{
                    Available:0,
                    cumulative:0
                },
                Operations_Team:{},
                School_Team:{},
                Advisory_Team:{},
            },
            NFTgrounpId1:[],
            img:[],
            PLEDEG_loading:false,
            EXTRACT_loading:false
        }
    },
    async created() {
        // this.loading = ElLoading.service({fullscreen: true})
		this.eth = await getEther()
		const { formatEther } = this.eth.utils
		const { dividend } = this.eth.c
        const { chaebolnft } =  this.eth.c
        const { offlineTeam } = this.eth.c
        const { onlineTeam } = this.eth.c
        const { businessTeam } = this.eth.c
        const { privateTeam } = this.eth.c
		this.formatEther = formatEther
		this.dividend = dividend
        this.chaebolnft = chaebolnft
        this.offlineTeam = offlineTeam
        this.onlineTeam = onlineTeam
        this.businessTeam = businessTeam
        this.privateTeam = privateTeam
        Object.freeze(this.eth)
		if (this.eth) {
			this.getData()
		}
	},
    methods:{
        // 选择NFT
       selectNFT(index){
            this.selete_NFT[index] = !this.selete_NFT[index]
       },
       async getData(){
            const res = await this.dividend.searchUserBonus(this.eth.myAddr)
            const res1 = await this.dividend.userInfos(this.eth.myAddr)
            this.userInfo.Available = Math.floor( this.formatEther(res) * 100) / 100
            this.userInfo.cumulative = Math.floor( this.formatEther(res1.cumulative) * 100) / 100
            const NFT = await this.chaebolnft.balanceOf(this.eth.myAddr)
            this.userInfo.NFT = this.formatEther(NFT) * this.formatNum
            // 查询是否授权
            this.userInfo.isApproved =  await this.chaebolnft.isApprovedForAll(this.eth.myAddr,this.dividend.address)
            // 股东池收入
            this.ShareholderPoolIncome = this.formatEther(await this.dividend.totalBonus())
            // 查询用户的NFTtoken
            this.NFTgrounpIds = this.getNFTtoken(this.userInfo.NFT)
        },
        async getTeamPools(i){
                const {TeamPools} = this
                if(i == 2){
                    if(TeamPools.Marketing_team.show) return
                    TeamPools.Marketing_team.show = true
                    TeamPools.Marketing_team.text = this.$t('chaebol.teamPool1')
                    TeamPools.Marketing_team.Available = this.formatEther(await this.offlineTeam.searchUserBonus(this.eth.myAddr))
                    TeamPools.Marketing_team.cumulative = this.formatEther(await this.offlineTeam.userInfos(this.eth.myAddr))
                }
                if(i == 3){
                    if(TeamPools.Operations_Team.show) return
                    TeamPools.Operations_Team.show = true
                    TeamPools.Operations_Team.text = this.$t('chaebol.teamPool2')
                    TeamPools.Operations_Team.Available = this.formatEther(await this.onlineTeam.searchUserBonus(this.eth.myAddr))
                    TeamPools.Operations_Team.cumulative = this.formatEther(await this.onlineTeam.userInfos(this.eth.myAddr))
                }
                if(i == 4){
                    if(TeamPools.School_Team.show) return
                    TeamPools.School_Team.show = true
                    TeamPools.School_Team.text = this.$t('chaebol.teamPool3')
                    TeamPools.School_Team.Available = this.formatEther(await this.businessTeam.searchUserBonus(this.eth.myAddr))
                    TeamPools.School_Team.cumulative = this.formatEther(await this.businessTeam.userInfos(this.eth.myAddr))
                }
                if(i == 5){
                    if(TeamPools.Advisory_Team.show) return
                    TeamPools.Advisory_Team.Available = this.formatEther(await this.privateTeam.searchUserBonus(this.eth.myAddr))
                    TeamPools.Advisory_Team.cumulative = this.formatEther(await this.privateTeam.userInfos(this.eth.myAddr))
                    TeamPools.Advisory_Team.show = true
                    TeamPools.Advisory_Team.text = this.$t('chaebol.teamPool4')
                }
        },
        getNFTtoken(length){
            let arr = []
            for(let i = 0;i<length;i++){
                let tokenId = ''
                const getGroupId =async ()=>{
                    const res = await this.chaebolnft.tokenOfOwnerByIndex(this.eth.myAddr,i)
                    tokenId = this.formatEther(res) * this.formatNum
                    this.chaebolnft.groupIdMap(tokenId).then(data=>{
                        let groupId = this.formatEther(data) * this.formatNum
                        if(groupId !== 1){
                            this.getTeamPools(groupId)
                        }else{
                            this.NFTgrounpId1.push(groupId)
                            this.img.push(`https://static.soulmeta.io/nft/cdf/${tokenId}.png`)
                        }
                        arr.push(groupId)
                    })
                }
                getGroupId()
            }
            return arr
        },
        //质押NFT
        async pledegFrog(){
            if(this.PLEDEG_loading) return 
            // 已知NFT个数，分别获取tokenId
            if(!this.userInfo.isApproved){
                // 未授权先授权
                this.$message.warning(this.$t('chaebol.msg11'))
                const approved =  await this.chaebolnft.setApprovalForAll(this.dividend.address,true)
                approved.wait().then(()=>{
                    this.$message.success(this.$t('chaebol.msg10'))
                    location.reload()
                }).catch(()=>{this.$message.error(this.$t('chaebol.msg9'))})
                return 
            }
            let selete_NFT = []
            for(let key in this.selete_NFT){
                if(this.selete_NFT[key]){
                    selete_NFT.push(key)
                }
            }
            if(selete_NFT.length == 0){
                alert(this.$t('chaebol.msg8'))
                return 
            }
            this.PLEDEG_loading = true
            let tokenIdArr = []
            for(let i = 0;i < selete_NFT.length;i++){
                let tokenId = await this.chaebolnft.tokenOfOwnerByIndex(this.eth.myAddr,i)
                tokenId = this.formatEther(tokenId) * this.formatNum
                tokenIdArr.push(tokenId)
            }
            try {
                const res = await this.dividend.pledgeNft(tokenIdArr)
                res.wait().then(()=>{
                    this.$message.success(this.$t('chaebol.msg7'))
                    location.reload() 
                }).catch(()=>{this.$message.error(this.$t('chaebol.msg6'));this.PLEDEG_loading = false })
            } catch (error) {//拒绝或报错
                this.PLEDEG_loading = false
            }
            
        },
        // 领取质押NFT
        async extractFrog(){
            if(this.EXTRACT_loading) return 
            this.EXTRACT_loading = true
            try {
                const res = await this.dividend.receiveNft()
                res.wait().then(()=>{
                    this.$message.success(this.$t('chaebol.msg5'))
                    location.reload() 
                }).catch(()=>{this.$message.error(this.$t('chaebol.msg4'));this.EXTRACT_loading = true})
            } catch (error) {
                this.EXTRACT_loading = false
            }
        },
        // 领取分红
        getUserBonu(val){
            const {TeamPools} = this
            const getUserBonuObj = {
                dividend:async ()=>{
                    const tx = await this.dividend.getUserBonus()
                    tx.wait().then(async ()=>{
                        this.$message.success(this.$t('chaebol.msg2'))
                        this.userInfo.Available = this.formatEther(await this.dividend.searchUserBonus(this.eth.myAddr))
                        this.userInfo.cumulative = this.formatEther(await this.dividend.userInfos(this.eth.myAddr))
                    }).catch(()=>{this.$message.error(this.$t('chaebol.msg3'))})
                },
                Marketing_team:async ()=>{
                    const tx = await this.eth.c.offlineTeam.getUserBonus()
                    tx.wait().then(async ()=>{
                        this.$message.success(this.$t('chaebol.msg2'))
                        TeamPools.Marketing_team.Available = this.formatEther(await this.offlineTeam.searchUserBonus(this.eth.myAddr))
                        TeamPools.Marketing_team.cumulative = this.formatEther(await this.offlineTeam.userInfos(this.eth.myAddr))
                    }).catch(()=>{this.$message.error(this.$t('chaebol.msg3'))})
                },
                Operations_Team:async ()=>{
                   const tx = await this.eth.c.onlineTeam.getUserBonus()
                   tx.wait().then(async ()=>{
                        this.$message.success(this.$t('chaebol.msg2'))
                        TeamPools.Operations_Team.Available = this.formatEther(await this.onlineTeam.searchUserBonus(this.eth.myAddr))
                        TeamPools.Operations_Team.cumulative = this.formatEther(await this.onlineTeam.userInfos(this.eth.myAddr))
                    }).catch(()=>{this.$message.error(this.$t('chaebol.msg3'))})
                },
                School_Team:async ()=>{
                   const tx = await this.eth.c.businessTeam.getUserBonus()
                   tx.wait().then(async ()=>{
                        this.$message.success(this.$t('chaebol.msg2'))
                        TeamPools.School_Team.Available = this.formatEther(await this.businessTeam.searchUserBonus(this.eth.myAddr))
                        TeamPools.School_Team.cumulative = this.formatEther(await this.businessTeam.userInfos(this.eth.myAddr))
                    }).catch(()=>{this.$message.error(this.$t('chaebol.msg3'))})
                },
                Advisory_Team:async ()=>{
                   const tx =  await this.eth.c.privateTeam.getUserBonus()
                   tx.wait().then(async ()=>{
                        this.$message.success(this.$t('chaebol.msg2'))
                        TeamPools.Advisory_Team.Available = this.formatEther(await this.privateTeam.searchUserBonus(this.eth.myAddr))
                        TeamPools.Advisory_Team.cumulative = this.formatEther(await this.privateTeam.userInfos(this.eth.myAddr))
                    }).catch(()=>{this.$message.error(this.$t('chaebol.msg3'))})
                }
            }
            getUserBonuObj[val]()
        },
    }
}
</script>
<style lang="scss" scoped>
.ReceivingRules::before{
    content: '';
    display: block;
    height: 20px;
    width: 2px;
    margin-right: 10px;
    background-color: #F0213B;
}
.wawa {
    &::-webkit-scrollbar{/*滚动条整体样式*/
        width: 3px;     /*高宽分别对应横竖滚动条的尺寸*/
        height: 3px; 
    }
    &::-webkit-scrollbar-thumb {/*滚动条里面小方块*/
        border-radius: 10px;
        -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
        background:#F0213B
    }
    &::-webkit-scrollbar-track {/*滚动条里面轨道*/
        -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
        border-radius: 10px;
        background: #ffffff;
    }
}
    
</style>
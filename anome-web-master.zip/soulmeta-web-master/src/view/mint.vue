<template>
  <div v-loading="loading" class="mintPage min-h-full">
    <Header class="hidden md:block" />

    <div class="w-9/10 lg:w-200 xl:w-300 pb-20 mx-auto">
      <div class="py-5 flex justify-between items-center">
        <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.push('/casting')" />
        <div class="w-full pr-7 flex md:hidden justify-center">
          <div class="w-full flex items-center justify-center">
            <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            <div class="font-semibold">SOULMETA</div>
          </div>
        </div>
      </div>
      <div class="xl:w-full mx-auto lg:flex items-center md:mt-10">
        <div class="w-4/5 mx-auto lg:w-1/2 lg:pr-10">
          <div class="w-full md:h-full m-auto">
            <div v-if="!upImgErr" class="relative img-bg md:w-full md:h-full rounded-xl">
              <div class="p-4 md:p-8 flex items-center justify-center">
                <img class="rounded-2xl md:h-auto w-full" :src="userInfo.img" alt="" />
                <img class="w-12 md:w-16 absolute -bottom-3 -right-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
              </div>
            </div>
            <div v-else class="w-72 h-68 mx-auto relative" :class="!upErr.img && 'file-bg'">
              <input type="file" class="w-full h-full z-10 opacity-0 absolute top-0" @change="uploadFile($event)" />
              <img
                v-if="upErr.img"
                :src="upErr.img"
                class="max-w-full max-h-full absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2"
                alt=""
              />
            </div>
          </div>
        </div>
        <div class="w-4/5 mx-auto md:mt-20 lg:mt-0 lg:w-1/2 lg:pl-10">
          <img class="mt-2" src="https://static.soulmeta.io/web/img/mint/photoLine.webp" />
          <div class="emailPut mt-4 rounded-full relative">
            <div class="w-56 md:w-108 mx-auto overflow-x-auto custom-scrollbar outline-none text-center px-2 py-2 md:py-3 relative text-white md:text-2xl">
              {{ userInfo.contInfo }}
            </div>
            <img class="w-5 md:w-8 absolute right-4 top-1/2 transform -translate-y-1/2" src="https://static.soulmeta.io/web/img/mint/ok_icon.webp" alt="" />
            <div class="absolute left-2 top-1/2 transform -translate-y-1/2">
              <img class="w-7 md:w-10" :src="'https://static.soulmeta.io/web/img/caste/link' + userInfo.linkType + '.webp'" alt="" />
            </div>
          </div>
          <img class="mt-5" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" />
          <div class="w-full mt-4">
            <p class="text-center text-white text-lg md:text-3xl uppercase">
              {{ $t("caste.cas7") }}
            </p>
            <div class="flex justify-center items-center md:mt-2.5">
              <input
                v-model.number="casteNum"
                class="numPut mx-2 w-28 md:w-32 lg:w-32 xl:w-60 h-8 md:h-11 xl:h-14 rounded-md outline-none text-center md:text-2xl"
                type="number"
                disabled="true"
              />
            </div>
            <p v-if="$route.query.identity === '3dcitizen'" class="text-center text-white md:text-3xl">
              {{ $t("caste.cas8") }}
            </p>
          </div>
          <div class="buyBox w-60 md:w-108 lg:w-full m-auto mt-8 py-2 md:py-4 flex flex-col justify-around items-center rounded-3xl">
            <div class="w-full flex justify-center items-end">
              <div class="w-7 md:w-10 xl:w-12 md:mr-4">
                <img src="https://static.soulmeta.io/web/img/mint/usdt.webp" />
              </div>
              <span class="px-2 text-4xl md:text-5xl xl:text-6xl text-semibold">{{ priceU }}</span>
              <span class="text-lg md:text-3xl text-yellow-300">USDT</span>
            </div>
            <div
              class="mt-2 md:mt-4 text-center md:text-xl rounded-lg bg-E72 text-white w-40 md:w-60 leading-8 xl:leading-10 md:py-2 cursor-pointer"
              @click="castingNft"
            >
              {{ $t("caste.cas9") }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer class="hidden sm:block" />
  </div>
</template>
<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";

import { getEther } from "@/plugins/ethers";
export default {
  name: "mint",
  components: { Header, Footer },
  data() {
    return {
      loading: false,
      upImgErr: false,
      upErr: {
        img: "",
        file: null,
      },
      linkType: 1,
      casteNum: 100,
      userInfo: {},
      invitor: "",
      priceU: 4,
    };
  },
  methods: {
    async uploadFile(el) {
      this.loading = true;
      if (!el.target.files[0] || !el.target.files[0].size) {
        this.loading = false;
        return;
      } // 如果文件大小为0，则返回
      if (el.target.files[0].size / 1024 / 1024 > 5) {
        this.$message.error(this.$t("msg.msg7"));
        this.loading = false;
        return;
      }

      if (el.target.files[0].type.indexOf("image") === -1) {
        //如果不是图片格式
        this.$message.error(this.$t("msg.msg8"));
      } else if (el.target.files[0].type === "image/jpeg" || el.target.files[0].type === "image/png" || el.target.files[0].type === "image/gif") {
        const that = this;
        const reader = new FileReader(); // 创建读取文件对象
        reader.readAsDataURL(el.target.files[0]); // 发起异步请求，读取文件
        reader.onload = function () {
          // 文件读取完成后
          // 读取完成后，将结果赋值给img的src
          that.upErr.img = this.result;
          that.upErr.file = el.target.files[0];
        };
        this.uploadImage();
      } else {
        this.loading = false;
        this.$message.error(this.$t("msg.msg9") + ": JPG, PNG, GIF");
      }
    },
    async uploadImage() {
      let balance = await this.eth.c.soul721.balanceOf(this.eth.myAddr);
      let maxId = 0;
      for (let i = 0; i < balance; i++) {
        let tokenId = await this.eth.c.soul721.tokenOfOwnerByIndex(this.eth.myAddr, i);
        if (parseInt(tokenId) > maxId) {
          maxId = parseInt(tokenId);
        }
      }
      let signMessage = "";
      try {
        signMessage = await this.eth.signer.signMessage("Sign to your Meta Soul, Token ID: " + String(maxId) + ".");
        let data = {
          token_id: maxId,
          file: this.upImgErr ? this.upErr.file : this.userInfo.file,
          address: this.eth.myAddr,
          signature: signMessage,
          information: this.userInfo.contInfo,
          contact_type: this.userInfo.linkType,
        };
        const formData = new FormData();
        Object.keys(data).forEach((key) => {
          formData.append(key, data[key]);
        });
        let res = await this.$axios.post("/api/soul/upload_img", formData);
        if (res.status === 200 && res.data.resultCode === 0) {
          this.$router.push({
            path: "/success-page",
            query: {
              type: 2,
              casteNum: this.casteNum,
            },
          });
          this.$store.commit("setWaitBuyPage", false);
        } else {
          this.$store.commit("setWaitBuyPage", false);
          this.upImgErr = true;
          this.loading = false;
          alert(this.$t("msg.msg10"));
        }
      } catch (error) {
        console.log(error);
        this.loading = true;
        return;
      }
    },
    async castingNft() {
      if (this.upImgErr) {
        this.$message.error(this.$t("msg.msg4"));
        return;
      }
      if (!this.userInfo.soulNum) return;

      let soulApproveStatus = await this.eth.c.soul.allowance(this.eth.myAddr, this.eth.c.router.address);
      if (soulApproveStatus.isZero()) {
        let approve = await this.eth.c.soul.approve(this.eth.c.router.address, this.eth.constants.MaxUint256);
        await approve.wait();
      }

      let usdtApproveStatus = await this.eth.c.usdt.allowance(this.eth.myAddr, this.eth.c.controller.address);
      if (usdtApproveStatus.isZero()) {
        let approve = await this.eth.c.usdt.approve(this.eth.c.controller.address, this.eth.constants.MaxUint256);
        await approve.wait();
      }

      let balanceOf = await this.eth.c.soul.balanceOf(this.eth.myAddr);
      if (parseInt(this.eth.utils.formatEther(balanceOf)) < this.userInfo.soulNum) {
        this.$message.error(this.$t("msg.msg6"));
        return;
      }

      let referralRewards = await this.eth.c.controller.referWallet(this.eth.myAddr);
      let usdtBalance = await this.eth.c.usdt.balanceOf(this.eth.myAddr);

      let priceU = this.eth.utils.parseEther(String(this.priceU));
      if (referralRewards.lt(priceU) && usdtBalance.lt(priceU)) {
        this.$message.error(this.$t("msg.msg3"));
        return;
      }

      if (this.invitor === this.eth.myAddr) {
        this.$message.error(this.$t("msg.msg2"));
        return;
      }
      this.$store.commit("setWaitBuyPage", true);
      this.userInfo.casteNum = this.casteNum;

      try {
        let res = await this.eth.c.router.buildBox(
          1,
          this.userInfo.type,
          this.userInfo.soulNum < 5 ? 0 : this.userInfo.soulNum,
          this.$route.query.identity === "3dcitizen" ? this.casteNum / 100 : 0,
          this.invitor ? this.invitor : this.eth.constants.AddressZero
        );
        await res.wait();

        this.uploadImage();
      } catch (error) {
        this.$store.commit("setWaitBuyPage", false);
      }
    },
  },
  async created() {
    if (this.$store.state.casteInfo.img) {
      this.userInfo = this.$store.state.casteInfo;
    } else {
      this.$router.push("/");
    }
    this.eth = await getEther();
    this.invitor = window.sessionStorage.getItem("invitor");
    if (this.$route.query.identity === "civilian") {
      let num = await this.eth.c.router.getBuildCount();
      this.casteNum = num.toNumber();
    }
  },
};
</script>
<style scoped lang="scss">
.mintPage {
  background: #000;
  background-size: 100% 100%;
  .emailPut {
    background-image: linear-gradient(to right, #a981f0, #fb8696);
  }
  .numPut {
    background-image: linear-gradient(to right, #ef213b, #220100);
  }
  .buyBox {
    background: #212121;
  }
  // .buyBtn{
  //   background:url(https://static.soulmeta.io/web/img/caste/buyBtn.webp) no-repeat center;
  //   background-size:100% 100%;
  // }
  .img-bg {
    background: linear-gradient(to right bottom, #4f3990, #d83b55);
  }
  .file-bg {
    background: url(https://static.soulmeta.io/web/img/caste/file_bg.webp) no-repeat center/100% 100%;
  }
}
</style>

<template>
  <div v-loading="loading" class="nft-bg min-h-full pb-20">
    <Header class="hidden md:block" />
    <div class="hidden xl:block w-full sm:w-9/10 lg:w-200 xl:w-300 mx-auto py-2">
      <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/acc/return_icon.webp" alt="" @click="$router.replace('/account')" />
    </div>

    <div class="w-full sm:w-9/10 lg:w-200 xl:w-300 mx-auto xl:flex items-center xl:mt-10">
      <div class="mx-auto xl:w-1/2 xl:pr-10">
        <div class="img-bg relative">
          <div class="block md:hidden">
            <img
              class="w-3 absolute top-6 left-6 block xl:hidden cursor-pointer"
              src="https://static.soulmeta.io/web/img/acc/return_icon.webp"
              alt=""
              @click="$router.replace('/account')"
            />
            <div class="flex items-center justify-center py-4">
              <img class="w-8 mr-4" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
              <div class="text-xl font-bold">www.soulmeta.io</div>
            </div>
          </div>

          <img v-if="!upImgErr" class="w-9/10 rounded-3xl mx-auto" :src="nftItem.img" alt="" />
          <div v-if="type === 2 && upImgErr" class="w-72 h-68 mx-auto relative" :class="!upErr.img && 'file-bg'">
            <input type="file" class="w-full h-full z-10 opacity-0 absolute top-0" @change="uploadFile($event)" />
            <img v-if="upErr.img" :src="upErr.img" class="max-w-full max-h-full absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2" alt="" />
          </div>
          <img v-if="nftType === 0 && !upImgErr" class="w-12 absolute -bottom-3 right-0" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
        </div>
        <div v-if="type === 2 && upImgErr">
          <div class="w-72 mt-2 md:mt-4 mx-auto relative">
            <div class="relative">
              <input v-model="upErr.contInfo" type="text" class="w-full h-10 px-10 text-center inp-sty md:text-xl rounded-3xl" :placeholder="$t('dtl.dtl1')" />
              <img
                v-show="upErr.contInfo"
                class="w-5 absolute top-1/2 right-2 transform -translate-y-1/2"
                src="https://static.soulmeta.io/web/img/caste/right_icn.webp"
                alt=""
              />
              <img
                class="w-7 absolute left-2 top-1/2 transform -translate-y-1/2 cursor-pointer"
                :src="'https://static.soulmeta.io/web/img/caste/link' + upErr.linkType + '.webp'"
                alt=""
                @click="linkType = !linkType"
              />
            </div>
          </div>
          <img class="mt-5 md:mt-6" src="https://static.soulmeta.io/web/img/caste/bor.webp" alt="" />
          <div class="mt-2 md:mt-4 flex justify-around">
            <div
              v-for="(item, index) in 6"
              :key="item"
              class="rounded-full mt-1 cursor-pointer"
              @click="
                upErr.linkType = index;
                linkType = false;
              "
            >
              <img
                v-if="upErr.linkType === index"
                class="w-7 md:w-10 rounded-full"
                :src="'https://static.soulmeta.io/web/img/caste/link' + index + '.webp'"
                alt=""
              />
              <img v-else class="w-7 md:w-10 rounded-full" :src="'https://static.soulmeta.io/web/img/caste/link_no' + index + '.webp'" alt="" />
            </div>
          </div>
          <div class="mt-3 md:mt-5">
            <div class="w-24 md:w-40 mx-auto py-1 md:py-2 md:mt-6 rounded-xl text-center cursor-pointer bg-F02" @click="upImg">
              {{ $t("dtl.dtl2") }}
            </div>
          </div>
        </div>
      </div>
      <div class="w-4/5 sm:w-full mx-auto md:mt-20 xl:mt-0 xl:w-1/2">
        <div class="md:w-4/5 mx-auto">
          <div v-if="nftType === 0 && type === 1" class="flex items-center justify-between mt-5">
            <!-- <div class="w-24 md:w-32 text-center text-sm md:text-xl font-bold rounded-lg py-1.5 md:py-2 cursor-pointer bg-E72" @click="rewardDia = true">Reward</div> -->
            <div></div>
            <div class="flex items-center">
              <template></template>
              <img
                v-if="destoryType === 1"
                class="w-8 md:w-12 h-8 md:h-12 mr-5 cursor-pointer md:mr-10"
                src="https://static.soulmeta.io/web/img/acc/up.webp"
                alt=""
              />
              <img
                v-if="destoryType !== 1"
                class="w-8 md:w-12 h-8 md:h-12 mr-5 cursor-pointer md:mr-10"
                src="https://static.soulmeta.io/web/img/acc/to_up.webp"
                alt=""
                @click="destoryNft(1)"
              />
              <img v-if="destoryType === 2" class="w-8 md:w-12 h-8 md:h-12 cursor-pointer" src="https://static.soulmeta.io/web/img/acc/down.webp" alt="" />
              <img
                v-if="destoryType !== 2"
                class="w-8 md:w-12 h-8 md:h-12 cursor-pointer"
                src="https://static.soulmeta.io/web/img/acc/to_down.webp"
                alt=""
                @click="destoryNft(2)"
              />
            </div>
          </div>
          <div v-if="nftType === 0">
            <div v-if="nftItem.img" class="w-full px-10 py-2 xl:py-3 mt-5 text-sm md:text-2xl copy-bor overflow-x-auto text-center relative rounded-full">
              {{ nftItem.information }}
              <img
                class="w-5 xl:w-7 absolute right-3 top-1/2 transform -translate-y-1/2 cursor-pointer"
                src="https://static.soulmeta.io/web/img/acc/copy.webp"
                alt=""
                @click="doCopy"
              />
              <div class="absolute left-2 top-1/2 transform -translate-y-1/2">
                <img class="w-7 xl:w-10" :src="'https://static.soulmeta.io/web/img/caste/link' + nftItem.linkType + '.webp'" alt="" />
              </div>
            </div>
            <div class="mt-5 mb-8 text-sm md:text-xl flex items-center text-gray">
              <img class="w-4 md:w-8 mr-2 md:mr-4" src="https://static.soulmeta.io/web/img/acc/icon1.webp" alt="" />
              <span class="uppercase">SOULMETA NFT</span> <span class="no-underline">（www.soulmeta.io）</span>
            </div>
            <div class="mt-10 md:mt-4 xl:mt-12 relative">
              <img
                class="w-full cursor-pointer"
                src="https://static.soulmeta.io/web/img/home/soul_shop.webp"
                alt=""
                @click="this.$store.commit('setSoon', true)"
              />
            </div>
          </div>

          <div class="mt-8 uppercase md:text-xl">{{ $t("dtl.dtl3") }}</div>
          <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
            <div class="text-gray">{{ $t("dtl.dtl4") }}</div>
            <div class="text-gray">
              {{ nftType === 0 ? "ERC1155" : "ERC721" }}
            </div>
          </div>
          <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
          <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
            <div class="text-gray">{{ $t("dtl.dtl5") }}</div>
            <div class="text-gray">BSC</div>
          </div>
          <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
          <div class="mt-8 uppercase md:text-xl">{{ $t("dtl.dtl6") }}</div>
          <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
            <div class="text-gray">Card id</div>
            <div class="text-gray">101{{ nftType === 0 ? this.nftItem.tokenId : 721 }}</div>
          </div>
          <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
          <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
            <div class="text-gray">{{ $t("dtl.dtl7") }}</div>
            <div class="text-gray uppercase">
              {{ nftType === 0 ? "SOULMETA" : nftType === 1 ? "KAKA monster" : "Fishpond" }}
            </div>
          </div>
          <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
          <div v-if="nftType !== 0">
            <div class="mt-8 uppercase md:text-xl">{{ $t("acc.acc13") }}</div>
            <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
              <div class="text-gray">{{ $t("acc.acc14") }}</div>
              <div class="text-gray">{{ releaseInfo.total || "--" }} $KAKA</div>
            </div>
            <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
            <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl">
              <div class="text-gray">{{ $t("acc.acc15") }}</div>
              <div class="text-gray">{{ releaseInfo.unclaimed || "--" }} $KAKA</div>
            </div>
            <img class="" src="https://static.soulmeta.io/web/img/acc/icon4.webp" alt="" />
          </div>

          <div class="pb-2 pt-5 pl-2 flex justify-between items-center text-sm md:text-xl" v-show="type == 1">
            <div class="w-max mx-auto p-1 md:p-2 md:px-6 md:mt-4 rounded-lg text-center cursor-pointer bg-F02" @click="transferPop = true">
              {{ $t("acc.acc16") }}
            </div>
            <div class="w-30% mx-auto p-1 md:p-2 md:px-6 md:mt-4 rounded-lg text-center cursor-pointer bg-F02" @click="releaseToken" v-if="nftType !== 0">
              {{ $t("acc.acc17") }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <!--pop-->
    <div class="fixed inset-0 z-50 bg-black bg-opacity-70" v-show="transferPop">
      <div class="mt-10 md:mt-60 w-9/10 md:w-108 rounded-xl bg-D7 m-auto">
        <h2 class="text-black pt-5 text-center md:text-xl">
          {{ $t("acc.acc18") }}
        </h2>
        <div class="text-center mt-5 flex justify-center">
          <input class="w-9/10 h-8 md:h-10 rounded-lg outline-none text-black md:text-xl" v-model="toAddr" />
        </div>
        <div class="flex justify-around mt-5 pb-5">
          <div class="w-30% mx-auto py-1 rounded-lg text-center cursor-pointer bg-F02 md:text-xl" @click="transferNft">
            {{ $t("acc.acc19") }}
          </div>
          <div class="w-30% mx-auto py-1 rounded-lg text-center cursor-pointer bg-F02 md:text-xl" @click="transferPop = false">
            {{ $t("acc.acc20") }}
          </div>
        </div>
      </div>
    </div>
    <Footer class="hidden sm:block" />
  </div>
</template>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
import { getEther } from "@/plugins/ethers";
export default {
  name: "nft-detail",
  components: { Header, Footer },

  data() {
    return {
      loading: false,
      upImgErr: false,
      type: 1,
      nftType: 0,
      nftInfo: [],
      nftItem: {},
      tokenId: 0,
      linkType: false,
      upErr: {
        img: "",
        file: null,
        contInfo: "",
        linkType: 0,
      },
      signMessage: "",
      imgUrl: "",
      transferPop: false,
      toAddr: "",
      cardId: 0,
      releaseInfo: {},
      destoryType: 0,
    };
  },
  methods: {
    async destoryNft(type) {
      if (this.destoryType) return;
      this.loading = true;

      let soul1155ApproveStatus = await this.eth.c.soul1155.isApprovedForAll(this.$store.state.myAddr, this.eth.c.bonus.address);
      if (!soul1155ApproveStatus) {
        let approve = await this.eth.c.soul1155.setApprovalForAll(this.eth.c.bonus.address, true);
        await approve.wait();
      }
      try {
        let res = await this.eth.c.bonus.inputNftApi(type, [this.tokenId]);
        await res.wait();
        this.destoryType = type;
        this.$router.back();
      } catch {
        this.destoryType = 0;
      }
      this.loading = false;
    },
    async transferNft() {
      try {
        let res;
        if (this.nftType === 0) {
          res = await this.eth.c.soul1155.safeTransferFrom(this.eth.myAddr, this.toAddr, this.tokenId, 1, "0x00");
        } else {
          res = await this.eth.c.rabbit.transferFrom(this.eth.myAddr, this.toAddr, this.tokenId);
        }
        await res.wait();
        this.$message.success("Success");
        this.transferPop = false;
        this.$router.push("/account");
      } catch (e) {
        console.log(e);
        this.$message.error("error");
      }
    },
    // KNFT释放Token相关
    async checkRelease() {
      const cardId = this.cardId;
      const tokenId = this.tokenId;
      let info;
      let type;
      const info1 = await this.eth.c.release.tokenInfoes(tokenId);
      const info2 = await this.eth.c.release.cardInfoes(cardId);
      const info3 = await this.eth.c.releaseRabbit.tokenInfoes(tokenId);
      if (info1.isOpen) {
        info = info1;
        type = "token";
      } else if (info2.isOpen) {
        info = info2;
        type = "card";
      } else if (info3.isOpen) {
        info = info3;
        type = "token";
        this.isRabbitRelease = true;
      } else {
        return;
      }

      this.isReleasing = true;
      const release = this.isRabbitRelease ? this.eth.c.releaseRabbit : this.eth.c.release;
      const reward = await release.rewardData(tokenId);
      let unclaimed;
      if (type === "token") {
        unclaimed = await release.viewRewardByTokenId(tokenId);
      } else if (type === "card") {
        unclaimed = await release.viewRewardByCardId(tokenId);
      } else {
        return;
      }
      const fmt = this.eth.utils.formatEther;
      this.releaseInfo = {
        total: fmt(info.total),
        claimed: (+fmt(reward.claimed)).toFixed(4),
        unclaimed: (+fmt(unclaimed)).toFixed(4),
        remaining: (+fmt(info.total.sub(reward.claimed).sub(unclaimed))).toFixed(4),
      };
    },
    async releaseToken() {
      this.btnLoading = true;
      try {
        const res = await this.eth.c.release.claimReward(this.tokenId);
        await res.wait();
        this.checkRelease();
        this.$message.success("Claim Succeeded");
      } catch (e) {
        console.log(e);
        this.$message.success("Claim Error");
      }
      this.btnLoading = false;
    },
    doCopy() {
      this.$copyText(this.nftItem.information).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },

    getImg() {
      this.loading = true;
      if (this.nftType === 1) {
        this.nftInfo = this.$store.state.monsterList;
        this.nftItem = this.nftInfo.filter((itm) => itm.tokenId === this.tokenId)[0];
      } else if (this.nftType === 2) {
        this.nftInfo = this.$store.state.fishList;
      } else {
        this.nftInfo = this.$store.state.soulmetaList;
      }

      if (!this.nftInfo.length) {
        this.$router.push("/account");
        return;
      }

      if (this.nftType === 0) {
        try {
          this.getNftInfo();
        } catch (error) {
          this.loading = false;
        }
      } else {
        this.loading = false;
      }
    },
    async uploadFile(el) {
      if (!el.target.files[0] || !el.target.files[0].size) {
        return;
      } // 如果文件大小为0，则返回
      if (el.target.files[0].size / 1024 / 1024 > 5) {
        this.$message.error(this.$t("msg.msg7"));
        return;
      }

      if (el.target.files[0].type.indexOf("image") === -1) {
        //如果不是图片格式
        this.$message.error(this.$t("msg.msg8"));
      } else if (el.target.files[0].type === "image/jpeg" || el.target.files[0].type === "image/png" || el.target.files[0].type === "image/gif") {
        const that = this;
        const reader = new FileReader(); // 创建读取文件对象
        reader.readAsDataURL(el.target.files[0]); // 发起异步请求，读取文件
        reader.onload = function () {
          // 文件读取完成后
          // 读取完成后，将结果赋值给img的src
          that.upErr.img = this.result;
          that.upErr.file = el.target.files[0];
        };
      } else {
        this.$message.error(this.$t("msg.msg9") + ": JPG, PNG, GIF");
      }
    },
    async upImg() {
      if (!this.upErr.img) {
        this.$message.error(this.$t("msg.msg4"));
        return;
      } else if (!this.upErr.contInfo) {
        this.$message.error(this.$t("msg.msg5"));
        return;
      }
      this.loading = true;
      let data = {
        token_id: this.tokenId,
        file: this.upErr.file,
        address: this.eth.myAddr,
        signature: this.signMessage,
        information: this.upErr.contInfo,
        contact_type: this.upErr.linkType,
      };

      const formData = new FormData();
      Object.keys(data).forEach((key) => {
        formData.append(key, data[key]);
      });
      let res = await this.$axios.post("/api/soul/upload_img", formData);
      if (res.status === 200 && res.data.resultCode === 0) {
        this.upImgErr = false;
        this.getImg();
      } else {
        this.$store.commit("setWaitBuyPage", false);
        this.upImgErr = true;
        this.loading = false;
        alert(this.$t("msg.msg10"));
      }
    },

    async getNftInfo() {
      try {
        let signMessage;
        try {
          if (!this.signMessage) {
            signMessage = await this.eth.signer.signMessage("Sign to your Meta Soul, Token ID: " + String(this.tokenId) + ".");
            this.signMessage = signMessage;
          }
          let data = {
            token_id: this.tokenId,
            address: this.eth.myAddr,
            signature: this.signMessage,
          };
          let res = await this.$axios.post("/api/soul/get_nft_info", data);
          if (res.status === 200 && res.data.data.img_url) {
            this.loading = false;
            this.nftItem.img = res.data.data.img_url;
            this.nftItem.information = res.data.data.information;
            this.nftItem.linkType = res.data.data.contact_type;
          } else {
            this.loading = false;
            this.upImgErr = true;
          }
        } catch (error) {
          if (error && !signMessage) {
            this.$router.replace("/account");
          }
        }
      } catch (error) {}
    },
  },
  async created() {
    this.eth = await getEther();

    this.type = Number(this.$route.query.type);
    this.nftType = Number(this.$route.query.nftType);
    this.tokenId = this.nftType === 0 ? Number(this.$route.query.tokenId) : this.$route.query.tokenId;
    this.cardId = this.$route.query.cardId;
    if (this.nftType === 1) {
      this.checkRelease();
    }
    this.getImg();
  },
};
</script>

<style lang="scss" scoped>
.nft-bg {
  background: #000;
}
.copy-bor {
  background-image: linear-gradient(to right, #a981f0, #fb8696);
}
.file-bg {
  background: url(https://static.soulmeta.io/web/img/caste/file_bg.webp) no-repeat center/90% 90%;
}
.inp-sty {
  &:focus {
    outline: medium;
  }
  &::-webkit-input-placeholder {
    font-size: 12px;
  }
  &::-webkit-input-placeholder {
    font-size: 12px;
    color: #fff;
    opacity: 0.5;
  }
  background-image: linear-gradient(to right, #a981f0, #fb8696);
}

@media (min-width: 768px) {
  .inp-sty {
    &::-webkit-input-placeholder {
      font-size: 16px;
    }
  }
}
</style>

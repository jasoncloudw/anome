<template>
  <div class="nft-mall bg-black min-h-full">
    <div class="w-9/10 lg:w-200 xl:w-300 mx-auto">
      <div class="flex md:hidden items-center justify-center py-2.5">
        <img
          class="absolute left-[5%] z-10 w-3 cursor-pointer"
          src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
          alt=""
          @click="$router.push('/')"
        />
        <img class="w-auto h-8" src="https://static.soulmeta.io/web/img/nft-mall/nft-mall-logo.webp" alt="" />
      </div>
      <div class="gray-line"></div>
      <div class="flex items-center justify-between py-5 md:py-9">
        <img
          class="w-auto h-16 hidden md:block cursor-pointer"
          src="https://static.soulmeta.io/web/img/nft-mall/nft-mall-logo.webp"
          alt=""
          @click="$router.push('/')"
        />
      </div>
    </div>
    <div class="w-9/10 lg:w-200 xl:w-300 mx-auto">
      <router-link class="sm:mr-8 mr-5 leading-10 inline-block border-b-2 border-black" to="/nft-marketplace/summonBeast">{{$t("marketplace.menu1")}}</router-link>
      <router-link class="sm:mr-8 mr-5 leading-10 inline-block border-b-2" to=""  @click="topage()" style="color:#ffffff;border:none;">{{$t("marketplace.menu2")}}</router-link>
      <router-link class="sm:mr-8 mr-5 leading-10 inline-block border-b-2 border-black"  to="/nft-marketplace/nft-mall">{{$t("marketplace.menu3")}}</router-link>
      <router-link class="sm:mr-8 mr-5 leading-10 inline-block border-b-2"  to="" @click="topage()" style="color:#ffffff;border:none;">{{$t("marketplace.menu4")}}</router-link>
    </div>
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  data() {
    return {
    };
  },
  async created() {
  },
  mounted() {
  },
  methods: {
    topage(){
this.$store.commit("setSoon", true);
        return;
      return
    }
  },
};
</script>

<style lang="scss" scoped>
.el-input {
  --el-input-border-color: transparent;
  --el-input-focus-border-color: transparent;
  --el-input-hover-border-color: transparent;
  --el-input-bg-color: #bbbbbb1a;
  height: 62px;
  line-height: 62px;
}

:deep(.el-input__wrapper) {
  padding: 0 20px;
}

:deep(.el-input__inner) {
  color: #fff;
  font-size: 22px;
  padding-left: 6px;
}

.img-bg {
  background: linear-gradient(to bottom, #f0213b, #e8136c);
}

.btn-bg {
  background: linear-gradient(to bottom, #f0213b, #cb115f);
}
.router-link-active{
  border-bottom:2px solid #f0213b;
}

@media screen and(max-width:640px) {
  .el-input {
    height: 40px;
    line-height: 40px;
  }

  :deep(.el-input__wrapper) {
    padding: 0 12px;
  }

  :deep(.el-input__inner) {
    color: #fff;
    font-size: 14px;
    padding-left: 0;
  }
}
</style>

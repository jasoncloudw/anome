<template>
<div class="h-full overflow-hidden bg-black" v-loading="loading" element-loading-text="Loading..." element-loading-background="rgba(0, 0, 0, 0.6)">
 <div id="unity-container" class="unity-desktop">
      <canvas id="unity-canvas" :height="innerWidthS" :width="innerHeightS"></canvas>
      <div @click="gameendto" class="fixed w-[12%] h-[14%] top-[43%] left-[9%] z-[99999999999]"></div>
      <div id="unity-loading-bar">
        <div id="unity-logo"></div>
        <div id="unity-progress-bar-empty">
          <div id="unity-progress-bar-full"></div>
        </div>
      </div>
      <div id="unity-warning"> </div>
      <div id="unity-footer">
        <div id="unity-webgl-logo"></div>
        <div id="unity-fullscreen-button"></div>
        <div id="unity-build-title"></div>
      </div>
    </div>
</div>
</template>

<script>
import { mallAnimation,close_playgame } from "@/plugins/gameBuild";
import { getEther } from "@/plugins/ethers";
import { getCurrentInstance } from "vue";
export default {
  data() {
    return {        
      gameurl:'',
      loading:true,
      eth:'',
      locationtype:1,
      playtime:{},
      innerHeightS:window.innerHeight,
      innerWidthS:window.innerWidth,
      selectSortList:[
        {'id':1,'name':'BNB','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele01.webp',payMin:0.02,dec:18},
        {'id':2,'name':'SOUL','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele11.webp',payMin:2,dec:18},
        {'id':3,'name':'KAKA','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele31.webp',payMin:100,dec:18},
        {'id':4,'name':'IZI','imgUrl':'https://izumi.finance/assets/home/iziLogo/logo.svg',payMin:1,dec:18},
        {'id':5,'name':'USDT','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele21.webp',payMin:4,dec:18},
        {'id':6,'name':'STI','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele41.webp',payMin:10,dec:10},
        {'id':7,'name':'FIST','imgUrl':'https://fstswap.finance/images/56/0xC9882dEF23bc42D53895b8361D0b1EDC7570Bc6A.png',payMin:1,dec:6},
        {'id':8,'name':'GMT','imgUrl':'https://s2.coinmarketcap.com/static/img/coins/64x64/18069.png',payMin:1,dec:8},
      ]
    };
  },
  created() {
  },
  
  beforeRouteLeave(to, from, next) {
     if (!/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
        clearInterval(this.playtime); 
          close_playgame().Quit()
          .then(function () {
            next();
          }).catch(function () {
            next();
          });
    } else {
      next();
    }  
  },
  async mounted() {
    let that = this;
    that.eth = await getEther();  
    // 
    that.$nextTick(function(){
        mallAnimation(that.$route.query.roomId,that.gameurl,that.eth.myAddr,that,that.$route.query.combatId)
      });
  },
  methods: {    
    gameendto(){
      let that=this
      that.$router.replace({
        name: "games-lobby",
      })   
    },
    //平局执行代码
    dogfallfun(e,f,g){
      let that=this     
      that.$router.replace({
        name: "games-lobby",
        query: {
          roomid: e,
          amount:f,
          payType:g
        }
      })
    },
  },
};
</script>
<style scoped>
</style>
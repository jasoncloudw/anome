<template>
  <div class="frog min-h-full">
    <div class="xl:w-300 w-9/10 mx-auto">
      <Header class="hidden md:block" />
      <div class="py-5 flex md:hidden justify-between items-center">
        <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.push('/')" />
        <div class="w-full flex justify-center">
          <div class="w-full flex items-center justify-center">
            <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            <div class="font-semibold">SOULMETA</div>
            <div class="my-3 md:my-10 text-lg">&nbsp;/&nbsp;{{ $t("frog.frog1") }}</div>
          </div>
        </div>
      </div>
      <div class="hidden md:block my-3 md:my-10 text-lg md:text-2xl font-semibold text-center">
        {{ $t("frog.frog1") }}
      </div>
      <!-- <div class="w-full">
        <div class="flex items-center relative">
          <div class="swiper-container">
            <div class="swiper-wrapper">
              <div class="swiper-slide" v-for="(item, index) in myCards" :key="index">
                <div class="w-full">
                  <img class="w-full" :src="'https://static.soulmeta.io/web/img/frog/slide' + item.image + '_' + lang + '.webp'" alt="" />
                </div>
                <div class="md:text-xl text-sm font-semibold text-center text-386">
                  {{ item.name }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> -->
      <div class="ml-auto my-5 md:my-10 flex text-center border rounded-lg border-gray-500">
        <!-- <div class="w-1/3 text-sm leading-10 rounded-lg" :class="navBg === 0 ? 'bg-F02' : ''" @click="sortTeam(0)">{{ $t('frog.frog2') }}</div> -->
        <!-- <div class="w-1/3 text-sm leading-10 rounded-lg" :class="navBg === 1 ? 'bg-F02' : ''" @click="sortTeam(1)">{{ $t('frog.frog3') }}</div> -->
        <div class="w-full text-sm leading-10 rounded-lg uppercase" :class="navBg === 2 ? 'bg-F02' : ''" @click="navBg = 2">
          {{ $t("frog.frog4") }}
        </div>
      </div>

      <div class="flex justify-start items-center flex-wrap" v-if="navBg === 0 || navBg === 1">
        <div v-for="item in teamList" :key="item" class="w-30% mb-3 mx-1">
          <div class="relative">
            <img class="" src="https://static.soulmeta.io/web/img/frog/frog_img.png" alt="" />
            <div class="text-xs md:text-xl absolute bottom-1 md:bottom-4 left-2 md:left-4">#{{ item.teamId }}</div>
          </div>
          <div class="flex justify-center items-center">
            <img class="w-5 md:w-10 mr-1 md:mr-2 my-2 md:my-4" src="https://static.soulmeta.io/web/img/mint/usdt.webp" alt="" />
            <div class="text-xs md:text-2xl">{{ item.reward }}/{{ item.totalReward }}</div>
          </div>
        </div>
      </div>
      <div class="flex justify-start items-center flex-wrap" v-else-if="navBg === 2">
        <div v-for="item in myTeams" :key="item" class="w-30% mb-3 mx-1">
          <div class="relative">
            <img class="" src="https://static.soulmeta.io/web/img/frog/frog_img.png" alt="" />
            <div class="text-xs md:text-xl absolute bottom-1 md:bottom-4 left-2 md:left-4">#{{ item.teamId }}</div>
          </div>
          <div class="flex justify-center items-center">
            <img class="w-5 md:w-10 mr-1 md:mr-2 my-2 md:my-4" src="https://static.soulmeta.io/web/img/mint/usdt.webp" alt="" />
            <div class="text-xs md:text-2xl">{{ item.reward }}/{{ item.totalReward }}</div>
          </div>
          <div
            class="leading-7 md:py-2 rounded-full text-sm md:text-xl text-center cursor-pointer bg-E72"
            @click="claimReward(item.tokenId)"
            v-if="item.tokenId"
          >
            {{ $t("frog.frog5") }}
          </div>
        </div>
      </div>
      <!-- <img class="my-5 md:my-10" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt="" /> -->
      <!-- <div class="mt-5 md:mt-10 mb-3 md:mb-5 text-sm md:text-2xl text-center">
        {{ $t("frog.frog6") }}
      </div>
      <div class="w-full h-3 md:h-4 rounded-full flex items-center bg-gray-400 bg-opacity-20">
        <div :style="'width:' + schedule" class="h-full rounded-full bg-F02"></div>
        <div class="text-xs">{{ schedule }}</div>
      </div> -->
      <!-- <img class="my-5" src="https://static.soulmeta.io/web/img/home/bor_img.webp" alt=""> -->
      <!-- <div class="my-5 md:my-10 text-lg font-semibold text-center">
        {{ $t("frog.frog7") }}
      </div> -->
      <!-- <div class="w-full grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        <div v-for="item, index in rankImgList" v-show="index <= 3 || commShowAll" :key="item.teamId" class="rounded-xl cursor-pointer" @click="toDetail(item)">
          <div class="flex items-center">
            <img class="w-full rounded-t-xl" :src="'https://static.soulmeta.io/nft/smcl/' + item.imgId + '.png'" alt="" />
          </div>
          <div class="p-1 md:p-3 text-xs md:text-base rounded-b-xl bg-2D2">
            <div class="flex items-center justify-between">
              <div>Community Frog</div>
              <div>SoulMeta</div>
            </div>
            <div class="my-1 italic font-semibold">#{{ item.teamId }}</div>
            <div class="flex items-center">
              <img class="w-4 md:w-6 h-4 md:h-6 mr-1 md:mr-2.5" src="https://static.soulmeta.io/web/img/frog/frog_icon.webp" alt="" />33.78 BNB
            </div>
          </div>
        </div>
      </div> -->
      <!-- <div class="w-max ml-auto my-3 text-sm md:text-xl cursor-pointer" @click="commShowAll = !commShowAll">{{ $t("frog.frog16") }}</div> -->
    </div>
    <Footer />
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import Footer from "@/components/footer.vue";
import Swiper from "swiper";
import { getEther } from "@/plugins/ethers";
export default {
  name: "frog",
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      myCards: [
        { key: 1, image: 1 },
        { key: 2, image: 2 },
      ],
      schedule: "10%",
      commShowAll: false,
      navBg: 2,
      teamList: [],
      myTeams: [],
    };
  },
  computed: {
    lang() {
      return this.$i18n.locale;
    },
    rankImgList() {
      let list = [];
      this.teamList.forEach((ele) => {
        list.push({
          teamId: ele.teamId,
          imgId: this.randomNum(1, 20),
        });
      });
      return list;
    },
  },
  methods: {
    randomNum(minNum, maxNum) {
      switch (arguments.length) {
        case 1:
          return parseInt(Math.random() * minNum + 1, 10);
        case 2:
          return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
        default:
          return 0;
      }
    },
    toDetail(item) {
      this.$router.replace({
        path: "/frog-comm-dtl",
        query: {
          imgId: item.imgId,
          teamId: item.teamId,
        },
      });
    },
    swiperFrog() {
      //调用延迟加载 $nextTick
      this.$nextTick(() => {
        let swiper = new Swiper(".swiper-container", {
          observer: true,
          observeParents: true,
          loop: true,
          speed: 1200,
          autoplay: {
            disableOnInteraction: false,
          },
          // navigation: {
          //     nextEl: '.swiper-button-next',
          //     prevEl: '.swiper-button-prev',
          // }
        });
      });
    },
    sortTeam(index) {
      this.navBg = index;
      if (index === 0) {
        this.teamList = this.teamList.sort(this.descend("index"));
      } else if (index === 1) {
        this.teamList = this.teamList.sort(this.ascend("totalReward"));
      }
    },
    async getInfo() {
      this.teamList = [];
      this.myTeams = [];
      let res = await this.eth.c.team.viewTeamList();
      if (res) {
        for (let i = 0; i < res.length; i++) {
          let rewards = await this.eth.c.team.teams(res[i]);
          this.teamList.push({
            index: i,
            leaders: res[i],
            teamId: res[i].slice(-4),
            totalReward: rewards.totalReward / Math.pow(10, 18),
            reward: (parseInt(rewards.totalReward) - parseInt(rewards.rewarded)) / Math.pow(10, 18),
          });
        }
      }
      //查询我的nft判断社区
      let balance = await this.eth.c.team.balanceOf(this.eth.myAddr);
      if (parseInt(balance) > 0) {
        for (let i = 0; i < balance; i++) {
          let tokenId = await this.eth.c.team.tokenOfOwnerByIndex(this.eth.myAddr, i);
          let leaders = await this.eth.c.team.leaders(tokenId);
          let myTeam = this.myTeams.filter((item) => item.leaders === leaders);
          if (myTeam <= 0) {
            let rewards = await this.eth.c.team.teams(leaders);
            this.myTeams.push({
              tokenId: tokenId,
              leaders: leaders,
              teamId: leaders.slice(-4),
              totalReward: rewards.totalReward / Math.pow(10, 18),
              reward: (parseInt(rewards.totalReward) - parseInt(rewards.rewarded)) / Math.pow(10, 18),
            });
          }
        }
      }
      //不管有没有nft 直接查询我的社区,重复则不添加不重复则添加   //根据要求只展示可领取的社区池所以屏蔽
      // let team = await this.eth.c.caste.teams(this.eth.myAddr)
      // let hasTeam = this.myTeams.filter(item => item.leaders === team.address)
      // if (team.address !== this.eth.constants.AddressZero && hasTeam<=0) {
      //     let rewards = await this.eth.c.team.teams(team.address)
      //     this.myTeams.push({
      //         tokenId:'',
      //         leaders:team.address,
      //         teamId: team.address.slice(-4),
      //         totalReward: rewards.totalReward / Math.pow(10,18),
      //         reward: (parseInt(rewards.totalReward) - parseInt(rewards.rewarded)) / Math.pow(10,18)
      //     })
      // }
    },
    async claimReward(tokenId) {
      try {
        let res = await this.eth.c.team.claimReward(tokenId);
        await res.wait();
        this.$message.success("Success");
        this.getInfo();
      } catch {
        this.$message.error("error");
      }
    },
    ascend(p) {
      return function (m, n) {
        var a = m[p];
        var b = n[p];
        return b - a;
      };
    },
    descend(p) {
      return function (m, n) {
        var a = m[p];
        var b = n[p];
        return a - b;
      };
    },
  },
  mounted() {
    this.swiperFrog();
  },
  async created() {
    this.eth = await getEther();
    if (this.eth) {
      this.getInfo();
    }
  },
};
</script>

<style lang="scss" scoped>
.frog {
  background: #000;
}
</style>

<template>
  <div class="w-full h-full" style="background-color:#34303a;">
    <img class="block w-1/2 mx-auto" src="https://img1.baidu.com/it/u=2059901607,903241081&fm=253&fmt=auto&app=138&f=PNG?w=889&h=500" alt="">
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>
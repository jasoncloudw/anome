<template>
  <div class="game-plaza bg-black min-h-full">
    <div class="w-full mx-auto pb-10">
      <div class="relative">
        <div class="flex items-center absolute w-full z-999">
          <img
            class="w-3 absolute left-[5%] block lg:hidden z-20"
            src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
            alt=""
            @click="$router.back()"
          />
          <Header class="block" />
        </div>
        <div class="w-full mx-auto max-w-[2560px] relative">
          <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/w3dnftback.webp" alt="" />
          <div class="absolute left-[8%] sm:bottom-[20%] bottom-[17%] overflow-hidden">
            <img class="xl:w-48 lg:w-40 sm:w-36 w-16 float-left" src="https://static.soulmeta.io/web/img/game-mora/w-publicity.webp" alt="">
            <div class="float-left xl:pt-12 lg:pt-10 sm:pt-8 pt-1 xl:pl-5 lg:pl-3 pl-2">
              <h6 class="lg:text-2xl sm:text-lg text-sm font-bold">3DNFT</h6>
              <span class="lg:text-lg sm:text-sm text-xs">character customization</span>
            </div>
            <img @click="toCustomizationNFT" class="xl:w-12 lg:w-10 sm:w-8 w-6 inline-block xl:mt-12 lg:mt-10 sm:mt-10 mt-2 cursor-pointer sm:ml-4 ml-2" src="https://static.soulmeta.io/web/img/game-mora/w-publicityOpen.webp" alt="">
          </div>
          <h4 class="absolute block text-center sm:text-3xl xs:text-xl w-full lg:text-6xl font-black italic z-10  max-w-[2560px]" style="bottom:6%;">{{ $t("navbar.nav11") }}</h4>
        </div>
      </div>
      <div  v-show="mobileevn" class="w-11/12 text-center mx-auto text-sm leading-5 pt-10">
{{ $t("gameslobby.msg13") }}
      </div>
      <div v-show="!mobileevn"
        class="w-full max-w-screen-2xl mx-auto overflow-hidden pt-4 pl-4 sm:px-0"
      >
        <div
          class="w-1/2 md:w-1/3 xl:w-1/4 float-left px-0 my-2.5 pr-4 sm:my-5 box-sizing sm:px-5"
          v-for="(item, index) in roomlist"
          :key="index"
        >
          <div class="w-full float-left backpos px-3 sm:pb-6 pb-3 relative">
            <h6
              class="w-full text-center block leading-5 font-normal text-xs md:text-sm md:leading-8 md:font-bold"
            >
              {{ $t("gameslobby.game4") }}{{ index + 1 }}
            </h6>
            <h6
            v-show="item.bet!=0"
              class="w-full absolute text-center block leading-5 font-normal text-[12px] md:text-sm md:leading-8 md:font-bold left-0 top-1/4 text-F52"
            >
              {{ item.bet!=0?item.bet/Math.pow(10, selectSortList[item.payType-1].dec)+' ':'' }}
              {{selectSortList[item.payType-1]?.name!=undefined?selectSortList[item.payType-1]?.name:'SOUL'}}
            </h6>
            <div class="w-2/5 float-left cursor-pointer">
              <div class="w-full relative" @click="showdislog(index, 1,item.bet,item.player1,item.userInside,item.combatId,item.payType)">
                <strong
                  v-show="!item.player1"
                  class="absolute text-black block w-full text-xs md:text-lg text-center top-1/2 -mt-2 md:-mt-3.5 font-normal md:font-bold"
                  >{{ $t("gameslobby.game8") }}</strong
                >
                <img
                  v-show="item.player1"
                  :src="item.player1url"
                  class="w-full block absolute rounded-full"
                  alt=""
                  style="padding: 19%"
                />
                <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/roomback1.webp" alt="" />
              </div>
              <span
                class="text-xs sm:text-sm md:font-bold font-normal block text-center"
                :class="item.userInside==1?'text-F52':'text-bg-white'" 
                >{{ $t("gameslobby.game11") }}1</span
              >
            </div>
            <span
              class="w-1/5 float-left text-center top-1/2 left-1/2 absolute inline-block -mt-0 -ml-0.5 md:-ml-0 text-sm md:text-2xl font-black"
              style="transform: translate(-50%, -50%)"
              >VS</span
            >

            <div class="w-2/5 float-right cursor-pointer">
              <div class="w-full relative" @click="showdislog(index, 2,item.bet,item.player2,item.userInside,item.combatId,item.payType)">
                <strong
                  v-show="!item.player2"
                  class="absolute text-black block w-full text-xs md:text-lg text-center top-1/2 -mt-2 md:-mt-3.5 font-normal md:font-bold"
                  >{{ $t("gameslobby.game8") }}</strong
                >
                <img
                  v-show="item.player2"
                  :src="item.player1ur2"
                  class="w-full block absolute rounded-full"
                  alt=""
                  style="padding: 19%"
                />
                <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/roomback2.webp" alt="" />
              </div>
              <span
                class="text-xs sm:text-sm md:font-bold font-normal block text-center"
                :class="item.userInside==2?'text-F52':'text-bg-white'" 
                >{{ $t("gameslobby.game11") }}2</span
              >
            </div>  
            <div class="lg:w-4/5 w-full float-left lg:ml-[10%] lg:ml-1/5 pt-4">                  
              <div class="grid grid-cols-8 gap-2 px-4">
                <div v-for="item in selectSortList" :key="item.id" class="rounded-full cursor-pointer mx-auto">
                  <img class="w-full rounded-full" :src="item.imgUrl" alt="" />
                </div>
              </div>
            </div>      
          </div>
        </div>
      </div>
      <div class="w-full mx-auto "  v-show="!mobileevn">
        <div class="relative max-w-[2560px] mx-auto">
          <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/w-gamebanner.webp" alt="" />
          <h5 class="absolute lg:left-20 sm:left-8 left-4 lg:text-6xl sm:text-2xl text-sm top-[37%]">{{ $t("gameslobby.msg22") }}</h5>
          <p  class="absolute lg:left-20 sm:left-8 left-4 lg:text-2xl text-xs block  max-w-lg top-[57%]">{{ $t("gameslobby.msg23") }}</p>
        </div>
        <div
          class="w-full -mt-20 pt-24 px-5 pb-5 lg:px-10 lg:pb-10 rounded-b-xl  max-w-[2560px] mx-auto"
          style="background-color: #1b1b1b"
        >
          <div class="instructions lg:px-20">
            <p class="showback">{{ $t("gameslobby.game25") }}</p>
            <p class="showback">{{ $t("gameslobby.game26") }}</p>
            <p class="showback">{{ $t("gameslobby.game27") }}</p>
            <p>{{ $t("gameslobby.game28") }}</p>
            <p class="showback">{{ $t("gameslobby.game29") }}</p>
            <p class="showback">{{ $t("gameslobby.game30") }}</p>
            <p class="showback">{{ $t("gameslobby.game31") }}</p>
            <p>{{ $t("gameslobby.game32") }}</p>
            <p class="showback">{{ $t("gameslobby.game33") }}</p>
            <p class="showback">{{ $t("gameslobby.game34") }}</p>
            <p class="showback">{{ $t("gameslobby.game35") }}</p>
            <p>{{ $t("gameslobby.game41") }}</p>
            <p class="showback">{{ $t("gameslobby.game42") }}</p>
            <p class="showback">{{ $t("gameslobby.game43") }}</p>
          </div>
        </div>
      </div>

      <div class="w-full max-w-screen-xl mx-auto lg:mt-10 sm:mt-6 mt-4"  v-show="!mobileevn">
        <div class="w-full font-semibold text-center md:text-3xl text-xl">
          {{ $t("gameslobby.game1") }}
        </div>
        <div class="w-full balanceback lg:mt-10 sm:mt-6 mt-4 overflow-hidden">
          <div class="w-1/2 h-full float-left lg:py-16 md:py-12 py-6">
            <h5 class="text-center font-medium lg:text-2xl sm:text-xl text-sm">
              {{ $t("gameslobby.game5") }}
            </h5>
            <div class="text-center lg:pt-20 sm:pt-16 pt-4">
              <span class="lg:text-4xl sm:text-2xl text-sm font-bold">{{
                numberToCurrency(subStringNum(totalBonusall,2), 10)
              }}</span>
              <span class="lg:text-lg sm:text-lg text-xs pl-2">SOUL</span>
            </div>
          </div>
          <div class="w-1/2 h-full float-left lg:py-16 md:py-12 py-6">
            <h5 class="text-center font-medium lg:text-2xl sm:text-xl text-sm">
              {{ $t("gameslobby.game9") }}
            </h5>
            <div class="text-center lg:pt-20 sm:pt-16 pt-4">
              <span class="lg:text-4xl sm:text-2xl text-sm font-bold">{{
                numberToCurrency(totalPledgeall, 10)
              }}</span>
            </div>
          </div>
        </div>
        <div>
          <div class="w-full relative h-10 lg:my-10 sm:my-4 my-2">
            <div class="w-full h-px absolute top-1/2 bg-white"></div>
            <span
              class="w-32 absolute top-0 lg:text-3xl sm:text-2xl text-xl text-center font-semibold bg-black left-1/2 -ml-16 h-10 leading-10"
              >{{ $t("gameslobby.game13") }}</span
            >
          </div>
          <div class="w-full overflow-hidden">
            <div
              class="w-full lg:w-1/2 rounded-lg float-left lg:relative lg:pt-1/2"
              style="background: #1c1c1c"
            >
              <div
                class="w-full lg:h-full lg:p-10 sm:p-6 p-4 lg:absolute top-0 left-0"
              >
               <!-- <img v-show="soulmetaList.length == 0" src="../assets/img/nftnullimg.png" alt="" srcset="" class="w-1/4 mx-auto block"> -->
               <p  v-show="soulmetaList.length == 0" class="text-center lg:text-xl sm:text-sm text-xs lg:leading-10 sm:leading-8 leading-6 px-10 lg:pt-[30%] lg:py-0 py-4">{{ $t("gameslobby.msg6") }}</p>
              <!--  -->
                <div class="w-full h-full overflow-y-auto scrollstr">
                 
                  <!-- lg:w-1/2 sm:w-1/4 w-1/2 p-2 sm:px-4 sm:py-6 float-left -->
                  <div
                  
                    class="lg:w-1/2 sm:w-1/4 w-1/2 p-2 sm:px-4 sm:pb-6 float-left relative cursor-pointer"
                    @click="selectNft(item)"
                    v-for="item in soulmetaList"
                    :key="item.tokenId"
                  >
                    <img
                      src="https://static.soulmeta.io/web/img/game-mora/w-fishpondntfimg.webp"
                      class="w-full"
                      alt=""
                    />
                    <img
                      v-show="item.select"
                      src="https://static.soulmeta.io/web/img/game-mora/wpledgenftselect.webp"
                      class="absolute lg:w-1/12 sm:w-6 w-4 lg:right-10 lg:bottom-12 sm:right-8 sm:bottom-10 right-5 bottom-6"
                      alt=""
                    />
                    <img
                      v-show="!item.select"
                      src="https://static.soulmeta.io/web/img/game-mora/wpledgenftnoselect.webp"
                      class="absolute lg:w-1/12 sm:w-6 w-4 lg:right-10 lg:bottom-12 sm:right-8 sm:bottom-10 right-5 bottom-6"
                      alt=""
                    />
                  </div>
                </div>
              </div>
            </div>

            <div
              class="w-full lg:w-1/2 rounded-lg float-left lg:relative lg:pt-1/2"
            >
              <div
                class="w-full lg:h-full lg:px-10 sm:p-6 p-4 lg:absolute top-0 left-0"
              >
                <h5 class="sm:pt-8 pt-4 pb-3 sm:pb-6 md:text-3xl text-xl">
                  {{ $t("gameslobby.game18") }}
                </h5>
                <div class="w-full h-3/5 lg:pr-4 overflow-y-auto scrollstr">
                  <p
                    class="sm:text-xl text-sm leading-7 text-white sm:leading-10 break-words"
                  >
                    {{ $t("gameslobby.game21") }}
                  </p>
                  <p
                    class="sm:text-xl text-sm leading-7 text-white sm:leading-10 break-words"
                  >
                    {{ $t("gameslobby.game22") }}
                  </p>
                  <p
                    class="sm:text-xl text-sm leading-7 text-white sm:leading-10 break-words"
                  >
                    {{ $t("gameslobby.game23") }}
                  </p>
                  <p
                    class="sm:text-xl text-sm leading-7 text-white sm:leading-10 break-words"
                  >
                    {{ $t("gameslobby.game24") }}
                  </p>
                </div>
                <div class="lg:mt-5 mt-10">
                  <span
                    @click="pledeto"
                    :class="selectLength.length!=0?'bg-F52':'bg-gray-300'"
                    class="sm:w-40 w-32 inline-block sm:h-12 h-10 sm:leading-lh-3 leading-10 sm:text-lg text-sm rounded-full text-white text-center font-bold cursor-pointer"
                    >{{ $t("gameslobby.game2") }}</span
                  >
                  <span
                    @click="receiveNftTo"
                    class="sm:w-40 w-32 inline-block border border-white sm:h-12 h-10 sm:leading-lh-3 leading-10 sm:text-lg text-sm rounded-full text-white text-center font-bold ml-6 cursor-pointer"
                    >{{ $t("gameslobby.game6") }}</span
                  >
                  <p class="sm:text-lg text-sm ml-4 mt-4">
                    {{ $t("gameslobby.game10") }}：{{selectLength.length !=0 ? selectLength:''}}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="w-full lg:mt-20 sm:mt-10 mt-6 overflow-hidden px-4">
            <div class="sm:w-1/4 w-full float-left">
              <div class="text-center threeback relative">
                <span class="text-4xl font-bold leading-lh-14">{{subStringNum(totalBonus,2)}}</span>
                <strong class="ml-2">SOUL</strong>
                <p class="absolute text-center text-sm bottom-5 block w-full">
                  {{ $t("gameslobby.game16") }}
                </p>
              </div>
            </div>
            <div class="sm:w-1/4 sm:my-0 my-4 w-full float-left sm:mx-1/8">
              <div class="text-center threeback relative">
                <span class="text-4xl font-bold leading-lh-14">{{resulttotal}}</span>
                <p class="absolute text-center text-sm bottom-5 block w-full">
                  {{ $t("gameslobby.game19") }}
                </p>
              </div>
            </div>
            <div class="sm:w-1/4 w-full float-left">
              <div class="text-center threeback relative">
                <span class="text-4xl font-bold leading-lh-14">{{subStringNum(myBonus,2)}}</span>
                <strong class="ml-2">SOUL</strong>
                <p class="absolute text-center text-sm bottom-5 block w-full">
                  {{ $t("gameslobby.game3") }}
                </p>
              </div>
            </div>
            <div class="w-full float-left mt-8">
              <span @click="getUserBonusApi"
                :class="myBonus!=0?'bg-F52':'bg-gray-300'"
                class="sm:w-40 w-32 block mx-auto sm:h-12 h-10 sm:leading-lh-3 leading-10 sm:text-lg text-sm rounded-full text-white text-center font-bold cursor-pointer"
                >{{ $t("gameslobby.game7") }}</span
              >
            </div>
          </div>
        </div>
      </div>
      <div
        class="fixed w-4/5 max-w-screen-lg bg-black/90 top-1/2 left-1/2 z-999 backdislogs pb-10 lg:pb-20"
        v-show="displayshow"
      >
        <h6
          class="w-60 h-10 mx-auto text-center text-lg tracking-widest"
          style="line-height: 3.5rem"
        >{{ $t("gameslobby.game19") }}
        </h6>
        <div class="lg:w-72 lg:h-36 w-56 h-28 mx-auto mt-6">
          <img
            class="w-1/4 float-left pt-7 lg:pt-9 cursor-pointer"
            src="https://static.soulmeta.io/web/img/game-mora/wswitchleft.webp"
            alt=""
            @click="selectsoulNft(0)"
          />
          <div
            class="w-1/2 float-left"
            :class="dislogbordertype == 1 ? 'selectclick' : 'selectclickt'"
          >
            <img
              :src="soulNftListimg"
              class="w-full block rounded-full"
              alt=""
              style="padding: 19%"
            />
          </div>
          <img
            class="w-1/4 float-left pt-7 lg:pt-9 cursor-pointer"
            src="https://static.soulmeta.io/web/img/game-mora/wswitchright.webp"
            alt=""
            @click="selectsoulNft(1)"
          />
        </div>
        <img
          class="absolute top-6 right-6 w-5 lg:top-8 lg:right-8 lg:w-10 cursor-pointer"
          @click="displayshow = false;refresh(),dogfallroomid=''"
          src="https://static.soulmeta.io/web/img/game-mora/w-displayclose.webp"
          alt=""
        />
        <div
          class="flex flex-row lg:pl-32 lg:mt-10 mt-5 w-4/5 lg:w-full mx-auto"
        >
          <div
            class="xl:p-10 lg:p-6 p-5 lg:mr-32 cursor-pointer relative"
            @click="selectindex(0)"
            :class="select[0] != 0 ? 'selectback' : 'noselectback'"
          >
            <span
              v-show="select[0]"
              class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
              >{{ select[0] }}</span
            >
            <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/wstone.webp" alt="" />
          </div>
          <div class="w-1/4 lg:hidden"></div>
          <div
            class="xl:p-10 lg:p-6 p-5 lg:mr-32 cursor-pointer relative"
            @click="selectindex(1)"
            :class="select[1] != 0 ? 'selectback' : 'noselectback'"
          >
            <span
              v-show="select[1]"
              class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
              >{{ select[1] }}</span
            >
            <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/wscissors.webp" alt="" />
          </div>
          <div class="w-1/4 lg:hidden"></div>
          <div
            class="xl:p-10 lg:p-6 p-5 lg:mr-32 cursor-pointer relative"
            @click="selectindex(2)"
            :class="select[2] != 0 ? 'selectback' : 'noselectback'"
          >
            <span
              v-show="select[2]"
              class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
              >{{ select[2] }}</span
            >
            <img class="w-full" src="https://static.soulmeta.io/web/img/game-mora/wcloth.webp" alt="" />
          </div>
        </div>
        <div class="sm:w-96 w-4/5 sm:h-16 h-12 mx-auto flex mt-4 justify-center items-center break-all">
          <img v-for="item in selectSortList" :key="item.id" @click="selectSortFUN(item.id,item.name)" class="sm:h-10 h-6 px-1 mx-1 border-b-2 pb-2 border-black" :class="selectSort==item.id?'border-white':''" :src="item.imgUrl" alt="">         
        </div>
        <div
          class="sm:w-96 w-4/5 sm:h-16 h-12 mx-auto rounded-md overflow-hidden mt-4"
          style="background-color: #272727"
        >
          <input
            class="block w-2/3 sm:w-72 border-0 outline-none sm:h-16 h-12 px-4 sm:text-lg text-sm float-left"
            type="text"
            v-model="amount"
            :disabled="amountdisbale"
            style="background-color: #272727"
          />
          <span
            class="sm:w-24 w-1/3 float-left block text-center sm:leading-8 leading-6 sm:my-4 my-3 border-l border-white"
            >{{sortName}}</span
          >
        </div>
        <div class="flex flex-row lg:w-160 w-4/5 mx-auto lg:mt-16 mt-8">
          <div class="basis-1/4 text-center"></div>
          <div class="basis-1/2 text-center">
            <!-- <img @click="toplay" class="lg:h-16 h-10 block mx-auto  cursor-pointer" src="../assets/img/wtobtn.png" alt=""> -->
            <div
              @click="toplay"
              class="btnback w-40 lg:h-12 h-10 mx-auto text-center lg:leading-lh-3 leading-10 font-bold lg:text-lg text-sm cursor-pointer"
            >
              {{ $t("gameslobby.game14") }}
            </div>
          </div>
          <div class="basis-1/4 text-center">
            <img
              class="lg:h-12 h-10 block mx-auto cursor-pointer"
              src="https://static.soulmeta.io/web/img/game-mora/w-refresh.webp"
              alt=""
              @click="refresh()"
            />
          </div>
        </div>
      </div>
      <div
        class="w-full h-full bg-black opacity-80 fixed top-0 left-0 z-99"
        v-show="displayshow || resultsshow || resultsshowloss ||moveDrawer"
      ></div>
      
      <div
        class="fixed left-0 lg:hidden block z-10 recordback cursor-pointer w-8 h-20 top-1/2"
        @click="moveDrawer = true"
      >
        <img class="w-6 h-6 mt-7 ml-1" src="https://static.soulmeta.io/web/img/game-mora/wopenrecord.webp" alt="" />
      </div>
      <div
        class="fixed left-0 lg:block hidden z-10 recordback cursor-pointer"
        @click="drawer = true"
        style="top: calc(50% - 185px); height: 370px; width: 50px"
      >
        <img class="wopenrecord" src="https://static.soulmeta.io/web/img/game-mora/wopenrecord.webp" alt="" />
      </div>
     <div class="fixed bottom-0 left-0 bg-black w-full h-96 z-100" v-show="moveDrawer">
        <img src="https://static.soulmeta.io/web/img/game-mora/w-displayclose.webp" @click="moveDrawer=false" class="w-6 h-6 float-right mt-4 mr-4 mb-4" alt="">
        
            <p v-if="combatsData.length==0" class="text-center text-sm leading-lh-12 w-full float-left">{{$t("gameslobby.msg21")}}</p>
            <ul v-if="combatsData.length!=0" class="w-full h-80 block overflow-auto scrollstr">
              <li
                class="overflow-hidden border-b border-515 p-3"
                v-for="(item, index) in combatsData"
                :key="index"
              >
                <span
                  :class="item.resuleStart ? 'bg-amber-500' : 'bg-slate-200'"
                  class="w-12 h-8 text-sm text-center leading-8 rounded-lg float-left block"
                  >{{ item.resuleStart ? $t("gameslobby.game38") : $t("gameslobby.game37") }}</span
                >
                <strong
                  class="w-10 h-8 text-sm text-right leading-8 rounded-lg float-left inline-block"       
                       
                  >{{ item.resuleStart ? '+' : '-'}}{{item.resuleStart ? item.winBet/Math.pow(10, selectSortList[item.payType-1].dec) : item.bet/Math.pow(10, selectSortList[item.payType-1].dec) }}</strong
                >
                <img
                  class="h-8 p-2 float-left"
                  :src="selectSortList[item.payType-1]?.imgUrl!=undefined?selectSortList[item.payType-1].imgUrl:'https://static.soulmeta.io/web/img/home/logo.webp'"
                  alt=""
                />
                <p class="w-1/3 float-left  text-sm leading-8 truncate block ml-3">
                  {{$t("gameslobby.game36")}}：{{item.resuleAddress}}
                </p>
                <span
                  class="h-8 text-xs leading-8 text-center rounded-lg float-right block border px-2 border-slate-200"
                  >{{$t("gameslobby.game39")}}{{item.roomId}}</span
                >
                <div class="w-full float-left overflow-hidden">                  
                  <div class="w-1/3 float-left leading-8 mt-2">
                    <span class="inline-block float-left text-sm">{{$t("gameslobby.msg24")}}：</span>                  
                    <img v-for="(items,index) in item.ismora" :key="index" class="h-4 w-4 m-1 float-left" :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`" alt="">
                  </div>
                  <div class="w-1/3 float-left leading-8 mt-2">
                    <span class="inline-block float-left text-sm">{{$t("gameslobby.game36")}}：</span>
                    <img v-for="(items,index) in item.noismora" :key="index" class="h-4 w-4 m-1 float-left" :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`" alt="">
                  </div>
                  <div class="w-1/3 float-left leading-8 mt-2">
                      <span class="text-right block text-xs">{{toLocal(item.createTime)}}</span>
                  </div>
                </div>
              </li>
            </ul>
     </div>
      <el-drawer
        v-model="drawer"
        direction="ltr"
        size="800px"
        :with-header="false"
        :before-close="handleClose"
      >
        <div class="relative overflow-hidden">
          <div class="w-full">
            <h4 class="block text-center w-full text-2xl pb-4">{{$t("gameslobby.game40")}}</h4>
            <p v-if="combatsData.length==0" class="text-center text-lg leading-lh-12">{{$t("gameslobby.msg21")}}</p>
            <ul v-if="combatsData.length!=0" class="w-9/10 h-64 block pr-4 overflow-auto scrollstr">
              <li
                class="overflow-hidden border-b border-515 py-3 pl-10"
                v-for="(item, index) in combatsData"
                :key="index"
              >
                <span
                  :class="item.resuleStart ? 'bg-amber-500' : 'bg-slate-200'"
                  class="w-16 h-10 text-lg text-center leading-10 rounded-lg float-left block"
                  >{{ item.resuleStart ? $t("gameslobby.game38") : $t("gameslobby.game37") }}</span
                >
                <strong
                  class="w-20 h-10 text-lg text-right leading-10 rounded-lg float-left inline-block"
                  >{{ item.resuleStart ? '+' : '-'}}{{item.resuleStart ? item.winBet/Math.pow(10, selectSortList[item.payType-1].dec) : item.bet/Math.pow(10, selectSortList[item.payType-1].dec) }}</strong
                >
                <img
                  class="h-10 p-2 float-left"
                  :src="selectSortList[item.payType-1]?.imgUrl!=undefined?selectSortList[item.payType-1].imgUrl:'https://static.soulmeta.io/web/img/home/logo.webp'"
                  alt=""
                />
                <p class="w-72 float-left leading-10 truncate block ml-6">
                  {{$t("gameslobby.game36")}}：{{item.resuleAddress}}
                </p>
                <span
                  class="h-10 text-xs leading-10 text-center rounded-lg float-right block border px-3 border-slate-200"
                  >{{$t("gameslobby.game39")}}{{item.roomId}}</span
                >
                
                <div class="w-1/3 float-left leading-10 mt-2">
                  <span class="inline-block float-left">{{$t("gameslobby.msg24")}}：</span>                  
                  <img v-for="(items,index) in item.ismora" :key="index" class="h-8 w-8 m-1 float-left" :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`" alt="">
                </div>
                <div class="w-1/3 float-left leading-10 mt-2">
                  <span class="inline-block float-left">{{$t("gameslobby.game36")}}：</span>
                  <img v-for="(items,index) in item.noismora" :key="index" class="h-8 w-8 m-1 float-left" :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`" alt="">
                </div>
                <div class="w-1/3 float-left leading-10 mt-2">
                    <span class="text-right block">{{toLocal(item.createTime)}}</span>
                </div>
              </li>
            </ul>
          </div>
          <img
            class="rotate-180 absolute right-2 w-10 block cursor-pointer top-32"
            @click="drawer = false"
            src="https://static.soulmeta.io/web/img/game-mora/wopenrecord.webp"
            alt=""
          />
        </div>
      </el-drawer>
      <Footer />
    </div>
    
<div v-show="loading"  v-loading="loading" class="w-full fixed h-screen top-0 left-0 z-999" element-loading-background="rgba(0, 0, 0, 0.6)"></div>
  </div>
</template>

<style scoped lang="scss"></style>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
import { getEther } from "@/plugins/ethers";
import { numberFilter } from "../plugins/handleAmount";
import axios from "axios";
import { getCurrentInstance } from "vue";
export default {
  components: { Header, Footer },

  data() {
    return {
      moveDrawer:false,
      mobileevn:false,
      select: [0, 0, 0],
      soulNftList:[],
      soulNftToken:'',
      soulNftListimg:'',
      amountdisbale:false,
      loading:false,
      drawer: false,
      clickindex: 1,
      displayshow: false,
      resultsshow: false,
      resultsshowloss: false,
      dislogbordertype: 1,
      resulttext: 1,
      player1src: "",
      player2src: "",
      myBonus:0,
      amount: 0,
      resulttotal: '-',
      totalBonus:0,
      totalPledgeall: '-',
      totalBonusall: '-',
      selectin: 1,
      dislogsrc: "",
      roomid: "",
      dogfallroomid:'',
      imgindex: 0,
      roomlist: [],
      combatsData:[],
      soulmetaList:[],
      // 用于倒计时标记，true-正在倒计时
      countFlag: false,
      // 定时器
      intervalBtn: {},
      playintervalBtn:{},
      playStatus:{},
      roomset:{},
      newarr:[],
      selectSort:1,
      sortName:'BNB',
      selectSortList:[
        {'id':1,'name':'BNB','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele01.webp',payMin:0.02,dec:18},
        {'id':2,'name':'SOUL','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele11.webp',payMin:1,dec:18},
        {'id':3,'name':'KAKA','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele31.webp',payMin:1,dec:18},
        {'id':4,'name':'IZI','imgUrl':'https://izumi.finance/assets/home/iziLogo/logo.svg',payMin:1,dec:18},
        {'id':5,'name':'USDT','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele21.webp',payMin:1,dec:18},
        {'id':6,'name':'STI','imgUrl':'https://static.soulmeta.io/web/img/game-mora/w-gamesele41.webp',payMin:1,dec:10},
        {'id':7,'name':'FIST','imgUrl':'https://fstswap.finance/images/56/0xC9882dEF23bc42D53895b8361D0b1EDC7570Bc6A.png',payMin:1,dec:6},
        {'id':8,'name':'GMT','imgUrl':'https://s2.coinmarketcap.com/static/img/coins/64x64/18069.png',payMin:1,dec:8},
      ]
    };
  },
  computed: {
    // 计算属性的 getter
    selectLength() {
      let res = this.soulmetaList.filter((e) => {
        return e.select;
      });
      let restoken = res.map((e) => {
        return e.tokenId;
      });
      return restoken
    }
  },
  beforeRouteLeave(to, from, next) {    
    clearInterval(this.playintervalBtn);            
    clearInterval(this.roomset);   
    next();
  },
  async created() {
    // if(/iPhone/i.test(navigator.userAgent)){
    //   this.mobileevn=true
    //   return
    // }
    this.eth = await getEther();
     if (this.eth) {
      this.searchUserBonus();
      this.fishNft721()
      this.acquiregametota()
      this.getCombatData() 
       this.roomlistis()
       this.getNftList()
      this.roomset = setInterval(() => {
        this.roomlistis()
      }, 3000);
      let souldec=await this.eth.c.soul.decimals()
      this.selectSortList[1].dec=parseInt(souldec)
      let kakadec=await this.eth.c.kakaChain.decimals()
      this.selectSortList[2].dec=parseInt(kakadec)
      let izidec=await this.eth.c.iziChain.decimals()
      this.selectSortList[3].dec=parseInt(izidec)
      let usdtdec=await this.eth.c.usdt.decimals()
      this.selectSortList[4].dec=parseInt(usdtdec)
      let stidec=await this.eth.c.stiChain.decimals()
      this.selectSortList[5].dec=parseInt(stidec)
      let fistdec=await this.eth.c.fistChain.decimals()
      this.selectSortList[6].dec=parseInt(fistdec)
      let gmtdec=await this.eth.c.gmtChain.decimals()
      this.selectSortList[7].dec=parseInt(gmtdec)
    }
    
  },
  mounted() {
    this.amountdisbale=false  
    if(this.$route.query.roomid!=undefined){
      this.amountdisbale=true    
      this.dogfallroomid = this.$route.query.roomid
      this.displayshow = true;
      this.amount=this.$route.query.amount,
      this.selectSort=this.selectSortList[parseInt(this.$route.query.payType)-1].id
      this.sortName=this.selectSortList[parseInt(this.$route.query.payType)-1].name
    }
  },
  methods: {
    //时间转换
    toLocal(date){
      date = new Date(date);
      var local = date.toLocaleString('en-US', {
        hour12: false,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      return local;
    },
    // 关闭战绩
    handleClose() {
      this.drawer = false;
      this.moveDrawer=false
    },
    //跳转铸造NFT
    toCustomizationNFT(){
      if (/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)){        
        this.$message.error(this.$t("gameslobby.msg13"));
        return
      }
        this.$router.push({path: '/CustomizationNFT',query:{ 
        }});
    },
    // 截取小数两位
    subStringNum(a,num) {
    var a_type = typeof(a);
        if(a_type == "number"){
            var aStr = a.toString();
            var aArr = aStr.split('.');
        }else if(a_type == "string"){
            var aArr = a.split('.');
        }
        
        if(aArr.length > 1) {
            a = aArr[0] + "." + aArr[1].substr(0, num);
        }
        return a
    },
    // 切换币种
    selectSortFUN(id,name){ 
      if(this.amountdisbale==true) return
      this.selectSort=id
      this.sortName=name
    },
    
    // <!-- 显示操作框 -->
    showdislog(f, e,g,h,l,combatId,payType) {
      let that=this
      that.amountdisbale=false
      that.amount=0
      // if(that.soulNftList.length==0){
      //   that.$message.error(that.$t("gameslobby.msg20"));
      //   return
      // }
      if((that.$route.query.roomid==parseInt(f)+1)&&(l!=0)){
        that.dogfallroomid=parseInt(f)+1
      }
      if(l!=0&&that.dogfallroomid==""){
                 
        clearInterval(that.roomset);  
        that.$router.push({path: '/fightpage',query:{ 
          roomId:parseInt(f)+1,
          combatId:combatId
        }});
        return
      }
      if(h&&l==0){
        that.$message.error(that.$t("gameslobby.msg1"));
        return
      }
      if(g!=0){
        that.amount=g/Math.pow(10, that.selectSortList[payType-1].dec);
        that.amountdisbale=true
        if(payType==undefined){
          that.selectSort=2
          that.sortName='SOUL'
        }else{
          that.selectSort=that.selectSortList[payType-1].id
          that.sortName=that.selectSortList[payType-1].name
        }
      }
      that.roomid = f + 1;
      that.resulttext = e;
      that.dislogbordertype = e;
      that.displayshow = true;
    },
    async toplay() {
      let that = this;
      let newsa=['','','']
      that.select.forEach((e,index)=>{
        if(e!=0){
          newsa[e-1]=index+1
        }
      })
     let noselect = newsa.filter(e=>{return e!=''})
      if(noselect==''){        
        that.$message.error(that.$t("gameslobby.msg2"));
        return
      }
      //验证是否为正数并且为数字
      let reg = /^[+-]?(\d|([1-9]\d+))(\.\d+)?$/;
      if (!reg.test(that.amount) || that.amount <= 0) {
        that.$message.error(that.$t("gameslobby.msg17"));
        return;
      }
      if(that.amount<that.selectSortList[parseInt(that.selectSort)-1].payMin){
        that.$message.error(that.$t("gameslobby.msg25")+that.selectSortList[parseInt(that.selectSort)-1].payMin+' '+that.selectSortList[parseInt(that.selectSort)-1].name);
        return
      }
      
      var x = String(that.amount).indexOf(".") + 1; //小数点的位置
      var y = String(that.amount).length - x; //小数的位数
      if (x != 0 && y > 2) {
        that.$message.error(that.$t("gameslobby.msg18"));
        return;
      }      
      that.loading=true      
      let signMessage = '';
      try {
        signMessage = await that.eth.signer.signMessage(noselect.map(e=>{return parseInt(e)-1}).toString().replace(/,/g,""));
      } catch (e) {
        that.$message.error(e.message);
        that.loading=false
        return
      }
      if(that.dogfallroomid!=''){
        that.playerSetRPS(noselect.map(e=>{return parseInt(e)-1}).toString().replace(/,/g,""),signMessage,that.dogfallroomid,2)
        return
      
      }
      var chainFun=''
      if(that.selectSort==2){
        chainFun=that.eth.c.soul
      }else if(that.selectSort==3){
        chainFun=that.eth.c.kakaChain
      }else if(that.selectSort==4){
        chainFun=that.eth.c.iziChain
      }else if(that.selectSort==5){
        chainFun=that.eth.c.usdt
      }else if(that.selectSort==6){
        chainFun=that.eth.c.stiChain
      }else if(that.selectSort==7){
        chainFun=that.eth.c.fistChain
      }else if(that.selectSort==8){
        chainFun=that.eth.c.gmtChain        
      }
      //判断soul
     if(that.selectSort!=1){
    // 获取soul余额
        let soul = await chainFun.balanceOf(that.eth.myAddr);
        let soulBalance = parseFloat(soul) / Math.pow(10, that.selectSortList[parseInt(that.selectSort)-1].dec);
        // 判断余额是否小于当前输入余额
        if (
          parseFloat(soulBalance) <= 0 ||
          parseFloat(soulBalance) < parseFloat(that.amount)
        ) {
          that.$message.error(that.selectSortList[parseInt(that.selectSort)-1].name+that.$t("msg.msgA6"));
          that.loading=false
          return;
        }
        let allowance = await chainFun.allowance(
          that.eth.myAddr,
          that.eth.c.guessFist.address
        );
        // let soulAllowance = that.eth.utils.formatEther(allowance);
        let soulAllowance = parseFloat(allowance) / Math.pow(10, that.selectSortList[parseInt(that.selectSort)-1].dec);
        if (parseFloat(soulAllowance) < parseFloat(that.amount)) {        
          try {
            let allowances = await chainFun.approve(
            that.eth.c.guessFist.address,
            that.eth.constants.MaxUint256
          );
            await allowances.wait();
          } catch (e) {
            that.loading=false
            return
          }
        }
      }else{        
        let bnbBalance = await that.eth.provider.getBalance(that.eth.myAddr);
        let bnbBalances = that.eth.utils.formatEther(bnbBalance);
        if (
          parseFloat(bnbBalances) <= 0 ||
          parseFloat(bnbBalances) < parseFloat(that.amount)
        ) {
          that.$message.error(that.selectSortList[parseInt(that.selectSort)-1].name+that.$t("msg.msgA6"));
          that.loading=false
          return;
        }
      }
      let toamount = 0;
      // if (that.selectSort == 1) {  
        toamount = that.amount * Math.pow(10, that.selectSortList[parseInt(that.selectSort)-1].dec);
      // }
      try {
        let paygasFees= await that.eth.c.guessFist.gasFees()
        let getNonce=  await that.eth.signer.getTransactionCount()        
        let getGasnum=  await that.eth.signer.getGasPrice()
        var paygasFeesInt=that.eth.utils.parseEther((paygasFees / Math.pow(10, 18)).toString())
        if(that.selectSort==1){
          let bnbZong=((parseInt(paygasFees)+parseInt(toamount))/ Math.pow(10, 18)).toString()
          var paygasFeesInt=that.eth.utils.parseEther(bnbZong)
        }
        let args={
              // The maximum units of gas for the transaction to use
              gasLimit:400000,
              // The price (in wei) per unit of gas
              gasPrice: getGasnum,
              // The nonce to use in the transaction
              nonce: parseInt(getNonce),
              // The amount to send with the transaction (i.e. msg.value)
              value: paygasFeesInt,
        }
        let payresult= await that.eth.c.guessFist.enterRoom(that.roomid,toamount.toString(),that.resulttext,that.selectSort,args)
        if(payresult){
          this.playerSetRPS(noselect.map(e=>{return parseInt(e)-1}).toString().replace(/,/g,""),signMessage,that.roomid,1)
        }
      } catch (e) {
          this.$message.error(e.message); 
          this.loading=false
      }
    },
    //提交签名出拳信息
    async playerSetRPS(message,sign,roomId,sendType){
        // let inroomtrue = await this.eth.c.guessFist.inRoomId(this.eth.myAddr)
        //  ||inroomtrue>0
      // 设置倒计时
      this.playintervalBtn = setInterval(() => {
        axios.post("/3dnft-rps-api/playerSetRPS",{signature: sign,message:message,roomId:parseInt(roomId),tokenId:this.soulNftToken.toString(),type:sendType},
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        ).then(e =>{
          if(e.data.result == 1 || e.data.result == 3){
            this.displayshow = false
            this.select=[0,0,0]
            this.clickindex=1
            clearInterval(this.playintervalBtn);            
            clearInterval(this.roomset); 
            this.loading=false
            this.$router.push({path: '/fightpage',query:{ 
              roomId,
              combatId:e.data.combatId
            }});
            return
          }else if(e.data.result == 2){
            // clearInterval(this.playintervalBtn);              
            //  this.$message.error(this.$t("gameslobby.msg15")); 
            this.loading=false
          }
        }).catch(f =>{
          this.$message.error(this.$t("gameslobby.msg9")); 
          clearInterval(this.playintervalBtn); 
          this.loading=false
        })
      }, 5000);
    },
    // 获取战报
    getCombatData(){
       axios.post("/3dnft-rps-api/getCombatData",{type: 1,arg:this.eth.myAddr},
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        ).then(e =>{
          let that=this
          e.data.combatsData.forEach(f => {
            let resuleStart =false
            let resuleAddress = f.player2==that.eth.myAddr?f.player1:f.player2
            let ismora = f.player2==that.eth.myAddr?f.player2_RPS:f.player1_RPS
            let noismora = f.player2==that.eth.myAddr?f.player1_RPS:f.player2_RPS
            if((f.player1==that.eth.myAddr && f.winner==0)||f.player2==that.eth.myAddr && f.winner==1){
              resuleStart = true
            }
            if(f.payType==undefined||f.payType==null||f.payType==''){
              f.payType = 2
            }
            this.combatsData.push({
              resuleStart,
              ismora,
              noismora,
              resuleAddress,
              ...f
            })
          });
        }).catch(f =>{          
        })
    },
    // 获取房间数据
    roomlistis(){   
        axios.post("/3dnft-rps-api/checkAllRoomInfo",{address:this.eth.myAddr},
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        ).then(e =>{
          this.roomlist=e.data.rooms.map(f=>{
            f.player1url='https://static.soulmeta.io/nft/3dnft/'+f.player1_tokenId+'.png'
            f.player1ur2='https://static.soulmeta.io/nft/3dnft/'+f.player2_tokenId+'.png'
            return f
          })
          // this.roomlist=e.data.rooms
        }).catch(f =>{
        })
    },
    selectindex(e) {
      if (this.select[e] == 1) {
        let istwo = this.select.indexOf(2);
        let isthree = this.select.indexOf(3);
        if (istwo != -1) {
          this.select[istwo] = 1;
        }
        if (isthree != -1) {
          this.select[isthree] = 2;
        }
      }
      if (this.select[e] == 2) {
        let isthree = this.select.indexOf(3);
        this.select[isthree] = 2;
      }
      if (this.select[e] != 0) {
        this.select.splice(e, 1, 0);
        this.clickindex--;
        return;
      }
      this.select.splice(e, 1, this.clickindex);
      this.clickindex++;
    },
    // 点击刷新
    async refresh() {
      this.select = [0, 0, 0];
      this.clickindex = 1;
      if(!this.amountdisbale){
        this.amount = 0;
      }
    },
    selectNft(item){
      item.select = !item.select
    },
    //切换soulnft
    selectsoulNft(e){
      if(this.soulNftList.length==0) return
      if(e=0){
        this.imgindex--
      }else{
        this.imgindex++
      }
      if(this.imgindex==this.soulNftList.length) {
        this.imgindex=0
      }
      if(this.imgindex<0){
        this.imgindex=this.soulNftList.length
      }
      this.soulNftListimg=this.soulNftList[this.imgindex].image
      this.soulNftToken=this.soulNftList[this.imgindex].tokenId
    },
    // 数字截取
    numberToCurrency(data, cut) {
      return numberFilter(data, cut);
    },
    // 质押鱼塘NFT
    async pledeto(){
      if(this.selectLength.length==0){        
        this.$message.error(this.$t("gameslobby.msg7"));
        return
      }    
      this.loading=true 
      let isApprove = await this.eth.c.fishpondNFT.isApprovedForAll(this.eth.myAddr,this.eth.c.gameTotal.address);
      if (!isApprove) {
        try {
          let approve = await this.eth.c.fishpondNFT.setApprovalForAll(this.eth.c.gameTotal.address, true);
          await approve.wait();
        } catch {
          this.loading = false;
          return
        }
      } 
      let res = this.soulmetaList.filter((e) => {
        return e.select;
      });
      let residue = this.soulmetaList.filter((e) => {
        return !e.select;
      });
      let pledgeNftList = res.map((e) => {
        return e.tokenId;
      });
      this.eth.c.gameTotal.pledgeNft(pledgeNftList).then((result) => {   
          this.$message.success(this.$t("gameslobby.msg14"));
          // this.fishNft721()
          this.soulmetaList=residue
          this.loading=false
      })
      .catch((err) => {
          this.loading=false
          this.$message.error(this.$t("gameslobby.msg16"));
      });
    },
    //领取分红
    getUserBonusApi(){
      if(this.myBonus==0){
        return
      }
       this.loading=true
      this.eth.c.gameTotal.getUserBonusApi().then((result) => {
          this.$message.success(this.$t("gameslobby.msg11"));
          // this.searchUserBonus()
          this.totalBonus=parseFloat(this.totalBonus)+parseFloat(this.myBonus)
          this.loading=false
      })
      .catch((err) => {
        this.loading=false
          this.$message.error(this.$t("gameslobby.msg12"));
      });
    },
    //查询当前可领取的分红
    async searchUserBonus(){
      let result = await this.eth.c.gameTotal.searchUserBonus(this.eth.myAddr);
      let resulttotal = await this.eth.c.gameTotal.userInfos(this.eth.myAddr);
      this.myBonus=parseFloat(result)/ Math.pow(10, 18) 
      this.resulttotal=parseFloat(resulttotal.nft)
      this.totalBonus=parseFloat(resulttotal.accumulate)/ Math.pow(10, 18) 
    },
    //查询nft数量
    async fishNft721(){
      let that=this
      that.soulmetaList=[]
      let balance = await that.eth.c.fishNft.balanceOf(this.eth.myAddr);
      for (let i = 0; i <parseInt(balance); i++) {
        let tempTokenId = await that.eth.c.fishNft.tokenOfOwnerByIndex(that.eth.myAddr, i);
        let tempTokenURL = await that.eth.c.fishNft.tokenURI(tempTokenId);
        let tempTokenURLINFO = await axios.get(tempTokenURL)
        try {
          this.soulmetaList.push({
            tokenId:parseInt(tempTokenId),
            select:false,
          });          
        } catch (error) {
        
        }
      }
      // let that=this
      // that.soulmetaList=[]
      // let balance = await that.eth.c.fishNft.balanceOf(that.eth.myAddr);
      // for (let i = 0; i <parseInt(balance); i++) {
      //   let tempTokenId = await that.eth.c.fishNft.tokenOfOwnerByIndex(that.eth.myAddr, i);
      //   let tempTokenURL = await that.eth.c.fishNft.tokenURI(tempTokenId);
      //   let tempTokenURLINFO = await axios.get(tempTokenURL)
      //   try {
      //      this.soulmetaList.push({
      //       ...tempTokenURLINFO.data,
      //       tokenId:tempTokenId.toString(),
      //       select:false,
      //     });          
      //   } catch (error) {
          
      //   }
      // }
    },
    // 获取小人头像
    async getNftList(){
      let that=this
      let nftlist = await that.eth.c.sm3d.balanceOf(that.eth.myAddr);
      if(nftlist==0){
          that.soulNftListimg="https://static.soulmeta.io/nft/3dnft/193.png",          
          that.soulNftToken='193'
          return
      }
      for (let i = 0; i <parseInt(nftlist); i++) {
        let tempTokenId = await that.eth.c.sm3d.tokenOfOwnerByIndex(that.eth.myAddr, i);
        let tempTokenURL = await that.eth.c.sm3d.tokenURI(tempTokenId);
        let tempTokenURLINFO = await axios.get(tempTokenURL)
        if(i==0){
          that.soulNftListimg=tempTokenURLINFO.data.image,          
          that.soulNftToken=tempTokenId
        }
        try {
           that.soulNftList.push({
            ...tempTokenURLINFO.data,
            tokenId:tempTokenId.toString(),
            select:false,
          });          
        } catch (error) {
          
        }
      }
    },
    //查询总数
    async acquiregametota(){
       let result = await this.eth.c.gameTotal.lastSettleDay();
       let totalPledgeall = await this.eth.c.gameTotal.totalPledge(parseFloat(result));
       let totalBonusall = await this.eth.c.gameTotal.totalBonus();
       this.totalPledgeall=totalPledgeall
       this.totalBonusall=totalBonusall / Math.pow(10, 18)
    },
    
    // 取回NFT
     receiveNftTo(){
      this.loading=true
      this.eth.c.gameTotal.receiveNft().then((result) => {         
          this.$message.success(this.$t("gameslobby.msg8"));
          this.fishNft721()
          this.loading=false
      })
      .catch((err) => {
        this.loading=false
        if(err.code!=4001){
          this.$message.error(this.$t("gameslobby.msg10"));
        }
      });
     }
  },
};
</script>
<style scoped>
.gameroom {
  padding: 0px 20px;
  margin: 20px 0px;
  box-sizing: border-box;
}
.backpos {
  background: url("https://static.soulmeta.io/web/img/game-mora/wgameback.webp") no-repeat center/100% 100%;
}
.selectclick {
  background: url("https://static.soulmeta.io/web/img/game-mora/roomback1.webp") no-repeat center/100% 100%;
}
.backresults {
  transform: translate(-50%, -50%);
  background: url("https://static.soulmeta.io/web/img/game-mora/w-gamewin.webp") no-repeat center/100% 100%;
}
.backresultsloss {
  transform: translate(-50%, -50%);
  background: url("https://static.soulmeta.io/web/img/game-mora/w-gameloss.webp") no-repeat center/100% 100%;
}
.recordback {
  background: url("https://static.soulmeta.io/web/img/game-mora/wopenrecordback.webp") no-repeat center/100%
    100%;
}
.backdislogs {
  transform: translate(-50%, -50%);
  background: url("https://static.soulmeta.io/web/img/game-mora/wdislogback.webp") no-repeat center/100% 100%;
}
.selectback {
  border: 1px solid rgba(0, 0, 0, 0);
  background: url("https://static.soulmeta.io/web/img/game-mora/wdisselectback.webp") no-repeat center/100% 100%;
}
.selectclickt {
  background: url("https://static.soulmeta.io/web/img/game-mora/roomback2.webp") no-repeat center/100% 100%;
}
.instructions p {
  text-indent: 2em;
  font-size: 14px;
  line-height: 26px;
  font-weight: 400;
  overflow-wrap: break-word;
  color: #929292;
  font-weight: 500;
}
.instructions .showback {
  background: url("https://static.soulmeta.io/web/img/game-mora/w-instructionsback.webp") no-repeat;
}
.balanceback {
  background: url("https://static.soulmeta.io/web/img/game-mora/w-balanceback.webp") no-repeat center/100% 100%;
}
.btnback {
  background: url("https://static.soulmeta.io/web/img/game-mora/wbtnback.webp") no-repeat center/100% 100%;
}
.threeback {
  background: url("https://static.soulmeta.io/web/img/game-mora/w-threeback.webp") no-repeat center/100% 100%;
}
.noselectback {
  border: 1px solid #f9f9f9;
  box-sizing: border-box;
  border-radius: 10px;
}
.wopenrecord {
  width: 40px;
  padding-left: 5px;
  padding-top: 165px;
}
.scrollstr::-webkit-scrollbar {
  width: 4px;
}
.scrollstr::-webkit-scrollbar-thumb {
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #ffffff;
}
.scrollstr::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 0;
  background: #4e4e4e;
}
</style>
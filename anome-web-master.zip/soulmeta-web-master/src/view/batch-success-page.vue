<template>
  <div class="mintPage w-full h-full fixed top-0 left-0 z-100 bg-black">
    <div class="w-10/12 md:w-1/3 mx-auto">
      <h2 class="text-center text-2xl md:text-3xl font-semibold mt-20 md:mt-40 text-F02">{{ $t("batchOfBoxSucc.succ1") }}...</h2>
      <div class="py-10">
        <p class="text-sm md:text-xl text-center whitespace-pre-wrap mt-4">
          {{ $t("batchOfBoxSucc.succ2") }}
        </p>
        <p class="text-sm md:text-xl text-center whitespace-pre-wrap mt-4">{{ $t("batchOfBoxSucc.succ3") }} {{ quantity }} {{ $t("batchOfBoxSucc.succ4") }}</p>
      </div>
      <router-link to="/account">
        <img class="w-2/3 mx-auto" src="https://static.soulmeta.io/web/img/home/personal-center.webp" alt="" />
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      quantity: 0,
    };
  },
  created() {
    this.quantity = this.$route.params.quantity;
  },
};
</script>

<style lang="less" scoped></style>

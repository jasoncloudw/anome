<template>
  <div>
    <div class="account">
      <Header />
      <div class="lg:flex lg:justify-center lg:px-10 lg:mt-4">
        <div class="lg:w-200 xl:w-300 w-9/10 mx-auto">
          <img
            class="w-3 absolute top-6 md:hidden"
            src="https://static.soulmeta.io/web/img/home/return_icon.webp"
            alt=""
            @click="$router.push('/')"
          />
          <div
            class="w-40 lg:w-32 h-40 lg:h-32 mx-auto my-6 lg:my-0 lg:mb-2 px-4 border-8 rounded-full flex justify-center items-end bg-590"
          >
            <img
              class="w-full"
              src="https://static.soulmeta.io/web/img/home/logo.png"
              alt=""
            />
          </div>

          <div class="flex flex-col items-start justify-around">
            <!-- <div class="w-full mb-5 text-center">
                    <div class="text-sm">{{ $t('acc.acc1') }}</div>
                    <div class="w-full overflow-x-auto text-lg text-center font-semibold text-F02">{{ scientificComputing(usdtBalance) }}</div>
                </div> -->
            <div class="w-full text-xs text-center">{{ $t("acc.acc23") }}</div>
            <div class="w-full">
              <div class="lg:w-1/2 w-full float-left p-2 box-border">
                <div
                  class="w-full mt-2 p-2 py-4 border rounded-lg border-red-600"
                >
                  <div class="flex justify-between">
                    <div class="w-1/2">
                      <div class="text-xs">{{ $t("acc.acc1") }}</div>
                      <div
                        class="w-full overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(usdtBalance) }}
                      </div>
                    </div>
                    <div class="text-xs">{{ $t("acc.acc21") }}</div>
                  </div>
                  <!--                pancake-->
                  <div class="mt-3 flex justify-between items-end">
                    <div class="w-1/2">
                      <!-- {{ $t('acc.acc23') }} -->
                      <div class="text-xs">SOUL/USDT @PancakeSwap</div>
                      <div
                        class="w-full overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{
                          soulPricePancake
                            ? soulPricePancake.toFixed(6)
                            : "0.000000"
                        }}
                        <span class="font-mono">USDT</span>
                      </div>
                    </div>
                    <a
                      href="https://pancakeswap.finance/swap"
                      target="_blank"
                      class="text-xs"
                      >{{ $t("acc.acc51") }} ></a
                    >
                  </div>
                  <!--                dodo-->
                  <!-- <div class="mt-3 flex justify-between items-end">
                <div class="w-1/2">
                  <div class="text-xs">SOUL/USDT @DODO</div>
                  <div class="w-full overflow-x-auto custom-scrollbar text-sm font-semibold text-F02">
                    {{ soulPrice ? soulPrice.toFixed(6) : "0.000000" }} <span class="font-mono">USDT</span>
                  </div>
                </div>
                <a href="https://legacy.dodoex.io/exchange/USDT-SOUL?network=bsc-mainnet" target="_blank" class="text-xs">{{ $t("acc.acc22") }} ></a>
              </div> -->
                </div>
                <div class="w-full mt-5 flex justify-between">
                  <div class="text-xs">
                    <div>{{ $t("acc.acc24") }}：</div>
                    <div class="flex items-center">
                      https://bscscan.com..
                      <img
                        class="w-3 ml-2 cursor-pointer"
                        src="https://static.soulmeta.io/web/img/acc/copy.webp"
                        alt=""
                        @click="
                          doCopy(
                            'https://bscscan.com/token/0x9c2DcEB3fEBEC3b7245a0c2395aFdd92d9364862'
                          )
                        "
                      />
                    </div>
                  </div>
                  <div class="text-xs">
                    <div>{{ $t("acc.acc25") }}：</div>
                    <div class="flex items-center">
                      https://bscscan.com..
                      <img
                        class="w-3 ml-2 cursor-pointer"
                        src="https://static.soulmeta.io/web/img/acc/copy.webp"
                        alt=""
                        @click="
                          doCopy(
                            'https://bscscan.com/address/0x18d503A9bc476dB7fBe0BC067aF4DB2cA71C2D1b'
                          )
                        "
                      />
                    </div>
                  </div>
                </div>
                <div
                  class="w-full p-2 py-4 mt-5 border rounded-lg border-red-600 text-center"
                >
                  <div class="text-xs">{{ $t("acc.acc54") }}</div>
                  <div class="flex items-center mt-2.5">
                    <div class="w-1/4">
                      <div class="text-xs whitespace-nowrap">
                        {{ $t("acc.acc55") }}
                      </div>
                      <div class="text-F02 font-bold text-sm">
                        {{ scientificComputing(openBlindBoxGetSoulData.total) }}
                      </div>
                    </div>
                    <div class="w-1/4">
                      <div class="text-xs">{{ $t("acc.acc56") }}</div>
                      <div class="text-F02 font-bold text-sm">
                        {{ openBlindBoxGetSoulData.received }}
                      </div>
                    </div>
                    <div class="w-1/4">
                      <div class="text-xs">{{ $t("acc.acc57") }}</div>
                      <div class="text-F02 font-bold text-sm">
                        {{ openBlindBoxGetSoulData.available }}
                      </div>
                    </div>
                    <div class="w-1/4">
                      <div
                        v-loading="receiveOpenBXBtnLoading"
                        class="w-12 py-1 rounded-sm text-xs text-center cursor-pointer float-right"
                        :class="
                          openBlindBoxGetSoulData.available > 0
                            ? 'bg-F02'
                            : 'bg-gray-400'
                        "
                        @click="receiveOpenBlindBoxSoul"
                      >
                        {{ $t("acc.acc8") }}
                      </div>
                    </div>
                  </div>
                  <div class="text-xs text-left mt-2.5 text-yellow-200">
                    {{
                      $t("acc.acc58").replace(
                        "x%",
                        `${scientificComputing(openBlindBoxGetSoulData.rate)}%`
                      )
                    }}
                  </div>
                </div>
                <div
                  class="w-full p-2 py-4 mt-5 border rounded-lg border-red-600"
                >
                  <div class="flex justify-between items-center">
                    <div class="w-60 flex justify-between items-center">
                      <div class="text-center">
                        <div class="text-xs">{{ $t("acc.acc6") }}</div>
                        <div class="flex justify-center">
                          <div
                            class="max-w-20 overflow-x-auto text-sm font-semibold text-F02"
                          >
                            {{ scientificComputing(walletBox) }}
                          </div>
                          <div class="ml-1 text-sm">USDT</div>
                        </div>
                      </div>
                      <div class="text-center">
                        <div class="text-xs">{{ $t("acc.acc7") }}</div>
                        <div class="flex justify-center">
                          <div
                            class="max-w-20 overflow-x-auto text-sm font-semibold text-F02"
                          >
                            {{ scientificComputing(waitIncome) }}
                          </div>
                          <div class="ml-1 text-sm">USDT</div>
                        </div>
                      </div>
                    </div>
                    <div
                      v-loading="walletLoading"
                      :class="
                        Number(walletBox) > 0 ||
                        (Number(waitIncome) > 0 && !isReceiveReferralRewards)
                          ? 'bg-F02'
                          : 'bg-gray-400'
                      "
                      class="w-12 py-1 rounded-sm text-xs text-center cursor-pointer"
                      @click="receiveBenefits"
                    >
                      {{ $t("acc.acc8") }}
                    </div>
                  </div>
                  <div class="mt-2 text-xs text-yellow-200">
                    {{ $t("acc.acc50") }}
                  </div>
                </div>
              </div>
              <div class="lg:w-1/2 w-full float-left p-2 box-borde">
                <div
                  class="w-full p-2 py-4 mt-2 border rounded-lg border-red-600"
                >
                  <div class="flex justify-between items-center">
                    <div class="text-center">
                      <div class="text-xs">SOUL</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(soulBalance) }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc2") }}</div>
                      <div class="flex justify-center items-center text-xs">
                        0xBcD...11E
                        <img
                          class="w-3 ml-2 cursor-pointer"
                          src="https://static.soulmeta.io/web/img/acc/copy.webp"
                          alt=""
                          @click="
                            doCopy('0xBcD09729602EdeD7801EB30dc0Dc686b0222111E')
                          "
                        />
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc3") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto text-sm font-semibold text-F02"
                      >
                        {{ (yestodayWeights * 100).toFixed(2) + "%" }}
                      </div>
                    </div>
                    <div
                      class="w-12 py-1 rounded-sm text-xs text-center cursor-pointer"
                      :class="
                        Number(soulBalance) > 0 ? 'bg-F02' : 'bg-gray-400'
                      "
                      @click="toShowInjectBox"
                    >
                      {{ $t("acc.acc4") }}
                    </div>
                  </div>
                  <div class="flex justify-between items-center mt-2">
                    <div class="text-center">
                      <div class="text-xs">LP</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(lpBalance) }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc37") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(pledgeLpAmount) }}
                      </div>
                    </div>
                    <div
                      class="px-1 py-1 rounded-sm text-xs text-center cursor-pointer"
                      :class="Number(lpBalance) > 0 ? 'bg-F02' : 'bg-gray-400'"
                      @click="toPledgeLp"
                    >
                      {{ $t("acc.acc38") }}
                    </div>
                    <div
                      v-loading="getLpBtnLoading"
                      class="px-1 py-1 rounded-sm text-xs text-center cursor-pointer"
                      :class="
                        Number(pledgeLpAmount) > 0 ? 'bg-F02' : 'bg-gray-400'
                      "
                      @click="getLp"
                    >
                      {{ $t("acc.acc39") }}
                    </div>
                  </div>
                  <div class="flex justify-start items-center mt-2">
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc52") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(oldLpAmount) }}
                      </div>
                    </div>
                    <div
                      v-loading="getOldLpBtnLoading"
                      class="px-1 py-1 rounded-sm text-xs text-center cursor-pointer ml-4"
                      :class="
                        Number(oldLpAmount) > 0 ? 'bg-F02' : 'bg-gray-400'
                      "
                      @click="getOldLp"
                    >
                      {{ $t("acc.acc53") }}
                    </div>
                  </div>
                  <div class="mt-2 text-xs text-yellow-200">
                    {{ $t("acc.acc5") }}
                  </div>
                </div>
                <div
                  class="w-full p-2 py-4 mt-5 border rounded-lg border-red-600"
                >
                  <div class="flex justify-between items-center">
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc43") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(todaySoulAmount) }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc45") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(todayNFTAmount) }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc44") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ scientificComputing(todayLpAmount) }}
                      </div>
                    </div>
                  </div>
                  <div class="flex justify-between items-center">
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc46") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{
                          scientificComputing(cumulativeDestructionSoulAmount)
                        }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc47") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{
                          scientificComputing(cumulativeDestructionNFTAmount)
                        }}
                      </div>
                    </div>
                    <div class="text-center">
                      <div class="text-xs">{{ $t("acc.acc48") }}</div>
                      <div
                        class="max-w-20 overflow-x-auto custom-scrollbar text-sm font-semibold text-F02"
                      >
                        {{ (todayWeights * 100).toFixed(2) + "%" }}
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  class="w-full border border-red-600 rounded flex justify-between text-xs my-5 px-2.5 py-5"
                >
                  <div class="w-[45%]">
                    <div>
                      <div>
                        <span class="whitespace-nowrap">{{
                          $t("acc.acc26")
                        }}</span>
                      </div>
                      <div>
                        <span class="text-F02 font-bold text-sm">
                          {{ scientificComputing(accumulatedAvailable) }} </span
                        >&nbsp;USDT
                      </div>
                    </div>
                    <div class="mt-5">
                      <div class="flex items-center">
                        <span>{{ $t("acc.acc28") }}</span>
                        <el-popover
                          placement="top-start"
                          :width="200"
                          trigger="hover"
                          popper-style="font-size:12px"
                          :content="$t('acc.acc33')"
                        >
                          <template #reference>
                            <img
                              class="w-3 h-3"
                              src="https://static.soulmeta.io/web/img/acc/question.webp"
                              alt=""
                            />
                          </template>
                        </el-popover>
                      </div>
                      <div class="text-F02 font-bold text-sm">
                        {{ sliceDecimals(soulDestroysAPR)
                        }}{{
                          sliceDecimals(soulDestroysAPR) === "--" ? "" : "%"
                        }}
                      </div>
                    </div>
                    <div class="mt-5">
                      <div class="flex items-center">
                        <span>{{ $t("acc.acc30") }}</span>
                        <el-popover
                          placement="top-start"
                          :width="200"
                          trigger="hover"
                          popper-style="font-size:12px"
                          :content="$t('acc.acc35')"
                        >
                          <template #reference>
                            <img
                              class="w-3 h-3"
                              src="https://static.soulmeta.io/web/img/acc/question.webp"
                              alt=""
                            />
                          </template>
                        </el-popover>
                      </div>
                      <div class="text-F02 font-bold text-sm">
                        {{ sliceDecimals(lpApr)
                        }}{{ sliceDecimals(lpApr) === "--" ? "" : "%" }}
                      </div>
                    </div>
                  </div>
                  <div class="w-[45%]">
                    <div>
                      <div>{{ $t("acc.acc27") }}</div>
                      <div>
                        <span class="text-F02 font-bold text-sm">
                          {{ scientificComputing(dividendsReceived) }}</span
                        >&nbsp;USDT
                      </div>
                    </div>
                    <div class="mt-5">
                      <div class="flex items-center">
                        <span>{{ $t("acc.acc29") }}</span>
                        <el-popover
                          placement="top-start"
                          :width="200"
                          trigger="hover"
                          popper-style="font-size:12px"
                          :content="$t('acc.acc34')"
                        >
                          <template #reference>
                            <img
                              class="w-3 h-3"
                              src="https://static.soulmeta.io/web/img/acc/question.webp"
                              alt=""
                            />
                          </template>
                        </el-popover>
                      </div>
                      <div class="text-F02 font-bold text-sm">
                        {{ sliceDecimals(nftEvaluationAPR)
                        }}{{
                          sliceDecimals(nftEvaluationAPR) === "--" ? "" : "%"
                        }}
                      </div>
                    </div>
                    <div class="mt-5">
                      <div class="flex items-center">
                        <span>{{ $t("acc.acc31") }}</span>
                        <el-popover
                          placement="top-start"
                          :width="200"
                          trigger="hover"
                          popper-style="font-size:12px"
                          :content="$t('acc.acc36')"
                        >
                          <template #reference>
                            <img
                              class="w-3 h-3"
                              src="https://static.soulmeta.io/web/img/acc/question.webp"
                              alt=""
                            />
                          </template>
                        </el-popover>
                      </div>
                      <div class="text-F02 font-bold text-sm">
                        {{ sliceDecimals(totalApr)
                        }}{{ sliceDecimals(totalApr) === "--" ? "" : "%" }}
                      </div>
                    </div>
                  </div>
                  <div class="w-[10%]]">
                    <div
                      v-loading="getDividendsBtnLoading"
                      class="w-12 py-1 rounded-sm text-xs text-center cursor-pointer float-right"
                      :class="
                        Number(scientificComputing(accumulatedAvailable)) > 0
                          ? 'bg-F02'
                          : 'bg-gray-400'
                      "
                      @click="getDividends"
                    >
                      {{ $t("acc.acc8") }}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- <img class="my-5" src="https://static.soulmeta.io/web/img/acc/bor_img.webp" alt="" /> -->
            <!-- <div class="w-full text-center">
                    <div class="text-base">可领取的奖励</div>
                    <div class="w-full overflow-x-auto text-2xl text-center font-semibold text-F02">{{ scientificComputing(wallet) }} <span>U</span></div>
                </div> -->
          </div>
        </div>
        <!-- <div class="hidden lg:block w-2/3 xl:w-3/4 lg:h-160 relative">
          <iframe class="w-full h-full" src="https://3dnft.soulmeta.io" frameborder="0"></iframe>
          <div id="unity-container" class="unity-desktop" style="width: 100%; height: 100%; overflow: hidden">
            <canvas id="unity-canvas" width="100%" height="100%"></canvas>
            <div id="unity-loading-bar">
              <div id="unity-logo"></div>
              <div id="unity-progress-bar-empty">
                <div id="unity-progress-bar-full"></div>
              </div>
            </div>
            <div id="unity-warning"></div>
            <div id="unity-footer">
              <div id="unity-webgl-logo"></div>
              <div id="unity-fullscreen-button"></div>
              <div id="unity-build-title"></div>
            </div>
          </div>
        </div> -->
      </div>
      <div class="lg:w-200 xl:w-300 w-9/10 mx-auto">
        <div
          v-loading="loading"
          class="w-72 md:w-144 mx-auto mt-5 md:mt-10 flex justify-between text-center rounded-xl bg-2D2"
        >
          <div
            :class="nftType === 1 ? 'bg-F02' : ''"
            class="w-1/2 py-1 rounded-xl cursor-pointer md:text-2xl"
            @click="changeNav(1)"
          >
            {{ $t("acc.acc9") }}
          </div>
          <div
            :class="nftType === 2 ? 'bg-F02' : ''"
            class="w-1/2 py-1 rounded-xl cursor-pointer md:text-2xl"
            @click="changeNav(2)"
          >
            {{ $t("acc.acc10") }}
          </div>
        </div>

        <img
          class="mt-10 w-full"
          src="https://static.soulmeta.io/web/img/acc/bor_img.webp"
          alt=""
        />

        <div class="mt-5 md:mt-10 flex justify-between items-center">
          <div class="flex items-center">
            <div class="w-10 h-10 mr-3 border-2 rounded-full">
              <img
                class="w-8 mx-auto"
                src="https://static.soulmeta.io/web/img/home/logo.png"
                alt=""
              />
            </div>
            <div class="text-sm md:text-xl uppercase">soulmeta nft</div>
          </div>
          <div class="flex items-center">
            <div
              v-if="nftType === 1 && soulmetaList.length"
              class="bg-F02 rounded text-xs md:text-base px-2 md:px-4 py-1 mr-2 md:mr-4 cursor-pointer"
              @click="toEvaluate"
            >
              {{ $t("acc.acc42") }}
            </div>
            <div class="text-sm md:text-2xl">{{ soulmetaList.length }}</div>
          </div>
        </div>
        <div
          v-if="soulmetaList.length"
          class="h-24 md:h-60 lg:h-68 mt-3 md:mt-6 pl-5 flex"
        >
          <img
            class="w-1 mr-3"
            src="https://static.soulmeta.io/web/img/acc/icon3.webp"
            alt=""
          />
          <div class="flex items-center relative overflow-x-hidden w-full">
            <div class="swiper-container-soul">
              <div class="swiper-wrapper">
                <div
                  class="swiper-slide"
                  v-for="(item, index) in soulmetaList"
                  :key="index"
                >
                  <div
                    class="img-bg w-max md:w-4/5 md:h-48 lg:h-60 p-2 rounded-xl"
                  >
                    <div
                      class="h-16 md:h-full overflow-y-auto hidden-scrollbar flex justify-center items-center cursor-pointer"
                    >
                      <img
                        v-if="item.img"
                        class="w-16 md:w-full lg:h-full rounded-lg object-contain"
                        :src="item.img"
                        alt=""
                        @click="toDetail('/nft-detail', 0, item)"
                      />
                      <div
                        v-if="!item.img && nftType === 1"
                        class="w-16 md:w-full h-16 lg:h-full lg:max-h-max lg:p-2 rounded-lg text-xs md:text-xl flex items-center text-center"
                      >
                        {{ $t("acc.acc11") }}
                      </div>
                      <img
                        v-if="!item.img && nftType === 2"
                        class="w-16 md:w-32 rounded-lg cursor-pointer"
                        src="https://static.soulmeta.io/web/img/caste/file_bg.webp"
                        alt=""
                        @click="toDetail('/nft-detail', 0, item)"
                      />
                    </div>
                  </div>
                  <div
                    class="pr-5 md:pr-0 text-xs md:text-xl text-center md:w-4/5"
                  >
                    x {{ item.num }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div v-show="nftType === 1">
          <div class="mt-5 md:mt-10 font-semibold text-center md:text-3xl">
            {{ $t("acc.acc12") }}
          </div>
          <img
            class="mb-3 w-full md:mt-2.5"
            src="https://static.soulmeta.io/web/img/acc/bor_img.webp"
            alt=""
          />
        </div>
        <div v-show="nftType === 1">
          <div class="flex justify-between items-center">
            <div class="flex items-center">
              <img
                class="w-10 mr-3"
                src="https://static.soulmeta.io/web/img/acc/kaka_logo.webp"
                alt=""
              />
              <div class="text-sm md:text-xl uppercase">KAKAMETA</div>
            </div>
            <div class="text-sm md:text-2xl">{{ monsterList.length }}</div>
          </div>
          <div
            v-if="monsterList.length"
            class="h-24 md:h-60 mt-3 md:mt-6 pl-5 flex"
          >
            <img
              class="w-1 mr-3"
              src="https://static.soulmeta.io/web/img/acc/icon3.webp"
              alt=""
            />
            <div
              class="flex items-center relative overflow-x-hidden w-full hidden-scrollbar"
            >
              <div class="swiper-container-kaka">
                <div class="swiper-wrapper">
                  <div
                    class="swiper-slide"
                    v-for="(item, index) in monsterList"
                    :key="index"
                  >
                    <img
                      class="w-20 md:w-60 xl:w-80"
                      :src="item.img"
                      alt=""
                      @click="toDetail('/nft-detail', 1, item)"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div v-show="nftType === 1 && false">
          <div class="mt-5 flex justify-between items-center">
            <div class="flex items-center">
              <img
                class="w-10 mr-3"
                src="https://static.soulmeta.io/web/img/acc/fish_logo.webp"
                alt=""
              />
              <div class="text-sm md:text-xl uppercase">
                NAKAMOTO’S FISHPOND
              </div>
            </div>
            <div class="text-sm">{{ fishList.length }}</div>
          </div>
          <div v-if="fishList.length" class="h-24 mt-3 pl-5 flex">
            <img
              class="w-1 mr-3"
              src="https://static.soulmeta.io/web/img/acc/icon3.webp"
              alt=""
            />
            <div class="flex items-center relative overflow-x-hidden">
              <div class="swiper-container-fish">
                <div class="swiper-wrapper">
                  <div
                    class="swiper-slide"
                    v-for="(item, index) in fishList"
                    :key="index"
                  >
                    <img
                      class="w-16"
                      :src="item.img"
                      alt=""
                      @click="toDetail('/nft-detail', 2, item)"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
    <!-- evaluate box -->
    <div
      class="fixed inset-0 z-99 bg-black bg-opacity-70 overflow-hidden"
      v-show="showEvaluateBox"
    >
      <div
        v-loading="loadingEvaluateBox"
        class="w-9/10 md:w-auto absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 rounded-xl border border-red-500 bg-black py-4 md:py-8"
      >
        <div
          class="flex items-center justify-between px-2 md:px-8 pb-2 md:pb-6"
        >
          <img
            class="w-3 cursor-pointer"
            src="https://static.soulmeta.io/web/img/home/return_icon.webp"
            alt=""
            @click="closeEvaluate"
          />
          <div class="flex items-center justify-between">
            <img
              class="w-8 mr-7 cursor-pointer"
              src="https://static.soulmeta.io/web/img/acc/to_up.webp"
              alt=""
              @click="destoryNft(1)"
            />
            <img
              class="w-8 cursor-pointer"
              src="https://static.soulmeta.io/web/img/acc/to_down.webp"
              alt=""
              @click="destoryNft(2)"
            />
          </div>
        </div>
        <ul
          class="grid grid-cols-3 gap-4 md:gap-8 h-80 md:h-120 px-2 md:px-8 justify-center overflow-x-hidden overflow-y-scroll custom-scrollbar custom-y-scrollbar"
        >
          <li
            class="w-24 md:w-48 h-24 md:h-48 border-2 border-white rounded relative"
            v-for="(item, index) in evaluateList"
            :key="item.tokenId"
            @click="handleEvalute(index)"
          >
            <img
              v-if="item.img"
              class="w-full h-full rounded-lg object-scale-down"
              :src="item.img"
              alt=""
            />
            <div v-if="!item.img" class="w-full h-full"></div>
            <div class="w-5 h-5 absolute -right-1 -bottom-1 z-10">
              <img
                v-if="item.selected"
                class="w-full"
                src="https://static.soulmeta.io/web/img/acc/selected.webp"
                alt=""
              />
              <img
                v-else
                class="w-full"
                src="https://static.soulmeta.io/web/img/acc/unselected.webp"
                alt=""
              />
            </div>
          </li>
        </ul>
      </div>
    </div>
    <!-- inject box -->
    <div
      class="fixed inset-0 z-50 bg-black bg-opacity-70"
      v-show="showInjectBox"
      v-loading="injectLoading"
    >
      <div
        class="bg-black absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-9/10 md:w-108 border rounded-xl border-red-600 bg-opacity-70 m-auto px-3 md:px-6"
      >
        <h2 class="pt-5 md:pt-8 text-center md:text-xl">
          {{ $t("acc.acc32") }}
        </h2>
        <div class="text-center mt-5 md:mt-8 flex justify-center">
          <input
            v-model.trim="injectNum"
            class="input-bg mx-2 w-full h-8 md:h-11 xl:h-14 rounded-full outline-none text-center md:text-2xl"
            @input="handleInjectNum"
          />
        </div>
        <div class="mt-4 text-xs text-yellow-200 text-center">
          {{ $t("acc.acc49") }}
        </div>
        <div class="flex justify-around py-5 md:py-8">
          <div
            class="w-1/3 py-1 md:py-2 rounded-lg text-center cursor-pointer bg-F02 md:text-xl"
            @click="injected"
          >
            {{ $t("acc.acc4") }}
          </div>
          <div
            class="w-1/3 py-1 md:py-2 rounded-lg text-center cursor-pointer bg-F02 md:text-xl"
            @click="closeInjectBox"
          >
            {{ $t("acc.acc20") }}
          </div>
        </div>
      </div>
    </div>
    <!-- peldge box -->
    <div
      class="fixed inset-0 z-50 bg-black bg-opacity-70"
      v-show="showPledgeLpBox"
      v-loading="pledgeLpLoading"
    >
      <div
        class="bg-black absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-9/10 md:w-108 border rounded-xl border-red-600 bg-opacity-70 m-auto px-3 md:px-6"
      >
        <h2 class="pt-5 md:pt-8 text-center md:text-xl">
          {{ $t("acc.acc40") }}
        </h2>
        <div class="text-center mt-5 md:mt-8 flex justify-center">
          <input
            v-model.trim="pledgeLpNum"
            class="input-bg mx-2 w-full h-8 md:h-11 xl:h-14 rounded-full outline-none text-center md:text-2xl"
            @input="handlePledgeLpNum"
          />
        </div>
        <div class="flex justify-around py-5 md:py-8">
          <div
            class="w-1/3 py-1 md:py-2 rounded-lg text-center cursor-pointer bg-F02 md:text-xl"
            @click="pledgeLp"
          >
            {{ $t("acc.acc41") }}
          </div>
          <div
            class="w-1/3 py-1 md:py-2 rounded-lg text-center cursor-pointer bg-F02 md:text-xl"
            @click="closePledgeLpBox"
          >
            {{ $t("acc.acc20") }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
import Swiper from "swiper";
import { getEther } from "@/plugins/ethers";
import { inputAmount } from "@/plugins/handleAmount";

export default {
  name: "account",
  components: { Header, Footer },
  data() {
    return {
      loading: true,
      walletLoading: false,
      nftType: 1,
      soulBalance: 0,
      usdtBalance: 0,
      soulPrice: 0,
      soulPricePancake: 0,
      dividend: 0,
      yestodayWeights: "0.00",
      todayWeights: "0.00",
      waitIncome: 0,
      award: 0,
      walletBox: 0,
      soulmetaList: [],
      fishList: [],
      monsterList: [],
      soulBox: 0,
      perViewNum: 3,
      showEvaluateBox: false,
      showEvaluteSite: 0,
      loadingEvaluateBox: false,
      lpBalance: 0,
      pledgeLpAmount: 0,
      oldLpAmount: 0,
      todayLpAmount: 0,
      todaySoulAmount: 0,
      todayNFTAmount: 0,
      yesterdayUserData: 0,
      cumulativeDestructionSoulAmount: 0,
      cumulativeDestructionNFTAmount: 0,
      dividendsAmount: 0,
      dividendsReceived: 0,
      accumulatedAvailable: 0,
      soulDestroysAPR: 0,
      nftEvaluationAPR: 0,
      lpApr: 0,
      totalApr: 0,
      showInjectBox: false,
      showPledgeLpBox: false,
      injectNum: "",
      pledgeLpNum: "",
      injectLoading: false,
      pledgeLpLoading: false,
      getDividendsBtnLoading: false,
      getLpBtnLoading: false,
      getOldLpBtnLoading: false,
      isReceiveReferralRewards: false,
      receiveOpenBXBtnLoading: false,
      openBlindBoxGetSoulData: {
        total: 0,
        received: 0,
        available: 0,
        rate: 0,
      },
    };
  },
  computed: {
    evaluateList() {
      return this.soulmetaList.map((item) => {
        item.selected = false;
        return item;
      });
    },
  },
  methods: {
    handlePledgeLpNum() {
      if (Number(this.pledgeLpNum) > Number(this.lpBalance)) {
        this.pledgeLpNum = this.scientificComputing(this.lpBalance);
        return;
      }
      this.pledgeLpNum = inputAmount(this.pledgeLpNum);
    },
    toPledgeLp() {
      if (Number(this.lpBalance) <= 0) return;
      this.showPledgeLpBox = true;
    },
    async pledgeLp() {
      this.pledgeLpLoading = true;
      let lpApproveNum = await this.eth.c.lp.allowance(
        this.eth.myAddr,
        this.eth.c.bonus.address
      );
      if (lpApproveNum.eq(0)) {
        try {
          let approve = await this.eth.c.lp.approve(
            this.eth.c.bonus.address,
            this.eth.constants.MaxUint256
          );
          await approve.wait();
        } catch (e) {
          this.pledgeLpLoading = false;
        }
      }
      try {
        let amount = this.eth.utils.parseUnits(this.pledgeLpNum, 18);
        let res = await this.eth.c.bonus.inputTokenApi(amount);
        await res.wait();
        this.getUserBalance();
        this.getPledgeLpData();
        this.getTodayDividendsData();
      } catch (e) {
        this.pledgeLpLoading = false;
        this.showPledgeLpBox = false;
        this.pledgeLpNum = "";
      }
      this.pledgeLpLoading = false;
      this.showPledgeLpBox = false;
      this.pledgeLpNum = "";
    },
    async getLp() {
      if (Number(this.pledgeLpAmount) <= 0) return;
      this.getLpBtnLoading = true;
      try {
        let res = await this.eth.c.bonus.receiveTokenApi();
        await res.wait();
        this.getPledgeLpData();
        this.getUserBalance();
        this.getTodayDividendsData();
      } catch {
        this.getLpBtnLoading = false;
      }
      this.getLpBtnLoading = false;
    },
    async getOldLp() {
      if (Number(this.oldLpAmount) <= 0) return;
      this.getOldLpBtnLoading = true;
      try {
        let res = await this.eth.c.bonus.receiveOldLp();
        await res.wait();
        this.getOldPledgeLpData();
      } catch {
        this.getOldLpBtnLoading = false;
      }
      this.getOldLpBtnLoading = false;
    },
    closePledgeLpBox() {
      this.showPledgeLpBox = false;
      this.pledgeLpNum = "";
    },
    toShowInjectBox() {
      if (Number(this.soulBalance) <= 0) return;
      this.showInjectBox = true;
    },
    closeInjectBox() {
      this.showInjectBox = false;
      this.injectNum = "";
    },
    handleInjectNum() {
      if (Number(this.injectNum) > Number(this.soulBalance)) {
        this.injectNum = this.scientificComputing(this.soulBalance);
        return;
      }
      this.injectNum = inputAmount(this.injectNum);
    },
    async injected() {
      this.injectLoading = true;
      let lpApproveNum = await this.eth.c.soul.allowance(
        this.eth.myAddr,
        this.eth.c.bonus.address
      );
      if (lpApproveNum.eq(0)) {
        try {
          let approve = await this.eth.c.soul.approve(
            this.eth.c.bonus.address,
            this.eth.constants.MaxUint256
          );
          await approve.wait();
        } catch {
          this.injectLoading = false;
        }
      }
      try {
        let amount = this.eth.utils.parseUnits(this.injectNum, 18);
        let res = await this.eth.c.bonus.inputSoulApi(amount);
        await res.wait();
        this.getUserBalance();
        this.getTodayDividendsData();
        this.cumulativeDestoryData();
      } catch (e) {
        this.injectLoading = false;
        this.showInjectBox = false;
        this.injectNum = "";
      }
      this.injectLoading = false;
      this.showInjectBox = false;
      this.injectNum = "";
    },
    async getDividends() {
      if (Number(this.accumulatedAvailable) <= 0) return;
      this.getDividendsBtnLoading = true;
      let usdtApproveNum = await this.eth.c.usdt.allowance(
        this.eth.myAddr,
        this.eth.c.bonus.address
      );
      if (usdtApproveNum.eq(0)) {
        let approve = await this.eth.c.usdt.approve(
          this.eth.c.bonus.address,
          this.eth.constants.MaxUint256
        );
        await approve.wait();
      }
      try {
        let res = await this.eth.c.bonus.getUserBonusApi();
        await res.wait();
        this.getUserBalance();
        this.getYesterdayDividendsData();
      } catch (e) {
        // console.log(e, "e");
      }
      this.getDividendsBtnLoading = false;
    },
    async destoryNft(type) {
      let tokenIds = [];
      this.evaluateList.forEach((item) => {
        if (item.selected === true) {
          tokenIds.push(item.tokenId);
        }
      });
      if (!tokenIds.length) return;

      this.loadingEvaluateBox = true;
      let soul1155ApproveStatus = await this.eth.c.soul1155.isApprovedForAll(
        this.eth.myAddr,
        this.eth.c.bonus.address
      );

      if (!soul1155ApproveStatus) {
        try {
          let approve = await this.eth.c.soul1155.setApprovalForAll(
            this.eth.c.bonus.address,
            true
          );
          await approve.wait();
        } catch {
          this.loadingEvaluateBox = false;
        }
      }

      try {
        let res = await this.eth.c.bonus.inputNftApi(type, tokenIds);
        await res.wait();
        this.showEvaluateBox = false;
        await this.getData();
        this.soulmetaList = [];
        this.loading = true;
        await this.getSoulmeta();
        this.swiperSoul();
        this.loading = false;

        this.loadingEvaluateBox = false;
      } catch {
        this.loadingEvaluateBox = false;
      }
    },
    async toEvaluate() {
      this.showEvaluteSite = document.documentElement.scrollTop;
      this.showEvaluateBox = true;
    },
    handleEvalute(index) {
      this.evaluateList[index].selected = !this.evaluateList[index].selected;
    },
    closeEvaluate() {
      this.showEvaluateBox = false;
      setTimeout(() => {
        document.documentElement.scrollTop = this.showEvaluteSite;
      }, 0);
    },
    doCopy(text) {
      this.$copyText(text).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },
    sliceDecimals(data, n) {
      if (!n) n = 2;
      if (+data === 0) return 0 + "." + "0".repeat(n);
      if (!+data || data === Infinity || data === -Infinity) return "--";
      let arrStr = data.toString().split(".");
      if (arrStr[0] == data) return +data + "." + "0".repeat(n);

      if (arrStr[1].length > n) {
        return arrStr[0] + "." + arrStr[1].slice(0, n);
      } else return arrStr[0] + "." + arrStr[1].padEnd(n, "0");
    },
    scientificComputing(num) {
      let numStr = String(num);
      if (numStr.indexOf(".") === -1) {
        numStr = numStr + ".";
      }
      let strLeft = numStr.split(".")[0];
      let str = "";
      let index = numStr.split("").indexOf(".");
      str =
        (numStr.split("")[index + 1] ? numStr.split("")[index + 1] : "0") +
        (numStr.split("")[index + 2] ? numStr.split("")[index + 2] : "0");
      return strLeft + "." + str;
    },
    async changeNav(type) {
      this.loading = true;
      this.soulmetaList = [];
      this.nftType = type;
      try {
        await this.getSoulmeta();
      } catch (error) {
        this.loading = false;
      }
      this.swiperSoul();
      this.swiperKaka();
      // this.swiperFish();
    },
    toDetail(path, nft, item) {
      this.$router.push({
        path,
        query: {
          type: this.nftType,
          nftType: nft,
          tokenId: item.tokenId,
          cardId: item.cardId,
        },
      });
    },
    swiperSoul() {
      //调用延迟加载 $nextTick
      this.$nextTick(() => {
        let swiper = new Swiper(".swiper-container-soul", {
          slidesPerView: this.perViewNum,
        });
      });
    },
    swiperKaka() {
      //调用延迟加载 $nextTick
      this.$nextTick(() => {
        let swiper = new Swiper(".swiper-container-kaka", {
          slidesPerView: this.perViewNum,
        });
      });
    },
    swiperFish() {
      //调用延迟加载 $nextTick
      this.$nextTick(() => {
        let swiper = new Swiper(".swiper-container-fish", {
          slidesPerView: this.perViewNum,
        });
      });
    },
    async receiveBenefits() {
      if (
        Number(this.walletBox) > 0 ||
        (Number(this.waitIncome) > 0 && !this.isReceiveReferralRewards)
      ) {
        this.walletLoading = true;
        try {
          let res = await this.eth.c.controller.reward();
          await res.wait();
          this.getData();
          this.walletLoading = false;
        } catch (error) {
          this.walletLoading = false;
        }
      }
    },
    async getSoulmeta() {
      // soulmeta查询 查余额 -> 拿ID -> 取图片 -> 获取nft数量
      let idList = []; // tokenID
      let addrList = [];
      let tokenIdList = []; //  tokenID数量

      let chainId = window.ethereum.chainId;
      if (parseInt(chainId) === 97 && this.nftType === 1) {
        for (let j = 0; j <= 16; j++) {
          const tempIdList = [];
          for (let i = j * 500 + 1; i <= (j + 1) * 500; i++) {
            tempIdList.push(i);
          }
          const tempAddrList = new Array(tempIdList.length).fill(
            this.eth.myAddr
          );
          const tempTokenIdList = tempAddrList.length
            ? await this.eth.c.soul1155.balanceOfBatch(tempAddrList, tempIdList)
            : []; // 1155数量[]
          idList = idList.concat(
            tempIdList.filter((item, i) => !tempTokenIdList[i].eq(0))
          );
          tokenIdList = tokenIdList.concat(
            tempTokenIdList.filter((item) => !item.eq(0))
          );
        }
        await this.handleNftData(idList, tokenIdList);
        return;
      }

      if (this.nftType === 2) {
        let balance = await this.eth.c.soul721.balanceOf(this.eth.myAddr);

        let tempIdList = [];
        for (let i = 0; i < balance; i++) {
          let tempTokenId = await this.eth.c.soul721.tokenOfOwnerByIndex(
            this.eth.myAddr,
            i
          );
          tempIdList.push(parseInt(tempTokenId));
        }

        addrList = new Array(tempIdList.length).fill(this.eth.c.store.address);
        idList = tempIdList;
      } else if (this.nftType === 1) {
        const tempIdList = await this.eth.c.soul1155.getTokenIdList(
          this.eth.myAddr
        );
        idList = tempIdList.map((item) => item.toNumber());
        addrList = new Array(idList.length).fill(this.eth.myAddr);
      }

      tokenIdList = addrList.length
        ? await this.eth.c.soul1155.balanceOfBatch(addrList, idList)
        : [];
      await this.handleNftData(idList, tokenIdList);
    },
    async handleNftData(idList, tokenIdList) {
      let imgId = [];
      let nftInfo = await this.getSoulImg(idList);
      nftInfo.forEach((itm) => imgId.push(itm.token_id));

      let nums = [];
      idList.forEach((id, index) => {
        nums.push(parseInt(tokenIdList[index]));
        let ele = nftInfo[imgId.indexOf(id)];
        if (nums[index] !== 0) {
          this.soulmetaList.push({
            tokenId: imgId.indexOf(id) !== -1 ? ele.token_id : id,
            img: imgId.indexOf(id) !== -1 ? ele.img_url : "",
            num: nums[index],
            name: "SOULMETA",
          });
        }
      });

      this.loading = false;
      this.$store.commit("setSoulmetaList", this.soulmetaList);
    },
    async getSoulImg(tokenIds) {
      let res = await this.$axios.post(
        "/api/soul/get_nft_list",
        JSON.stringify({ token_ids: tokenIds })
      );
      if (res.status === 200 && res.data.resultCode === 0) {
        return res.data.data;
      }
    },
    async getMyNfts() {
      const promises = [];
      let balance;
      balance = await this.eth.c.rabbit.balanceOf(this.eth.myAddr);
      balance = parseInt(balance);
      for (let i = 0; i < balance; i++) {
        const p = async () => {
          let tokenId = await this.eth.c.rabbit.tokenOfOwnerByIndex(
            this.eth.myAddr,
            i
          );
          let cardId = await this.eth.c.rabbit.cardIdMap(tokenId);
          let uri = await this.eth.c.rabbit.tokenURI(tokenId);
          let uriRes = await this.$axios.get(uri);
          return { tokenId, cardId, uriRes };
        };
        promises.push(p());
      }
      balance = await this.eth.c.fishNft.balanceOf(this.eth.myAddr);
      balance = parseInt(balance);
      for (let i = 0; i < balance; i++) {
        const p = async () => {
          let tokenId = await this.eth.c.fishNft.tokenOfOwnerByIndex(
            this.eth.myAddr,
            i
          );
          let cardId = await this.eth.c.fishNft.cardIdMap(tokenId);
          let uriRes = await this.$axios.get(
            "https://test.btcfish.io/nft-info/ngi/" +
              parseInt(cardId) +
              "/" +
              tokenId
          );
          let type = "fish";
          return { tokenId, cardId, uriRes, type };
        };
        promises.push(p());
      }
      const res = await Promise.allSettled(promises);
      for (let item of res) {
        if (item.status !== "fulfilled") continue;
        // const tokenId = this.$utils.toHex(item.value.tokenId)
        const cardId = +item.value.cardId
          ? +item.value.cardId
          : item.value.cardId;
        if (item.value.type === "fish") {
          this.fishList.push({
            tokenId: this.$utils.toHex(item.value.tokenId),
            cardId: cardId,
            name: item.value.uriRes.data.name,
            img: item.value.uriRes.data.image,
          });
          this.$store.commit("setFishList", this.fishList);
        } else if (cardId === 110001) {
          let data = item.value.uriRes.data;
          this.monsterList.push({
            tokenId: item.value.tokenId.toString(),
            cardId: cardId,
            img: data.image,
            name: "KAKA Monster",
          });
          this.$store.commit("setMonsterList", this.monsterList);
        }
      }
    },
    async getData() {
      let wallet = await this.eth.c.controller.castWallet(this.eth.myAddr);
      let tabAmount = await this.eth.c.controller.totalAmount();
      let referrersWallet = await this.eth.c.controller.referWallet(
        this.eth.myAddr
      );
      let soulBala = await this.eth.c.soul.balanceOf(this.eth.c.lp.address);
      let usdtBala = await this.eth.c.usdt.balanceOf(this.eth.c.lp.address);
      this.dividend = this.eth.utils.formatEther(tabAmount.platform);
      this.waitIncome = this.eth.utils.formatEther(referrersWallet);
      this.walletBox = this.eth.utils.formatEther(wallet);
      this.soulPrice =
        this.eth.utils.formatEther(usdtBala) /
        this.eth.utils.formatEther(soulBala);
      {
        const soulBala = await this.eth.c.soul.balanceOf(
          this.eth.c.pancakeLp.address
        );
        const usdtBala = await this.eth.c.usdt.balanceOf(
          this.eth.c.pancakeLp.address
        );
        this.soulPricePancake =
          this.eth.utils.formatEther(usdtBala) /
          this.eth.utils.formatEther(soulBala);
      }

      let referralRewardsCount = await this.eth.c.controller.userInfos(
        this.eth.myAddr
      );
      let time = Number.parseInt(Date.now() / (1000 * 60 * 60 * 24));
      if (parseInt(referralRewardsCount) == time) {
        this.isReceiveReferralRewards = true;
      }
      this.getUserBalance();
      this.getOpenBlindBoxSoulData();
      this.getPledgeLpData();
      this.getOldPledgeLpData();
      this.getTodayDividendsData();
      this.getYesterdayDividendsData();
      this.cumulativeDestoryData();
    },
    async getUserBalance() {
      let soul = await this.eth.c.soul.balanceOf(this.eth.myAddr);
      let usdt = await this.eth.c.usdt.balanceOf(this.eth.myAddr);
      let lp = await this.eth.c.lp.balanceOf(this.eth.myAddr);
      this.soulBalance = this.eth.utils.formatEther(soul);
      this.usdtBalance = this.eth.utils.formatEther(usdt);
      this.lpBalance = this.eth.utils.formatEther(lp);
    },
    async getPledgeLpData() {
      let data = await this.eth.c.bonus.userInfos(this.eth.myAddr);
      this.pledgeLpAmount = this.eth.utils.formatEther(data.lp);
    },
    async getOldPledgeLpData() {
      let data = await this.eth.c.bonus.userInfos(this.eth.myAddr);
      this.oldLpAmount = data.isChangeLp
        ? this.eth.utils.formatEther(data.oldLp)
        : this.eth.utils.formatEther(data.lp);
    },
    async getTodayDividendsData() {
      const utils = this.eth.utils;
      let time = Number.parseInt(Date.now() / (1000 * 60 * 60 * 24));
      // let time = Number.parseInt(Date.now() / (1000 * 900));

      // 个人用户当天数据
      let todayData = await this.eth.c.bonus.dayToDayToken(
        time,
        this.eth.myAddr
      );
      let ysetodayData = await this.eth.c.bonus.dayToDayToken(
        time - 1,
        this.eth.myAddr
      );

      this.todayLpAmount = this.pledgeLpAmount;
      this.todaySoulAmount = todayData.soul.gt(ysetodayData.soul)
        ? utils.formatEther(todayData.soul.sub(ysetodayData.soul))
        : 0.0;
      this.todayNFTAmount = todayData.nft.gt(ysetodayData.nft)
        ? parseInt(todayData.nft.sub(ysetodayData.nft))
        : 0.0;

      // 所有用户当天数据
      let totalData = await this.eth.c.bonus.totalDayToken(time);
      let { lp } = await this.eth.c.bonus.userInfos(this.eth.myAddr);

      this.todayWeights = utils.formatEther(
        lp
          .mul(utils.parseEther("0.4"))
          .div(totalData.lp)
          .add(todayData.soul.mul(utils.parseEther("0.3")).div(totalData.soul))
          .add(todayData.nft.mul(utils.parseEther("0.3")).div(totalData.nft))
      );
    },
    async getYesterdayDividendsData() {
      let soulTotal = await this.eth.c.soul.balanceOf(this.eth.c.lp.address);
      let usdtTotal = await this.eth.c.usdt.balanceOf(this.eth.c.lp.address);
      let data = await this.eth.c.bonus.searchUserBonusApi(this.eth.myAddr);

      this.yesterdayUserData = data[0];

      // 个人用户前一天数据
      let sigleLpNum = this.eth.utils.formatEther(data[0].lp);
      let sigleNftNum = parseInt(data[0].nft);
      let sigleSoulNum = this.eth.utils.formatEther(data[0].soul);

      this.accumulatedAvailable = this.eth.utils.formatEther(
        data[0].accumulate
      );
      this.dividendsReceived = this.eth.utils.formatEther(data[0].cumulative);

      // 所有用户前一天数据
      let totalLpNum = this.eth.utils.formatEther(data[1].lp);
      let totalNftNum = parseInt(data[1].nft);
      let totalSoulNum = this.eth.utils.formatEther(data[1].soul);

      let bonusData = this.eth.utils.formatEther(data[2]);

      this.yestodayWeights =
        (sigleLpNum / totalLpNum || 0) * 0.4 +
        (sigleNftNum / totalNftNum || 0) * 0.3 +
        (sigleSoulNum / totalSoulNum || 0) * 0.3;

      let nftBonus = bonusData * 0.3;
      let soulBonus = bonusData * 0.3;
      let lpBonus = bonusData * 0.4;

      let soulPrice = parseInt(usdtTotal.div(soulTotal)._hex);
      let lpTotalsupply = await this.eth.c.lp.totalSupply();
      let lpSiglePrice = parseInt(usdtTotal.div(lpTotalsupply._hex)._hex);

      this.soulDestroysAPR =
        (soulBonus / (totalSoulNum * soulPrice)) * 365 * 100 || 0;
      this.nftEvaluationAPR =
        (nftBonus / (totalNftNum * 4) || 0) * 365 * 100 || 0;

      this.lpApr = (lpBonus / (totalLpNum * lpSiglePrice)) * 365 * 100 || 0;
      this.totalApr =
        ((soulBonus + nftBonus + lpBonus) /
          (totalSoulNum * soulPrice +
            totalNftNum * 4 +
            totalLpNum * lpSiglePrice)) *
          365 *
          100 || 0;
    },
    async cumulativeDestoryData() {
      let data = await this.eth.c.bonus.userInfos(this.eth.myAddr);
      this.cumulativeDestructionSoulAmount = this.eth.utils.formatEther(
        data.soul
      );
      this.cumulativeDestructionNFTAmount = data.nft;
    },
    async getOpenBlindBoxSoulData() {
      let { total, amount, receiveTime } =
        await this.eth.c.soulReceive.userReceive(this.eth.myAddr);
      let rate = await this.eth.c.soulReceive.getRate();
      this.openBlindBoxGetSoulData.rate = (rate.toNumber() / 9600) * 100;
      this.openBlindBoxGetSoulData.total = this.eth.utils.formatEther(total);
      this.openBlindBoxGetSoulData.received = Number(
        this.sliceDecimals(this.eth.utils.formatEther(total.sub(amount)), 4)
      );

      this.openBlindBoxGetSoulData.available =
        receiveTime.toNumber() === Number.parseInt(Date.now() / 1000 / 900)
          ? 0
          : Number(
              this.sliceDecimals(
                (this.eth.utils.formatEther(amount) *
                  this.openBlindBoxGetSoulData.rate) /
                  100,
                4
              )
            );
    },
    async receiveOpenBlindBoxSoul() {
      let { receiveTime } = await this.eth.c.soulReceive.userReceive(
        this.eth.myAddr
      );
      if (this.openBlindBoxGetSoulData.available <= 0) {
        return;
      }
      if (receiveTime.toNumber() === Number.parseInt(Date.now() / 1000 / 900)) {
        return;
      }
      this.receiveOpenBXBtnLoading = true;
      try {
        let res = await this.eth.c.soulReceive.soulReceive();
        await res.wait();
        await this.getOpenBlindBoxSoulData();
      } catch {
        this.receiveOpenBXBtnLoading = false;
      }
      this.receiveOpenBXBtnLoading = false;
    },
  },

  async created() {
    this.eth = await getEther();
    this.soulBox = Number(window.localStorage.getItem("soulBox"));

    window.localStorage.setItem("soulBox", 0);
    if (this.eth) {
      this.getData();
      await this.getMyNfts();
      await this.getSoulmeta();

      this.swiperSoul();
      this.swiperKaka();
      // this.swiperFish();
    }
  },
  mounted() {
  },
};
</script>

<style lang="scss" scoped>
@import url("https://static.soulmeta.io/web/3dnft-web/TemplateData/style.css");

.account {
  background: #000;
}
.img-bg {
  background: linear-gradient(to right bottom, #4f3990, #d83b55);
}
.swiper-wrapper {
  width: 300px !important;
}

.red-bg {
  background: linear-gradient(to bottom, #cc4c1b, #cb2f2b);
}

.input-bg {
  background-image: linear-gradient(to right, #a981f0, #fb8696);
}

@media screen and(min-width:440px) {
  .swiper-wrapper {
    width: 400px !important;
  }
}

@media screen and(min-width:768px) {
  .swiper-wrapper {
    width: 800px !important;
  }
}

@media screen and(min-width:1200px) {
  .swiper-wrapper {
    width: 1200px !important;
  }
}

custom-y-scrollbar {
  &::-webkit-scrollbar {
    width: 2px;
    height: 100px;
  }
  &::-webkit-scrollbar-track {
    background-color: transparent;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #191a37;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
}
</style>

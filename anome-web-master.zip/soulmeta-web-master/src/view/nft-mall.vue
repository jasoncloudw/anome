<template>
  <div class="nft-mall bg-black min-h-full">
    <div class="w-9/10 lg:w-200 xl:w-300 mx-auto pb-10">
      <div class="grid grid-cols-2 xl:grid-cols-3 gap-5 md:gap-10 mt-2 md:mt-8">
        <div class="p-2 md:p-4 border border-[#515151] rounded-md" v-for="item in mallList" :key="item.id">
          <div class="img-bg w-full rounded-md py-2 md:py-6">
            <img class="w-auto h-40 md:h-40 xl:h-48 mx-auto" :src="'https://static.soulmeta.io/web/img/nft-mall/batch-of-prop-' + item.key + '.webp'" alt="" />
          </div>
          <div class="flex mt-3">
            <div class="w-8 h-8 md:w-10 md:h-10 bg-[#222222] rounded-full flex items-center justify-center">
              <img class="w-1/2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            </div>
            <div class="ml-2 md:ml-4">
              <div class="text-[#A3A3A3] text-sm md:text-xl">SoulMeta</div>
              <div class="text-xs md:text-base text-white">{{ $t("nftmall.mall1") }}</div>
              <div class="text-xs md:text-base">{{ $t("nftmall.mall2") }}:{{ item.quantity }}</div>
            </div>
          </div>
          <div class="flex items-center justify-between mt-2.5">
            <div class="flex items-baseline">
              <span class="text-sm md:text-xl mr-1 font-bold">{{ item.price }}</span>
              <span class="text-xs md:text-base">SOUL</span>
              <!-- <img class="w-3 md:w-4 h-auto" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" /> -->
            </div>
            <div class="btn-bg w-16 md:w-24 leading-6 md:leading-8 text-center rounded-3xl text-sm md:text-xl cursor-pointer" @click="toBuy(item.id, item.key)">
              {{ $t("nftmall.mall5") }}
            </div>
          </div>
          <div class="text-xs md:text-base mt-2">{{ $t("nftmall.mall16") }}</div>
        </div>
      </div>
    </div>
    <div v-show="showMenuList" class="bg-[#000000e6] fixed top-32 md:top-[134px] left-0 z-99 w-full h-20 md:h-40">
      <div class="flex lg:w-200 xl:w-300 mx-auto text-sm md:text-xl py-5 md:py-10">
        <div class="px-10 md:px-40">SOULMETA NFT</div>
        <div>KAKA</div>
      </div>
    </div>
  </div>
</template>

<script>
import { getEther } from "@/plugins/ethers";
import { sliceDecimals } from "@/plugins/handleAmount";

export default {
  data() {
    return {
      search: "",
      showMenuList: false,
      mallList: [],
    };
  },
  async created() {
    this.eth = await getEther();
    this.requestMallList();
  },
  mounted() {
    window.addEventListener("scroll", () => {
      let scrollTop = document.documentElement.scrollTop;
      if (scrollTop) {
        this.showMenuList = false;
      }
    });
  },
  methods: {
    async requestMallList() {
      let propIdList = [2, 3, 1, 4, 5, 6];
      let soulBala = await this.eth.c.soul.balanceOf(this.eth.c.lp.address);
      let usdtBala = await this.eth.c.usdt.balanceOf(this.eth.c.lp.address);

      for (let i = 0; i < propIdList.length; i++) {
        let { times, prices } = await this.eth.c.propCore.propEffect(propIdList[i]);
        let quantity = await this.eth.c.prop1155.balanceOf(this.eth.c.propCore.address, propIdList[i]);
        let price = soulBala.mul(this.eth.utils.parseEther(prices.toString())).div(usdtBala);

        let prop = {
          id: propIdList[i],
          key: propIdList[i] === 1 ? 100 : times.toNumber(),
          quantity: times.toNumber() > 100 ? 10000 : quantity.toNumber(),
          // price: propIdList[i] === 1 ? 0 : sliceDecimals(this.eth.utils.formatEther(price)),
          price: 0.1,
        };
        this.mallList.push(prop);
      }
    },
    toBuy(id, key) {
      if (key > 100 || id === 1) {
        this.$store.commit("setSoon", true);
        return;
      }

      this.$router.push(`/mall-product-detail/${id}`);
    },
  },
};
</script>

<style lang="scss" scoped>
.el-input {
  --el-input-border-color: transparent;
  --el-input-focus-border-color: transparent;
  --el-input-hover-border-color: transparent;
  --el-input-bg-color: #bbbbbb1a;
  height: 62px;
  line-height: 62px;
}

:deep(.el-input__wrapper) {
  padding: 0 20px;
}

:deep(.el-input__inner) {
  color: #fff;
  font-size: 22px;
  padding-left: 6px;
}

.img-bg {
  background: linear-gradient(to bottom, #f0213b, #e8136c);
}

.btn-bg {
  background: linear-gradient(to bottom, #f0213b, #cb115f);
}

@media screen and(max-width:640px) {
  .el-input {
    height: 40px;
    line-height: 40px;
  }

  :deep(.el-input__wrapper) {
    padding: 0 12px;
  }

  :deep(.el-input__inner) {
    color: #fff;
    font-size: 14px;
    padding-left: 0;
  }
}
</style>
<template>
  <div class="game-plaza bg-black  min-h-full">
    <div class="w-full lg:w-200 xl:w-300 mx-auto pb-10">
      <div class="flex items-center">
        <img class="w-3 absolute left-[5%] block lg:hidden z-10" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.back()" />
        <Header class="block" />
      </div>
      <div class="w-11/12 lg:w-full mx-auto">
        <div class="flex border-b border-F2B py-3 md:py-5 md:mt-5">
          <img class="w-5 h-5 p-1 mr-1  md:w-8 md:h-8 md:p-2" src="https://static.soulmeta.io/web/img/home/guideblock.webp" alt="">
          <h5 class="text-lg leading-5 md:text-2xl  md:leading-8">{{ $t("guide.title2") }}</h5>
        </div>
        <div>
         <div class="mt-2  p-2" v-for="(item,index) in teaching" :key="index">
          <h5 class="text-sm leading-6 font-bold mb-2 break-words md:text-lg md:leading-10">{{item.concent}}</h5>
          <div>
            <span class="text-xs font-thin text-slate-200 md:text-base">{{item.time}}</span>
            <a class ="float-right text-sm text-F02 font-medium  md:text-lg" :href="item.url">{{ $t("guide.original")}}</a>
          </div>
        </div>
        </div>
        <div class="flex border-b border-F2B py-3 md:py-5 md:mt-5">
          <img class="w-5 h-5 p-1 mr-1  md:w-8 md:h-8 md:p-2" src="https://static.soulmeta.io/web/img/home/guideblock.webp" alt="">
          <h5 class="text-lg leading-5 md:text-2xl  md:leading-8">{{ $t("guide.title1") }}</h5>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss"></style>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
export default {
  components: { Header, Footer },

  data() {
    return {
      teaching:[
        {concent:this.$t("guide.content1"),url:this.$t("guide.url1"),time:'2022-05-20'},
        {concent:this.$t("guide.content2"),url:this.$t("guide.url2"),time:'2022-05-20'}
      ]
    };
  },
};
</script>

<template>  
    <div class="block w-full h-full relative bg-[#2b2c30]">
      <!-- <iframe class="w-full h-full" src="https://3dnft.soulmeta.io" frameborder="0"></iframe> -->
      <div id="unity-container" class="unity-desktop" style="width: 100%; height: 100%; overflow: hidden">
        <canvas id="unity-canvas" width="100%" height="100%"></canvas>
        <div id="unity-loading-bar">
          <div id="unity-logo"></div>
          <div id="unity-progress-bar-empty">
            <div id="unity-progress-bar-full"></div>
          </div>
        </div>
        <div id="unity-warning"></div>
        <div id="unity-footer">
          <div id="unity-webgl-logo"></div>
          <div id="unity-fullscreen-button"></div>
          <div id="unity-build-title"></div>
        </div>
      </div>
    </div>
</template>

<style scoped lang="scss"></style>

<script>

import { canvas_3dnft_html, close_3dnft_html } from "@/plugins/3dnft";
export default {

  data() {
    return {
    };
  },
  
  beforeRouteLeave(to, from, next) {
    if (!/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
      if (from.name == "customizationNFT") {
        close_3dnft_html()
          .Quit()
          .then(function () {
            next();
          });
      }
    } else {
      next();
    }
  },
  methods:{
    open3ndft() {
      if (!/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)) {
        canvas_3dnft_html();
      }
    },
  },
   mounted() {
    this.open3ndft();
  },
};
</script>

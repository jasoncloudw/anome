<template>
	<div class="game-plaza bg-black min-h-full">
		<div class="w-full lg:w-200 xl:w-300 mx-auto pb-10">
			<div class="flex items-center">
				<img
					class="w-3 absolute left-[5%] block lg:hidden z-10"
					src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
					alt=""
					@click="$router.back()"
				/>
				<Header class="block" />
			</div>
			<!-- <img class="w-full mt-5" src="https://static.soulmeta.io/web/img/game-plaza/game-plaza/world_cup.webp" alt="" /> -->
			<div class="w-full">
				<img
					src="https://static.soulmeta.io/web/img/game-plaza/top_bg.webp"
					alt=""
					style="z-index: 2"
				/>
				<div class="bg pb-20">
					<div
						class="hu rounded-1/2 w-full h-16 md:h-24 -translate-y-8 md:-translate-y-12"
					></div>
					<div class="w-5/6 -translate-y-24">
						<div
							class="Vice_title w-3/4 h-16 md:h-24 text-xl md:text-4xl lg:text-5xl"
						>
							<em class="h-full">{{ $t("gamePlaza.gamePlaza1") }}</em>
						</div>
						<section
							class="matching_team p-2 w-86 h-20 md:w-112 md:h-31 lg:w-135 lg:h-36"
						>
							<div
								class="border-Gray-300 w-[66px] md:w-24 lg:w-32 cursor-pointer float-left"
								@click="showBet(1)"
							>
								<img
									:src="
										'https://static.soulmeta.io/web/img/game-plaza/country_light' +
										mapMatchInfo.team1 +
										'.webp'
									"
									class="w-full h-full rounded-full"
								/>
							</div>
							<div
								class="border-Gray-300 w-[66px] md:w-24 lg:w-32 cursor-pointer float-right"
								@click="showBet(2)"
							>
								<img
									:src="
										'https://static.soulmeta.io/web/img/game-plaza/country_light' +
										mapMatchInfo.team2 +
										'.webp'
									"
									alt=""
								/>
							</div>
							<span
								class="absolute left-24 text-xl top-8 md:left-32 lg:left-44 md:top-12 lg:top-16 md:text-3xl lg:text-4xl"
								>{{
									mapMatchInfo.roller1 ? mapMatchInfo.team1_result : "0"
								}}</span
							>
							<span
								class="absolute right-24 text-xl top-8 md:right-32 lg:right-44 md:top-12 lg:top-16 md:text-3xl lg:text-4xl"
								>{{
									mapMatchInfo.roller1 ? mapMatchInfo.team2_result : "0"
								}}</span
							>
							<strong
								v-if="mapMatchInfo.roller1"
								class="absolute left-20 md:left-t30 lg:left-36 top-16 md:top-24 lg:top-28 text-sm md:text-base lg:text-xl"
								:class="
									mapMatchInfo.team1_result > mapMatchInfo.team2_result
										? 'text-FFDB'
										: 'text-C7C'
								"
								>{{
									mapMatchInfo.team1_result > mapMatchInfo.team2_result
										? "WIN"
										: "LOSE"
								}}</strong
							>
							<strong
								v-if="mapMatchInfo.roller1"
								class="absolute right-20 md:right-t30 lg:right-36 top-16 md:top-24 lg:top-28 text-sm md:text-base lg:text-xl"
								:class="
									mapMatchInfo.team2_result > mapMatchInfo.team1_result
										? 'text-FFDB'
										: 'text-C7C'
								"
								>{{
									mapMatchInfo.team2_result > mapMatchInfo.team1_result
										? "WIN"
										: "LOSE"
								}}</strong
							>
							<time
								class="text-sm md:text-base lg:text-xl xl:text-2xl relative left-20 md:left-t30 lg:left-32 -top-1 lg:top-1"
								>{{ countdown }}</time
							>
						</section>

						<div
							class="w-full lg:w-3/4 mx-auto relative mt-20 mb-0 rounded-xl bg-FFD p-3 md:p-6 font-bold"
						>
							<div class="w-full pb-3 border-b-2 border-slate-900">
								<p class="text-sm md:text-base mb-4 text-zinc-800">
									{{ $t("gamePlaza.gamePlaza2") }}
								</p>
								<span class="text-xl md:text-2xl text-zinc-800"
									>{{ BonusPoolInfo.round  }}
									<span class="text-sm md:text-base text-zinc-800"
										>SOUL</span
									></span
								>
								<span></span>
							</div>
							<div class="w-full mt-4 pb-3 border-b-2 border-slate-900">
								<p class="text-sm md:text-base mb-4 text-zinc-800">
									{{ $t("gamePlaza.gamePlaza3") }}
								</p>
								<span class="text-xl md:text-2xl text-zinc-800"
									>{{ BonusPoolInfo.championship  }}
									<span class="text-sm md:text-base text-zinc-800"
										>SSOUL</span
									></span
								>
							</div>
							<!-- 杠杆倍数 -->
							<div class="w-full mt-4">
								<p class="text-sm md:text-base mb-4 text-zinc-800">
									{{ $t("gamePlaza.gamePlaza13") }}
								</p>
								<span class="text-xl md:text-2xl text-zinc-800">{{
									leverage
								}}</span>
							</div>
						</div>
					</div>
					<!-- 投注弹出框 -->
					<div
						class="w-3/4 md:w-1/3 p-2 md:p-14 fixed top-1/4 border border-red-600 z-20 flex flex-col justify-between items-center bg-slate-900"
						v-if="is_showBet"
					>
						<div style="width: 100%" class="flex justify-end">
							<img
								:src="
									castteam == 1
										? 'https://static.soulmeta.io/web/img/game-plaza/country_light' +
										  mapMatchInfo.team1 +
										  '.webp'
										: 'https://static.soulmeta.io/web/img/game-plaza/country_light' +
										  mapMatchInfo.team2 +
										  '.webp'
								"
								class="w-1/6 relative right-1/4"
								alt=""
								title="city"
							/>
							<div
								class="w-1/6 flex justify-end cursor-pointer text-base md:text-xl"
								@click="showBet(3)"
							>
								X
							</div>
						</div>
						<p class="text-yellow-300 text-sm my-3">
							{{ $t("gamePlaza.gamePlaza10") }}
						</p>
						<el-input
							placeholder=""
							v-model="bet_number"
							style="width: 75%; height: 30px"
						>
							<template #append>SOUL</template>
						</el-input>
						<div
							class="receive w-24 h-8 text-base md:text-2xl md:w-36 md:h-12 flex items-center justify-center mt-6"
							@click="pay"
						>
							<span v-if="!isConfirm_load" class="font-blod text-black">{{
								$t("gamePlaza.gamePlaza11")
							}}</span>
							<el-icon v-else class="is-loading" style="color: red">
								<Loading />
							</el-icon>
						</div>
					</div>
					<!-- <el-button @click="begin_match" type="primary"
						>查询用户授权的SOUL币</el-button
					> -->
					<el-scrollbar height="600px">
						<div v-for="(item, index) in 128" :key="index">
							<img
								:src="
									'https://static.soulmeta.io/web/img/game-plaza/country_light' +
									item +
									'.webp'
								"
								class="w-16 h-16 md:w-28 md:h-28 m-2 rounded-full cursor-pointer"
								:class="
									failTeam_id.find((i) => {
										return i == item
									})
										? 'opacity-20'
										: ''
								"
								alt=""
							/>
						</div>
					</el-scrollbar>
					<div
						class="w-5/6 lg:w-3/5 mx-auto relative mt-20 mb-0 rounded-xl bg-FFD p-3 md:p-6 font-bold"
					>
						<div class="w-full pb-3 border-b-2 border-slate-900">
							<p class="text-sm md:text-base mb-4 text-zinc-800">
								{{ $t("gamePlaza.gamePlaza4") }}
							</p>
							<span class="text-xl md:text-2xl text-zinc-800"
								>{{
									formatChampionList.matchId % 127 > 96 ||
									formatChampionList.matchId % 127 == 0
										? BonusPoolInfo.pool_amount 
										: "0"
								}}
								<span class="text-sm md:text-base text-zinc-800"
									>SOUL</span
								></span
							>
							<span></span>
						</div>
						<div class="w-full mt-4 font-bold">
							<p class="text-sm md:text-base mb-4 text-zinc-800">
								{{ $t("gamePlaza.gamePlaza5") }}
							</p>
							<span class="text-xl md:text-2xl text-zinc-800"
								>{{BonusPoolInfo.pool_points}}
								<span class="text-sm md:text-base text-zinc-800"
									>SSOUL</span
								></span
							>
						</div>
					</div>
					<div
						class="w-5/6 lg:w-3/5 relative my-8 md:my-12 rounded-xl bg-FFD p-3 md:p-6 font-bold"
					>
						<div class="w-full pb-3 border-b-2 border-slate-900">
							<div class="flex justify-between mb-2">
								<span class="text-sm md:text-base text-zinc-800">{{
									$t("gamePlaza.gamePlaza6")
								}}</span>
								<span class="text-xl md:text-2xl text-zinc-800"
									>{{ soulBalance }}
									<span class="text-sm md:text-base text-zinc-800"
										>SOUL</span
									></span
								>
							</div>
							<div class="flex justify-between">
								<span class="text-sm md:text-base text-zinc-800">{{
									$t("gamePlaza.gamePlaza7")
								}}</span>
								<span class="text-xl md:text-2xl text-zinc-800 inline-block"
									>{{ ssoulBalance }}
									<span class="text-sm md:text-base text-zinc-800"
										>SSOUL</span
									></span
								>
							</div>
						</div>
						<div class="w-full mt-4">
							<!-- 累计收益 -->
							<div class="flex justify-between mb-2">
								<span class="text-sm md:text-base mb-2 md:mb-4 text-zinc-800">{{
									$t("gamePlaza.gamePlaza8")
								}}</span>
								<span class="text-xl md:text-2xl text-zinc-800"
									>{{ (instantEarningsed * 1).toFixed(2) }}
									<span class="text-sm md:text-base text-zinc-800"
										>SOUL</span
									></span
								>
							</div>
							<!-- 可领取收益 -->
							<div class="flex justify-between">
								<span class="text-sm md:text-base mb-2 md:mb-4 text-zinc-800">{{
									$t("gamePlaza.gamePlaza9")
								}}</span>
								<span class="text-xl md:text-2xl text-zinc-800"
									>{{ (instantEarnings * 1).toFixed(2) }}
									<span class="text-sm md:text-base text-zinc-800"
										>SOUL</span
									></span
								>
							</div>
						</div>
					</div>
					<div
						class="receive text-xl md:text-2xl lg:text-3xl w-28 md:w-36 lg:w-44 h-10 md:h-12 lg:h-16 flex items-center justify-center"
						@click="getInstantEarnings"
					>
						<span class="text-black">{{ $t("gamePlaza.receive") }}</span>
					</div>
					<div class="result h-[660px] md:h-[1260px] lg:h-[1310px] xl:h-[1920px]">
						<!-- 上方 -->
						<div class="px-11 w-full h-1/3 flex justify-between p-10 flex-wrap">
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="top_16team.length >= 1 ? {backgroundSize: '100% 100%',backgroundImage: 'url(' + top_16team[0] + ')',}: ''"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 1 ? "" : "?" }}
								</div>
								<div
									:style="
										top_16team.length >= 2
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[1] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900  w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 2 ? "" : "?" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 3
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[2] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 3 ? "" : "?" }}
								</div>
								<div
									:style="
										top_16team.length >= 4
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[3] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 4 ? "" : "?" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 5
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[4] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 5 ? "" : "?" }}
								</div>
								<div
									:style="
										top_16team.length >= 6
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[5] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 6 ? "" : "?" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 7
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[6] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 7 ? "" : "?" }}
								</div>
								<div
									:style="
										top_16team.length >= 8
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[7] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 8 ? "" : "?" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/2 h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 17
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[16] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 17 ? "" : "?" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 18
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[17] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 18 ? "" : "?" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line2.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/2 h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 19
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[18] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 19 ? "" : "?" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 20
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[19] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 20 ? "" : "?" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line2.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
									/>
								</div>
							</div>
							<div class="w-full h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 25
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[24] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 25 ? "" : "?" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 26
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[25] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 26 ? "" : "?" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line1.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-full h-1/4 flex justify-around">
								<div
									:style="
										top_16team.length >= 29
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[28] + ')',
											  }
											: ''
									"
									class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
								>
									{{ top_16team.length >= 29 ? "" : "?" }}
								</div>
							</div>
						</div>

						<!-- 下方 -->
						<div
							class="px-11 w-full h-1/3 flex justify-between rotate-180 p-10 flex-wrap"
						>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 9
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[8] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 9 ? "" : "¿" }}
								</div>
								<div
									:style="
										top_16team.length >= 10
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[9] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 10 ? "" : "¿" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 11
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[10] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 11 ? "" : "¿" }}
								</div>
								<div
									:style="
										top_16team.length >= 12
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[11] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 12 ? "" : "¿" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 13
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[12] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 13 ? "" : "¿" }}
								</div>
								<div
									:style="
										top_16team.length >= 14
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[13] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 14 ? "" : "¿" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/4 h-1/4 flex justify-around flex-wrap">
								<div
									:style="
										top_16team.length >= 15
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[14] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 15 ? "" : "¿" }}
								</div>
								<div
									:style="
										top_16team.length >= 16
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[15] + ')',
											  }
											: ''
									"
									class="rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl result_img"
								>
									{{ top_16team.length >= 16 ? "" : "¿" }}
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line3.webp" class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/2 h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 21
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[20] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 21 ? "" : "¿" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 22
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[21] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 22 ? "" : "¿" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line2.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-1/2 h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 23
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[22] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 23 ? "" : "¿" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 24
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[23] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 24 ? "" : "¿" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line2.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-full h-1/4 flex justify-around flex-wrap">
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 27
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[26] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 27 ? "" : "¿" }}
									</div>
								</div>
								<div class="w-1/2 flex justify-center items-center">
									<div
										:style="
											top_16team.length >= 28
												? {
														backgroundSize: '100% 100%',
														backgroundImage: 'url(' + top_16team[27] + ')',
												  }
												: ''
										"
										class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
									>
										{{ top_16team.length >= 28 ? "" : "¿" }}
									</div>
								</div>
								<div class="rotate-180 w-1/2">
									<img
										src="https://static.soulmeta.io/web/img/game-plaza/Promotion_line1.webp"
										class="w-full h-[11px] md:h-[23px] xl:h-[50px]"
										alt=""
									/>
								</div>
							</div>
							<div class="w-full h-1/4 flex justify-around">
								<div
									:style="
										top_16team.length >= 30
											? {
													backgroundSize: '100% 100%',
													backgroundImage: 'url(' + top_16team[29] + ')',
											  }
											: ''
									"
									class="result_img rounded-full border border-sky-900 w-[30px] h-[30px] md:w-[60px] md:h-[60px] lg:w-[70px] lg:h-[70px] xl:w-[89px] xl:h-[89px] bg-white text-122 flex justify-center items-center text-sm md:text-3xl lg:text-5xl"
								>
									{{ top_16team.length >= 30 ? "" : "¿" }}
								</div>
							</div>
						</div>
					</div>
					<div class="mt-10 px-6 text-xs md:px-10 md:text-sm xl:px-20">
						<p :style="introduceStyle(item)" v-for="item in 15" :key="item">
							{{ $t("gamePlaza.introduce" + item) }}
						</p>
					</div>
				</div>
			</div>
		</div>
		<Footer />
	</div>
</template>

<script>
import Footer from "@/components/footer.vue"
import Header from "@/components/header.vue"
import { getEther } from "@/plugins/ethers"
import { computed, getCurrentInstance, reactive, ref } from "vue"
import { ElMessage, ElMessageBox } from "element-plus"
export default {
	components: { Header, Footer },
	setup() {
		let is_showBet = ref(false)
		let isConfirm_load = ref(false)
		let countryImg = reactive([])
		if (localStorage.getItem("countryImg")) {
			countryImg = JSON.parse(localStorage.getItem("countryImg"))
		} else {
			countryImg = computed(() => {
				let arr = []
				for (let i = 0; i < 128; i++) {
					const url = new URL(
						`https://static.soulmeta.io/web/img/game-plaza/country_light${
							i + 1
						}.webp`,
						import.meta.url
					).href
					arr.push({ src: url })
				}
				return arr
			})
			localStorage.setItem("countryImg", JSON.stringify(countryImg.value))
		}
		return {
			is_showBet,
			isConfirm_load,
			countryImg,
		}
	},
	data() {
		return {
			formatNum: Math.pow(10, 18),
			bet_number: "",
			soulBalance: "",
			ssoulBalance: "",
			leverage: "", //杠杆
			getChampionList: {},
			formatChampionList: {},
			mapMatchInfo: {},
			teamwin: "",
			castteam: "",
			getParticipates: "",
			authorizationsoulBalance: "",
			instantEarningsed: 0.0,
			instantEarnings: 0.0,
			BonusPoolInfo: {
				round: 0.0,
				championship: 0.0,
				pool_amount: 0.0,
				pool_points: 0.0,
			},
			BurnTotal: {},
			top_16team: [], // 16强队伍
			init: true,
			failTeam_id: [],
			countdown: "", //当前比赛结束倒计时
			is_countdown: true,
		}
	},
	methods: {
		// 游戏介绍样式判断
		introduceStyle(item) {
			let style = { textIndent: "2em" }
			if (item == 5 || item == 6 || item == 8 || item == 12 ) {
				style = { fontWeight: 600, fontSize: "14px", marginTop: "16px" }
			}
			if (item == 5) {
				style.color = "red"
			}
			return style
		},
		//获取账户的SOUL/SSOUL余额
		async getUserBalance() {
			let soul = await this.eth.c.soulToken.balanceOf(this.eth.myAddr)
			this.soulBalance = Math.floor(this.formatEther(soul) * 100) / 100
		},
		// async begin_match() {
		// 	let soulToken = await this.eth.c.soulToken.allowance(
		// 		this.eth.myAddr,
		// 		this.worldCup.address
		// 	)
		// 	console.log(this.formatEther(soulToken))
		// 	this.getChampionInfos()
		// },
		showBet(country) {
			if (this.is_showBet && country != 3) return
			if (!this.is_showBet && this.mapMatchInfo.roller1) {
				ElMessage({
					message: this.$t("gamePlaza.Tips1"),
					type: "warning",
				})
				return
			}
			if (!this.getParticipates) {
				ElMessage({
					message: this.$t("gamePlaza.Tips2"),
					type: "warning",
				})
				return
			}
			// 判断是否已超过可投注时间
			const localmesc = new Date().getTime()
			if ((this.mapMatchInfo.endTim - localmesc < 30000) && !this.is_showBet) {
				ElMessage({
					message: this.$t("gamePlaza.Tips6"),
					type: "warning",
				})
				return
			}
			this.castteam = country
			this.bet_number = ""
			const body = document.documentElement.style
			if (this.is_showBet) {
				body.overflow = ""
			} else {
				body.overflow = "hidden"
			}
			this.is_showBet = !this.is_showBet
			this.isConfirm_load = false
		},

		// 点击投注确认
		async pay() {
			// 判断是否输入正确值
			if (!this.bet_number || !Number(this.bet_number)) {
				ElMessage({
					message: this.$t("gamePlaza.Tips3"),
					type: "warning",
				})
				return
			}
			// 判断是否已超过可投注时间
			const localmesc = new Date().getTime()
			if ((this.mapMatchInfo.endTim - localmesc < 30000) && this.is_showBet) {
				ElMessage({
					message: this.$t("gamePlaza.Tips6"),
					type: "warning",
				})
				return
			}
			// 加载图标
			this.isConfirm_load = true

			// 查询用户授权的SOUL币
			let soulToken = await this.eth.c.soulToken.allowance(
				this.eth.myAddr,
				this.worldCup.address
			)
			// 获取授权余额并格式化
			this.authorizationsoulBalance = this.formatEther(soulToken)
			// 判断当前剩余授权余authorization额是否小于投注金额
			if (Number(this.authorizationsoulBalance) < this.bet_number) {
				// 进入这里说明授权SOUL币不足以投注，需要重新授权
				// 拉起授权
				ElMessageBox.confirm(this.$t("gamePlaza.gamePlaza14"), "Warning", {
				confirmButtonText: this.$t("gamePlaza.gamePlaza11"),
				cancelButtonText: this.$t("gamePlaza.gamePlaza12"),
				type: "warning",
				}).then(async () => {
					const approve = await this.eth.c.soulToken.approve(this.eth.c.worldCup.address,this.eth.constants.MaxUint256)
					await approve.wait()
					this.$message.success(this.$t('gamePlaza.authorize1'))
					this.betting()
				}).catch(() => {
					this.$message.success(this.$t('gamePlaza.authorize0'))
					this.isConfirm_load = false
				})
				return
			}
			this.betting()
		},
		// 投注
		betting() {
			// 判断是否已超过可投注时间
			const localmesc = new Date().getTime()
			if ((this.mapMatchInfo.endTim - localmesc < 30000) && this.is_showBet) {
				ElMessage({
					message: this.$t("gamePlaza.Tips6"),
					type: "warning",
				})
				this.isConfirm_load = false
				return
			}
			let amount = this.eth.utils.parseEther(this.bet_number, "ether")
			let team = this.castteam
			this.worldCup
				.betting(amount, team)
				.then(async (tx) => {
					await tx.wait()
					this.isConfirm_load = false
					ElMessage({
						message: this.$t("gamePlaza.Tips4"),
						type: "success",
					})
					this.is_showBet = false
					document.documentElement.style.overflow = ''

				})
				.catch((err) => {
					this.isConfirm_load = false
					ElMessage({
						message: this.$t("gamePlaza.Tips5"),
						type: "error",
					})
				})
		},
		// 领取即使奖池奖励
		async getInstantEarnings() {
			if (Number(this.instantEarnings) <= 0) {
				ElMessage({
					message: this.$t("gamePlaza.Tips7"),
					type: "error",
				})
				return
			}
			try {
				const tx = await this.worldCup.getInstantEarnings()
				await tx.wait()
				ElMessage({
					message: this.$t("gamePlaza.Tips8"),
					type: "success",
				})
			} catch (error) {
				ElMessage({
					message: this.$t("gamePlaza.Tips9"),
					type: "error",
				})
			}
				
		},
		async getData() {
			this.getUserBalance()
			this.getChampionInfos()
		},

		//获取世界杯数据
		async getChampionInfos() {  
			this.getChampionList = await this.worldcupViewer.getChampionInfo()
			this.formatChampionList.matchId = parseInt(
				this.formatEther(this.getChampionList.matchId) * this.formatNum
			) //格式化当前比赛id
			console.log("当前比赛id:" + this.formatChampionList.matchId)
			this.mapMatchs()
			this.getBonusPool()
			this.mapPlayerInfo()
			this.getParticipate()
			// this.getBurnTotal()
			if (this.init &&  this.formatChampionList.matchId !== 0) {
				this.init = false 
				for (
					let i = this.formatChampionList.matchId % 127 || this.formatChampionList.matchId - 1;
					i >= 0 ;
					i--
				) {
					let obj = {}
					this.worldCup.mapMatch(this.formatChampionList.matchId - i)
						.then(async (mapMatchInfo) => {
							obj.team1 = parseInt(
								this.formatEther(mapMatchInfo.team1) * this.formatNum
							)
							obj.team2 = parseInt(
								this.formatEther(mapMatchInfo.team2) * this.formatNum
							)
							const res = await this.eth.c.random.getRandom(mapMatchInfo.roller)
							obj.roller1 = this.formatEther(res[0])
							obj.roller2 = this.formatEther(res[1])
							if (Number(obj.roller1) > Number(obj.roller2)) {
								this.failTeam_id.push(obj.team2)
							} else {
								this.failTeam_id.push(obj.team1)
							}
						})
						.catch((err) => {})
				}
				if (
					this.formatChampionList.matchId % 127 > 97 ||
					this.formatChampionList.matchId % 127 == 0
				) {
				const exg = /\d+$/
				let site = 0
				exg.test(this.formatChampionList.matchId/127) ?  site = this.formatChampionList.matchId -30 : parseInt((this.formatChampionList.matchId / 127))*127 +	97 //当天16强开始场次
					for (
						let i = 1;
						i <= this.formatChampionList.matchId - site
							? 16
							: (this.formatChampionList.matchId % 127) - 96;
						i++
					) {
						try {
							let mapMatchInfo = await this.worldCup.mapMatch(site + i)
							let team1 = this.formatEther(mapMatchInfo.team1) * this.formatNum
							let team2 = this.formatEther(mapMatchInfo.team2) * this.formatNum
							const res = await this.eth.c.random.getRandom(mapMatchInfo.roller)
							const obj = {}
							obj.roller1 = this.formatEther(res[0])
							obj.roller2 = this.formatEther(res[1])
							if (Number(obj.roller1) > Number(obj.roller2)) {
								this.top_16team.push(
									`https://static.soulmeta.io/web/img/game-plaza/country_light${team1}.webp`
								)
							} else {
								this.top_16team.push(
									`https://static.soulmeta.io/web/img/game-plaza/country_light${team2}.webp`
								)
							}
						} catch (error) {}
					}
				}
			}
		},
		//获取当前比赛数据
		async mapMatchs() {
			let mapMatchInfo = await this.worldCup.mapMatch(
				this.formatChampionList.matchId //当前比赛索引
			)
			this.mapMatchInfo.startTim = new Date(
				this.formatEther(mapMatchInfo.startTim) * this.formatNum * 1000
			).getTime()
			this.mapMatchInfo.endTim = new Date(
				this.formatEther(mapMatchInfo.endTim) * this.formatNum * 1000
			).getTime()
			this.mapMatchInfo.team1 = parseInt(
				this.formatEther(mapMatchInfo.team1) * this.formatNum
			)
			this.mapMatchInfo.team2 = parseInt(
				this.formatEther(mapMatchInfo.team2) * this.formatNum
			)
			if(new Date().getTime() > this.mapMatchInfo.endTim && this.formatChampionList.matchId !== 0){
          			if(this.mapMatchInfo.roller1) return  
					try {
						const res = await this.eth.c.random.getRandom(mapMatchInfo.roller)
						this.mapMatchInfo.roller1 = this.formatEther(res[0])
						this.mapMatchInfo.roller2 = this.formatEther(res[1])
						const roller1 = Array.from(this.mapMatchInfo.roller1)
						const roller2 = Array.from(this.mapMatchInfo.roller2)
						let Bigarr = []
						let Smallarr = []
						if (Number(this.mapMatchInfo.roller1) > Number(this.mapMatchInfo.roller2)) {
							Bigarr = roller1
							Smallarr = roller2
						} else {
							Bigarr = roller2
							Smallarr = roller1
						}
						for (let i = 0; i < Smallarr.length; i++) {
							if (Number(Bigarr[i]) > Number(Smallarr[i])) {
								this.mapMatchInfo.team1_result = roller1[i]
								this.mapMatchInfo.team2_result = roller2[i]
								break
							}
							if (i == Smallarr.length - 1) {
								if (Bigarr == roller1) {
									this.mapMatchInfo.team1_result = 3
									this.mapMatchInfo.team2_result = 1
								} else {
									this.mapMatchInfo.team1_result = 1
									this.mapMatchInfo.team2_result = 3
								}
							}
						}
					} catch (error) {}
			}else{
				this.mapMatchInfo.roller1 = ""
				this.mapMatchInfo.roller2 = ""
			}
			if (new Date().getTime() < this.mapMatchInfo.endTim && !this.mapMatchInfo.roller1) {
				if (this.countdown_timer) return
				let interval = this.mapMatchInfo.endTim - new Date().getTime()
				// 求 相差的天数/小时数/分钟数/秒数
				let minute, second

				// 两个日期对象，相差的秒数
				interval = parseInt(interval / 1000)
				this.countdown_timer = setInterval(() => {
					if (interval == 0) {
						clearInterval(this.countdown_timer)
					}
					minute = parseInt((interval / 60) % 60)
					second = interval % 60
					minute >= 10 ? (minute = minute + ":") : (minute = "0" + minute + ":")
					second >= 10
						? (this.countdown = minute + second)
						: (this.countdown = minute + "0" + second)
					interval--
				}, 1000)
			} else {
				clearInterval(this.countdown_timer)
				this.countdown_timer = ""
				this.countdown = "00:00"
			}
		},
		//获取奖金池数据
		async getBonusPool() {
			const res = await this.worldCup.mapInstantTotal(
				this.getChampionList.matchId
			)
			const res1 = await this.worldCup.mapChampionTotal(
				this.getChampionList.championIndex
			)
			this.BonusPoolInfo.round = Math.floor(this.formatEther(res.total) * 100) / 100
			this.BonusPoolInfo.championship = Math.floor(this.formatEther(res.ssoulAmount) * 100) / 100
			this.BonusPoolInfo.pool_amount = Math.floor(this.formatEther(res1.soulAmount) * 100) /100
			this.BonusPoolInfo.pool_points = Math.floor(this.formatEther(res1.ssoulAmount) * 100) / 100
		},
		// 获取玩家数据
		async mapPlayerInfo() {
				this.worldcupViewer.getEarningsData(this.eth.myAddr).then((getEarningsDatas)=>{
					this.ssoulBalance = Math.floor(this.formatEther(getEarningsDatas.ssoulAmount) * 100) / 100//账户SSOUL
					this.instantEarnings = Math.floor(this.formatEther(getEarningsDatas.instantEarnings) * 100) / 100
					this.instantEarningsed = this.formatEther(getEarningsDatas.instantEarningsed) * 1 + this.formatEther(getEarningsDatas.instantEarnings) * 1
					this.instantEarningsed = Math.floor(this.instantEarningsed * 100) / 100
					this.leverage = getEarningsDatas.leverage == 0 ? 1 : getEarningsDatas.leverage
					// console.log('getEarningsDatas',this.ssoulBalance);
				}).catch(async ()=>{
					let mapPlayerInfos = await this.worldCup.mapPlayerInfo(this.eth.myAddr)
					this.ssoulBalance = Math.floor(this.formatEther(mapPlayerInfos.ssoulAmount) * 100) / 100//账户SSOUL
					this.instantEarnings = Math.floor(this.formatEther(mapPlayerInfos.instantEarnings) * 100 + this.formatEther(mapPlayerInfos.championEarnings) * 100) / 100
					this.instantEarningsed =this.formatEther(mapPlayerInfos.instantEarningsed) * 1 + this.formatEther(mapPlayerInfos.instantEarnings) * 1
					this.instantEarningsed = Math.floor(this.instantEarningsed * 100) / 100
					// console.log('mapPlayerInfos',this.ssoulBalance);
					this.leverage = mapPlayerInfos.leverage == 0 ? 1 : mapPlayerInfos.leverage 
				})
				
				
		},
		// 获取用户是否参加本场比赛
		async getParticipate() {
			this.getParticipates = await this.worldCup.getParticipate(this.eth.myAddr)
		},
		// 获取当天总销毁数量
		// async getBurnTotal() {
		// 	let getBurnTotals = await this.worldCup.getBurnTotal()
		// 	this.BurnTotal.soul = this.formatEther(getBurnTotals.soulAmount)
		// 	this.BurnTotal.ssoul = this.formatEther(getBurnTotals.ssoulAmount)
		// },
	},
	async created() {
		this.eth = await getEther()
		const { worldCup, soulToken,worldcupViewer } = this.eth.c
		const { formatEther } = this.eth.utils
		this.formatEther = formatEther
		this.worldCup = worldCup
		this.worldcupViewer = worldcupViewer
		this.soulToken = soulToken
		if (this.eth) {
			this.getData()
		}
	},
	async mounted() {
		this.timer = setInterval(() => {
			this.getData()
      if(this.formatChampionList.matchId%127 == 0){
        clearInterval(this.timer)
      }
		}, 5000)
	},
	unmounted() {
		clearInterval(this.timer)
	},
}
</script>

<style lang="scss">
.el-input-group__append {
	width: 20%;
}
.el-message-box__title span {
	color: rgb(244, 149, 16);
}
.el-message-box__message p {
	color: #000000 !important;
}
.el-message-box__btns button:nth-of-type(1) span {
	color: black;
}
.el-scrollbar {
	height: 600px;
}
@media (min-width: 629px) {
	.el-scrollbar__view {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		width: 700px;
	}
}
@media (max-width: 628px) {
	.el-scrollbar__view {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		width: 100%;
	}
}
.scrollbar__view:after {
	content: "";
	width: 128px;
	height: 0;
	display: block;
}
.bg {
	border-radius: 20px;
	width: 100%;
	background: linear-gradient(180deg, #001135 0%, #1e3567 54%, #001033 100%);
	opacity: 1;
	display: flex;
	flex-direction: column;
	align-items: center;
}
.hu {
	border-radius: 50%;
	background: #001236;
	// width: 100%;
	// height: 100px;
	// transform: translateY(-53px);
}
.Vice_title {
	margin: 0 auto;
	font-family: Futura Md BT-Bold Italic, Futura Md BT;
	font-weight: normal;
	color: #ffffff;
	transform: translateY(12px);
	text-align: center;
	background-image: url("https://static.soulmeta.io/web/img/game-plaza/title_bg.webp");
	background-size: 100% 100%;
}
.matching_team {
	margin: 20px auto 0;
	position: relative;
	// display: flex;
	// justify-content: space-around;
	// align-items: center;
	// padding: 8px;
	// width: 595px;
	// height: 144px;
	background-image: url("https://static.soulmeta.io/web/img/game-plaza/match_bg.webp");
	background-size: 100% 100%;
}
.receive {
	background-image: url("https://static.soulmeta.io/web/img/game-plaza/receive.webp");
	background-size: 100% 100%;
	text-align: center;
	font-family: D-DIN-DIN-Bold, D-DIN-DIN;
	font-weight: bold;
	color: #000000 !important;
	cursor: pointer;
}
.result {
	background-image: url("https://static.soulmeta.io/web/img/game-plaza/court.webp");
	background-size: 100% 100%;
	display: flex;
	flex-direction: column;
	justify-content: space-evenly;
}
</style>
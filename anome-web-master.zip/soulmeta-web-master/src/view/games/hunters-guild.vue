<template>
  <div class="bg-black min-h-full">
    <Header />
    <div>
      <el-carousel indicator-position="none" arrow="never">
        <div class="w-full h-28 md:h-60 xl:h-100 2xl:h-120">
          <el-carousel-item v-for="item in bannerList" :key="item.image">
            <img ref="banner" class="w-full h-auto" :src="'https://static.soulmeta.io/web/img/games/hunters-guild/banner' + item.image + '.webp'" alt="" />
          </el-carousel-item>
        </div>
      </el-carousel>
      <img class="mt-2 md:mt-10" src="https://static.soulmeta.io/web/img/games/hunters-guild/banner_top.webp" alt="" />
      <div class="hunting-today-bg">
        <div class="lg:w-200 xl:w-300 w-9/10 mx-auto">
          <img
            class="h-10 md:h-24 w-auto mt-4 md:mt-10 mb-2.5 md:mb-5"
            src="https://static.soulmeta.io/web/img/games/hunters-guild/hunting_today.webp"
            alt=""
          />
          <img src="https://static.soulmeta.io/web/img/games/hunters-guild/card.webp" alt="" />
          <img class="h-6 md:h-14 w-auto mx-auto -mt-3 md:-mt-7" src="https://static.soulmeta.io/web/img/games/hunters-guild/card_title.webp" alt="" />
          <div class="intro-bg px-8 md:px-32 pt-2.5 md:pt-5 pb-5 md:pb-10 mt-4 md:mt-10 relative">
            <div class="text-xs md:text-base">
              Man's dearest possession is life. It is given to him but once, and he must live it so as to feel no torturing regrets for wasted years, never know
              the burning shame of a mean and petty past; so live that, dying, he might say: all my life, all my strength were given to the finest cause in all
              the world—the fight for the Liberation of Mankind.
            </div>
            <img
              class="absolute left-1/2 -translate-x-1/2 -bottom-3 md:-bottom-6 h-6 md:h-12 w-auto"
              src="https://static.soulmeta.io/web/img/games/hunters-guild/enter_btn.webp"
              alt=""
            />
          </div>
        </div>
      </div>
      <div class="lg:w-200 xl:w-300 w-9/10 mx-auto">
        <img
          class="h-10 md:h-24 w-auto mt-7 md:mt-14 mb-2.5 md:mb-10"
          src="https://static.soulmeta.io/web/img/games/hunters-guild/hunting-ground.webp"
          alt=""
        />
        <ul class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5 md:gap-10 h-144 md:h-240 overflow-x-auto c-scrollbar pr-2 md:pr-4">
          <li v-for="monster in 100" :key="monster">
            <img :src="'https://static.soulmeta.io/web/img/games/monster/' + monster + '.webp'" alt="" />
            <div class="flex items-center justify-between mt-1 md:mt-3">
              <div>
                <span class="text-base md:text-xl">Bounty：</span>
                <span class="text-base md:text-xl text-[#FFB800]">--</span>
                <span class="text-xs ml-1">SOUL</span>
              </div>
              <img class="w-3 md:w-5 h-auto" src="https://static.soulmeta.io/web/img/games/hunters-guild/money.webp" alt="" />
            </div>
          </li>
        </ul>
        <!-- <div class="hunting-ground-intro text-xs md:text-base xl:text-xl mt-5 md:mt-10">
          <p>Enter the room</p>
          <p>
            In the game lobby, you can choose the room you want to enter. If there are no other players in the room, you will become the owner by default and
            have the right to set the challenge amount.
          </p>
          <p>If there is already a player in the room, click Join to join the room to challenge the owner.</p>
          <p>Policy settings</p>
          <p>
            After entering the room, you can set the order of "Rock Paper Scis sors". After entering the game, you will have a turn-based battle in the order of
            "Rock Paper Scissors"set by the player.
          </p>
          <p>
            After setting the order of "Rock Paper Scissors", click OK and the MetaMask wallet will pop up to pay the challenge gold. The challenge gold from
            both parties will be putinto the prize pool in this room.
          </p>
          <p>If you do not pay the challenge fee within 2 minutes of entering the room, you will be kicked out of the room.</p>
          <p>Game battle</p>
          <p>
            The game conducts turn-based battles in the order of "rock paper scissors" set by the player, and the winner of each round can attack the opponent
            once. If one of them
          </p>
          <p>has 0 HP, the game ends.</p>
          <p>The winner can get all the prize pool in this room.</p>
          <p>Players can view the game information in the personal center or room history.</p>
        </div> -->
      </div>
    </div>
    <Footer />
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import Footer from "@/components/footer.vue";
export default {
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      bannerList: [
        {
          image: 1,
        },
        {
          image: 2,
        },
      ],
      monsterList: [],
    };
  },
};
</script>

<style lang="scss" scoped>
.intro-bg {
  background: linear-gradient(to right, rgb(255 184 3 / 0%), rgb(255 184 3 / 70%), rgb(255 184 3 / 0%));
}

.hunting-today-bg {
  background: url("https://static.soulmeta.io/web/img/games/hunters-guild/hunting-today-bg.webp") no-repeat;
  background-size: cover;
}

.hunting-ground-intro {
  p {
    display: flex;
    align-items: baseline;
  }
  p::before {
    content: "";
    display: block;
    width: 7px;
    min-width: 7px;
    height: 7px;
    min-height: 7px;
    background: linear-gradient(180deg, #7d4400 0%, #bd976e 100%);
    border-radius: 50%;
    margin-right: 7px;
    clear: both;
  }
}

.c-scrollbar {
  &::-webkit-scrollbar {
    width: 8px;
    height: 4px;
  }
  &::-webkit-scrollbar-track {
    background-color: #484848;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #fff;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
}

:deep(.el-carousel__container) {
  height: 100%;
}

@media (max-width: 768px) {
  .c-scrollbar {
    &::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
  }
}
</style>

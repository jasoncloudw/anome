<template>
  <div class="bg-black min-h-full">
    <Header />
    <div>
      <div class="w-full relative">
        <img src="https://static.soulmeta.io/web/img/2dnft-fight/banner.webp" alt="" />
        <div v-if="!receiveCheck&&invitor!=undefined&&!isOwn" class="w-1/2 absolute sm:bottom-[19%] bottom-[9%] left-[13%]">
          <img @click="tokenReceive" class="sm:w-2/5 w-3/5 cursor-pointer" src="https://static.soulmeta.io/web/img/2dnft-fight/binding.webp" alt="">
          <span class="xl:text-lg xl:leading-10 sm:text-sm text-xs block xl:w-2/5 w-full xl:text-center text-left">{{ $t("nft2d.msg5") }}</span>
        </div>
      </div>
      <div class="lg:w-200 xl:w-300 w-9/10 mx-auto pb-5">
        <div class="flex items-center justify-around lg:py-20 sm:py-10 py-8">
          <div>
            <img class="w-108 h-auto" src="https://static.soulmeta.io/web/img/2dnft-fight/mint.webp" alt="" />
            <div @click="to2dNft" class="w-1/2 mx-auto text-center bg-E4FF02 text-1126AF lg:text-2xl sm:text-lg text-sm uppercase py-2.5 rounded cursor-pointer">{{ $t("nft2d.msg1") }}</div>
          </div>
          <div>
            <img class="w-108 h-auto" src="https://static.soulmeta.io/web/img/2dnft-fight/fight.webp" alt="" />
            <div @click="toNftFight" class="w-1/2 mx-auto text-center bg-E4FF02 text-1126AF lg:text-2xl sm:text-lg text-sm uppercase py-2.5 rounded cursor-pointer">{{ $t("nft2d.msg2") }}</div>
          </div>
        </div>
        <div class="invitor-bg rounded-2xl py-5 md:py-10 mt-10" v-if="balanceOf!=0">
          <div class="mb-2 text-center md:text-xl">
            {{ $t("nft2d.msg3") }}
          </div>
          <div class="">
            <img class="w-4 mx-auto mb-1" src="https://static.soulmeta.io/web/img/soulH/b_icon.webp" alt="" />
            <div class="flex justify-center items-center break-all px-5 md:px-10">
              <div class="text-xs md:text-xl text-yellow-200">
                {{ invitorLink }}
              </div>
              <img class="w-5 ml-2 cursor-pointer" @click="doCopy(invitorLink)" src="https://static.soulmeta.io/web/img/soulH/copy_icon.webp" alt="" />
            </div>
          </div>
          <div class="mt-3 text-xs md:text-xl text-center">
            {{ $t("nft2d.msg4") }}
          </div>
        </div>
      </div>
      
        <div class="lg:w-200 xl:w-300 w-9/10 mx-auto p-2">
          <div class="lg:p-6 sm:p-3 p-2 lg:pb-0 sm:pb-6 pb-4">
            <span  v-for="item in selectList" @click="selectIndex=item.index" :class="selectIndex==item.index?'bg-E4FF02 border-[#E4FF02] text-[#1126AF]':'border-white'" :key="item.index" 
            class="sm:mr-6 sm:px-6 mr-4 px-4 inline-block sm:leading-10 leading-6 font-medium sm:border-2 border cursor-pointer rounded-full sm:text-lg text-sm">{{item.name}}</span>
          </div>
          <div class="w-full overflow-hidden">
              <div class="sm:w-1/3 w-1/2 float-left lg:p-6 sm:p-3 p-2 rounded-lg relative" v-for="(item,index) in 6" :key="index">
                <div class=" rounded-xl border border-[#737373] sm:p-4 sm:pb-0 p-2 pb-0 w-full relative">                  
                  <strong class="bg-E4FF02 inline-block sm:top-4 top-2 absolute sm:left-4 left-2 leading-6 px-4 text-sm text-[#1126AF]  rounded-tl-xl rounded-br-xl">Available</strong>
                  <div class="bg-[#364258] rounded-xl">
                    <img src="https://static.soulmeta.io/web/img/2dnft-fight/nftClub.webp" alt="" srcset="">
                  </div>
                  <div class="overflow-hidden">
                    <span class="text-white lg:leading-lh-5 sm:leading-lh-3 leading-10 lg:text-xl sm:text-lg text-sm inline-block float-left font-bold">#3784</span>
                    <span class=" lg:leading-lh-5 sm:leading-lh-3 leading-10 lg:text-xl sm:text-lg text-sm text-[#F7FC0E] inline-block float-right font-bold" style="background-image: -webkit-linear-gradient(159deg, #FF8D8D 0%, #F7FC0E 100%);-webkit-background-clip: text;-webkit-text-fill-color: transparent;">#0.01/0.06</span>
                    <img src="https://static.soulmeta.io/web/img/game-mora/w-gamesele01.webp" class="block lg:h-6 lg:w-6 h-4 w-4 float-right lg:mt-7 sm:mt-4 mt-3 lg:mr-2 mr-1" alt="">
                  </div>                  
                </div>
                 <div  class="w-1/2 mx-auto mt-5 text-center bg-E4FF02 text-1126AF lg:text-2xl sm:text-lg text-sm uppercase py-2.5 rounded cursor-pointer">RECEIVE</div>
        
              </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import { getEther } from "@/plugins/ethers";

export default {
  components: {
    Header,
  },
  data() {
    return {
      invitorLink: "",
      balanceOf:0,
      receiveCheck:false,
      invitor:window.location.search?.split("?")[1]?.split("&")[0]?.split("=")[1],
      isOwn:false,
      selectList:[
        {index:0,name:'TIME'},
        {index:1,name:'AMOUNT'},
        {index:2,name:'MINE'},
      ],
      selectIndex:0
    };
  },
  computed: {},
  async created() {
    this.eth = await getEther();
    this.invitorLink = window.location.origin + window.location.pathname + "?invitor=" + this.eth.myAddr;
    let balanceOf= await this.eth.c.s2dNft.balanceOf(this.eth.myAddr);
    let receiveCheck= await this.eth.c.s2dNftSale.receiveMap(this.eth.myAddr);
    this.receiveCheck=receiveCheck
    this.balanceOf=balanceOf
    this.isOwn=this.eth.myAddr==window.location.search?.split("?")[1]?.split("&")[0]?.split("=")[1]
  },
  mounted(e){
  },
  methods:{
    to2dNft(){  
      if(this.$route.query.invitor!=undefined){
          window.location.href='https://2dnft.soulmeta.io/'+"?invitor=" + window.location.search?.split("?")[1]?.split("&")[0]?.split("=")[1]
      } else{
          window.location.href='https://2dnft.soulmeta.io/'
      }   
      
    },    
    async tokenReceive(){
      try {
        let signMessage = await this.eth.c.s2dNftSale.tokenReceive(window.location.search?.split("?")[1]?.split("&")[0]?.split("=")[1])
        if (signMessage) {
          this.$message.success('Binding success');
        }else{          
          this.$message.error('Binding failure');
        }
      } catch (e) {
        this.$message.error('Binding failure');
      }
    },
    toNftFight(){
      this.$store.commit("setSoon", true);
      return
      this.$router.push({path: '/nftFight'});
    },    
    doCopy(text) {
      this.$copyText(text).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },
  }
};
</script>

<style lang="scss" scoped>
.invitor-bg {
  background: rgb(228 255 2 / 7%);
}
</style>

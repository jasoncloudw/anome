<template>
  <div class="bg pb-20">
    <div class="lg:w-200 xl:w-300 w-9/10 mx-auto relative">
      <Header class="hidden md:block" />

      <div class="py-5 flex justify-between items-center">
        <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.push('/')" />
        <div class="w-full pr-7 flex md:hidden justify-center">
          <div class="w-full flex items-center justify-center">
            <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            <div class="font-semibold">SOULMETA</div>
          </div>
        </div>
      </div>
      <div class="xl:w-full xl:mx-auto xl:flex justify-center xl:mt-10">
        <div class="xl:w-1/2 xl:px-14">
          <div class="w-72 md:w-80 md:min-w-80 xl:w-9/10 h-68 xl:h-110 md:min-h-80 mx-auto relative" :class="!userInfo.img && 'file-bg'">
            <input type="file" class="w-full h-full z-10 opacity-0 absolute top-0" @change="uploadFile($event)" />
            <img
              v-if="userInfo.img"
              :src="userInfo.img"
              class="max-w-full max-h-full absolute top-1/2 left-1/2 transform -translate-y-1/2 -translate-x-1/2"
              alt=""
            />
          </div>
          <div class="w-9/10 md:w-80 md:min-w-80 xl:w-9/10 mx-auto">
            <div class="my-2 text-xs md:text-sm md:text-left text-gray">
              {{ $t("caste.cas1") }}
            </div>
            <div class="my-2 text-xs md:text-sm text-yellow-200">
              {{ $t("caste.cas15") }}
            </div>
          </div>
        </div>
        <div class="md:mt-20 lg:mt-10 xl:mt-0 xl:w-1/2 xl:pl-10">
          <!-- <img class="w-72 mx-auto" src="https://static.soulmeta.io/web/img/caste/look.webp" alt=""> -->
          <img class="w-9/10 mx-auto md:ml-0 md:w-full md:h-7" src="https://static.soulmeta.io/web/img/caste/Rectangle.webp" alt="" />
          <div class="w-9/10 md:w-full mt-2 md:mt-5 mx-auto md:ml-0 relative">
            <div class="relative">
              <input
                v-model="userInfo.contInfo"
                type="text"
                class="w-full h-10 md:h-12 px-10 text-center inp-sty rounded-3xl md:text-xl"
                :placeholder="$t('caste.cas2')"
              />
              <img
                v-show="userInfo.contInfo"
                class="w-5 absolute top-1/2 right-2 transform -translate-y-1/2"
                src="https://static.soulmeta.io/web/img/caste/right_icn.webp"
                alt=""
              />
              <img
                class="w-7 absolute left-2 top-1/2 transform -translate-y-1/2 cursor-pointer"
                :src="'https://static.soulmeta.io/web/img/caste/link' + userInfo.linkType + '.webp'"
                alt=""
                @click="linkType = !linkType"
              />
            </div>
          </div>
          <img class="mt-5" src="https://static.soulmeta.io/web/img/caste/bor.webp" alt="" />
          <div class="mt-2 md:mt-5 flex justify-around md:justify-between">
            <div
              v-for="item in linkTypeList"
              :key="item.key"
              class="rounded-full mt-1 cursor-pointer"
              @click="
                userInfo.linkType = item.key;
                linkType = false;
              "
            >
              <img
                v-if="userInfo.linkType === item.key"
                class="w-7 md:w-10 rounded-full"
                :src="'https://static.soulmeta.io/web/img/caste/link' + item.key + '.webp'"
                alt=""
              />
              <img v-else class="w-7 md:w-10 rounded-full" :src="'https://static.soulmeta.io/web/img/caste/link_no' + item.key + '.webp'" alt="" />
            </div>
          </div>
          <div class="mt-5 md:mt-7">
            <div class="text-center md:text-xl text-gray">
              {{ $t("caste.cas3") }}
            </div>
            <div class="w-full px-3 md:px-6 flex flex-wrap justify-center text-center md:leading-10">
              <div
                v-for="item in numList"
                :key="item.num"
                class="w-20 md:w-24 xl:w-32 mt-3 md:mt-5 mx-1 xl:mx-2 rounded-full cursor-pointer"
                :class="userInfo.soulNum === item.num ? 'bg-F02' : 'bg-707'"
                @click="selectSoulNum(item.num)"
              >
                {{ item.value }}
              </div>
            </div>
          </div>
          <div class="w-80 text-left text-sm mt-4 xl:mt-8 mx-auto">{{ $t("caste.cas14") }}</div>
          <div class="w-full flex items-start justify-center my-8 mt-4 xl:mt-8">
            <div class="cursor-pointer" :class="[$route.query.gender ? 'hidden' : 'block']" @click="userInfo.type = '1'">
              <div class="blind-box-btn w-10 md:w-14 h-10 md:h-14 rounded-full bg-F02 py-[2px] mx-auto">
                <div class="w-full h-full flex items-center justify-center rounded-full" :class="[userInfo.type === '1' ? 'bg-F02' : 'bg-black']">
                  <img class="w-5 h-auto" src="https://static.soulmeta.io/web/img/home/man.webp" alt="" />
                </div>
              </div>
              <div class="text-center mt-1">{{ $t("home.home22") }}</div>
            </div>
            <div class="w-48 md:w-72 mx-4 md:mx-10 md:mb-4 py-1 md:py-3 text-xl font-semibold text-center rounded-xl bg-F02 cursor-pointer" @click="toBuy">
              {{ $t("caste.cas4") }}
            </div>
            <div class="cursor-pointer" :class="[$route.query.gender ? 'hidden' : 'block']" @click="userInfo.type = '2'">
              <div class="blind-box-btn w-10 md:w-14 h-10 md:h-14 rounded-full bg-F02 py-[2px] mx-auto">
                <div class="w-full h-full flex items-center justify-center rounded-full" :class="[userInfo.type === '2' ? 'bg-F02' : 'bg-black']">
                  <img class="w-5 h-auto" src="https://static.soulmeta.io/web/img/home/woman.webp" alt="" />
                </div>
              </div>
              <div class="text-center mt-1">{{ $t("home.home23") }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="md:mt-20">
        <div class="text-sm md:text-3xl text-center">
          {{ $t("caste.cas5") }}
        </div>
        <img class="mt-1 md:mt-2.5 w-full" src="https://static.soulmeta.io/web/img/caste/bor.webp" alt="" />
        <div class="w-full mx-auto mt-5 text-xs md:text-base text-gray">&nbsp;&nbsp;&nbsp;&nbsp;{{ $t("caste.cas6") }}</div>
      </div>
    </div>
    <Footer class="hidden md:block" />
  </div>
</template>

<script>
import Footer from "@/components/footer.vue";
import Header from "@/components/header.vue";
import { getEther } from "@/plugins/ethers";
import { sliceDecimals } from "@/plugins/handleAmount";
export default {
  name: "casting",
  components: { Header, Footer },

  data() {
    return {
      soulNum: 1,
      linkType: false,
      valueUrl: "",
      userEmil: "",
      userInfo: {},
      numList: [],
      linkTypeList: [
        {
          key: 0,
        },
        {
          key: 1,
        },
        {
          key: 2,
        },
        {
          key: 3,
        },
        // {
        //   key: 4,  
        // },
        // {
        //   key: 5,
        // },
        {
          key: 6,
        },
      ],
    };
  },
  methods: {
    toBuy() {
      if (!this.userInfo.img) {
        this.$message.error(this.$t("msg.msg4"));
      } else if (!this.userInfo.contInfo) {
        this.$message.error(this.$t("msg.msg5"));
      } else if (!this.userInfo.type) {
        this.$message.error(this.$t("msg.msg15"));
      } else {
        this.$router.push({
          path: "/mint",
          query: {
            identity: this.$route.query.identity,
          },
        });
      }
    },
    async selectSoulNum(num) {
      // if (this.userInfo.soulNum === num) {
      //     this.userInfo.soulNum = 0
      //     return
      // }
      let balanceOf = await this.eth.c.soul.balanceOf(this.eth.myAddr);
      if (parseInt(this.eth.utils.formatEther(balanceOf)) < num) {
        this.$message.error(this.$t("msg.msg6"));
        return;
      }
      this.userInfo.soulNum = num;
    },
    async uploadFile(el) {
      if (!el.target.files[0] || !el.target.files[0].size) return; // 如果文件大小为0，则返回
      if (el.target.files[0].size / 1024 / 1024 > 5) {
        this.$message.error(this.$t("msg.msg7"));
        return;
      }

      if (el.target.files[0].type.indexOf("image") === -1) {
        //如果不是图片格式
        this.$message.error(this.$t("msg.msg8"));
      } else if (el.target.files[0].type === "image/jpeg" || el.target.files[0].type === "image/png" || el.target.files[0].type === "image/gif") {
        const that = this;
        const reader = new FileReader(); // 创建读取文件对象
        reader.readAsDataURL(el.target.files[0]); // 发起异步请求，读取文件
        reader.onload = function () {
          // 文件读取完成后
          // 读取完成后，将结果赋值给img的src
          that.userInfo.img = this.result;
          that.userInfo.file = el.target.files[0];
        };
      } else {
        this.$message.error(this.$t("msg.msg9") + ": JPG, PNG, GIF");
      }
    },
    async getSoulPrice() {
      let soulBala = await this.eth.c.soul.balanceOf(this.eth.c.lp.address);
      let usdtBala = await this.eth.c.usdt.balanceOf(this.eth.c.lp.address);
      let soulPrice = this.eth.utils.formatEther(usdtBala) / this.eth.utils.formatEther(soulBala);
      // let identity = this.$route.query.identity;
      let identity = "civilian";
      this.numList = [
        {
          num: 1,
          value: sliceDecimals(6 / soulPrice),
        },
        {
          num: 5,
          value: sliceDecimals((identity === "3dcitizen" ? 20 : 10) / soulPrice),
        },
        {
          num: 10,
          value: sliceDecimals((identity === "3dcitizen" ? 50 : 15) / soulPrice),
        },
        {
          num: 15,
          value: sliceDecimals((identity === "3dcitizen" ? 60 : 25) / soulPrice),
        },
        {
          num: 20,
          value: sliceDecimals((identity === "3dcitizen" ? 100 : 50) / soulPrice),
        },
      ];
    },
  },
  async created() {
    this.userInfo = this.$store.state.casteInfo;
    if (this.$store.state.boxType) {
      this.userInfo.type = this.$store.state.boxType;
    } else {
      this.userInfo.type = this.$route.query.gender;
      this.$store.commit("setBoxType", this.$route.query.gender);
    }
    this.eth = await getEther();
    this.getSoulPrice();
  },
};
</script>
<style lang="scss" scoped>
.bg {
  background: #000;
}

.inp-sty {
  &:focus {
    outline: medium;
  }
  &::-webkit-input-placeholder {
    font-size: 12px;
    color: #fff;
    opacity: 0.5;
  }
  background-image: linear-gradient(to right, #a981f0, #fb8696);
}

.file-bg {
  background: url(https://static.soulmeta.io/web/img/caste/file_bg.webp) no-repeat center/100% 100%;
}

@media (min-width: 768px) {
  .inp-sty {
    &::-webkit-input-placeholder {
      font-size: 20px;
    }
  }
}
</style>

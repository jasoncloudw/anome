<template>
  <div
    class="w-full h-full bodyBack flex rotate-90 lg:rotate-0 origin-center"
    :style="bodyStyle"
  >
    <div
      class="flex-none lg:h-5/6 h-full lg:mt-[4%] lg:w-32 w-20 lg:p-4 p-2 overflow-auto scrollStyle"
    >
      <img
        class="w-full border-4 border-black rounded-lg lg:mt-4 mt-2 cursor-pointer"
        :class="itemSelect == index ? 'border-white ' : ''"
        @click="itemSelect = index"
        v-for="(item, index) in 10"
        :key="index"
        src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-memLogo.webp"
        alt=""
      />
    </div>
    <div
      class="flex-none lg:w-96 w-48 h-full relative"
    >
      <div class="nftBack w-4/5 absolute left-1/2 top-1/2 p-2"
          style="transform: translate(-50%, -50%)">
        <img
          class="w-full"
          src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-memDetail.webp"
          alt=""
        />
      </div>
    </div>
    <div class="grow py-6 lg:py-8 lg:pr-8 pr-6">
      <div class="w-full roomBack h-full pt-12 lg:pt-20 relative pb-4 lg:pb-8">
        <div class="w-full absolute top-3 lg:top-6 left-0 h-6 px-6 lg:px-10">
          <div class="inline-block float-left" @click="selectIndex = 0">
            <img
              class="h-6 lg:h-8 float-left"
              :src="
                'https://static.soulmeta.io/web/img/2dnft-fight/nft2d-fight' +
                selectIndex +
                '.webp'
              "
              alt=""
            />
            <span
              :class="selectIndex == 0 ? 'text-white' : 'text-neutral-400'"
              class="inline-block float-left leading-6 lg:leading-8 ml-2 font-bold text-sm lg:text-lg"
              >{{ $t("gameslobby.game4") }}</span
            >
          </div>
          <div class="inline-block float-left ml-6" @click="selectIndex = 1">
            <img
              class="h-6 lg:h-8 float-left"
              :src="
                'https://static.soulmeta.io/web/img/2dnft-fight/nft2d-record' +
                selectIndex +
                '.webp'
              "
              alt=""
            />
            <span
              :class="selectIndex != 0 ? 'text-white' : 'text-neutral-400'"
              class="inline-block float-left leading-6 lg:leading-8 ml-2 font-bold text-sm lg:text-lg"
              >Record</span
            >
          </div>
          <img
            class="h-6 lg:h-8 float-right cursor-pointer"
            src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-close.webp"
            alt=""
            @click="closeShow = true"
          />
        </div>
        <div
          class="w-full h-full overflow-auto scrollRoomStyle p-4 lg:p-8 pt-0 lg:pt-0"
        >
          <div v-show="selectIndex == 0">
            <div
              class="xl:w-1/3 2xl:w-1/4 w-1/2 p-2 float-left box-border overflow-hidden"
              v-for="(item, index) in 20"
              :key="index"
            >
              <div
                class="w-full roomBC h-full sm:p-3 lg:p-4 p-2 overflow-hidden"
              >
                <span
                  class="w-1/2 float-left block sm:text-sm lg:text-lg text-xs"
                  >{{ $t("gameslobby.game4") }}{{ index + 1 }}</span
                >
                <span
                  class="w-1/2 float-left block sm:text-sm lg:text-lg text-xs text-right"
                  >Dark Castle</span
                >
                <div class="w-1/3 overflow-hidden float-left mt-2 relative">
                  <strong
                    class="absolute text-black block w-full text-xs md:text-sm lg:text-lg text-center top-1/2 -mt-2 md:-mt-3.5 font-normal md:font-bold cursor-pointer"
                    @click="displayshow = true"
                    >{{ $t("gameslobby.game8") }}</strong
                  >
                  <img
                    class="w-full"
                    src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-roominfo.webp"
                    alt=""
                  />
                </div>
                <img
                  class="w-1/3 float-left sm:p-3 lg:p-5 xl:p-6 3xl:p-8 p-2 box-border"
                  src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-fight.webp"
                  alt=""
                />
                <div class="w-1/3 overflow-hidden float-left mt-2 relative">
                  <strong
                    class="absolute text-black block w-full text-xs md:text-sm lg:text-lg text-center top-1/2 -mt-2 md:-mt-3.5 font-normal md:font-bold cursor-pointer"
                    @click="displayshow = true"
                    >{{ $t("gameslobby.game8") }}</strong
                  >
                  <img
                    class="w-full"
                    src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-roominfo.webp"
                    alt=""
                  />
                </div>
              </div>
            </div>
          </div>
          <div class="w-full overflow-auto" v-show="selectIndex == 1">
            <ul
              v-if="combatsData.length != 0"
              class="w-full h-full block overflow-auto scrollstr"
            >
              <li
                class="overflow-auto border-b border-515 py-3 w-full"
                v-for="(item, index) in combatsData"
                :key="index"
              >
                <div class="w-full overflow-hidden">
                  <span
                    :class="item.resuleStart ? 'bg-amber-500' : 'bg-slate-200'"
                    class="lg:w-16 lg:h-10 w-12 h-8 lg:text-lg text-xs text-center lg:leading-10 leading-8 rounded-lg float-left block"
                    >{{
                      item.resuleStart
                        ? $t("gameslobby.game38")
                        : $t("gameslobby.game37")
                    }}</span
                  >
                  <strong
                    class="lg:w-24 w-10 h-10 lg:text-lg text-xs text-right lg:leading-10 leading-8 rounded-lg float-left inline-block"
                    >{{ item.resuleStart ? "+" : "-"
                    }}{{
                      item.resuleStart
                        ? item.winBet / Math.pow(10, 18)
                        : item.bet / Math.pow(10, 18)
                    }}</strong
                  >
                  <img
                    class="lg:h-10 h-8 p-2 float-left"
                    src="https://static.soulmeta.io/web/img/home/logo.webp"
                    alt=""
                  />
                  <p
                    class="leading-10 truncate block ml-6 float-left w-full lg:block hidden"
                    style="width: calc(100% - 20rem)"
                  >
                    {{ $t("gameslobby.game36") }}：{{ item.resuleAddress }}
                  </p>
                  <span
                    class="lg:h-10 h-8 text-xs lg:leading-10 leading-8 text-center rounded-lg float-right block border px-3 border-slate-200"
                    >{{ $t("gameslobby.game39") }}{{ item.roomId }}</span
                  >
                </div>
                <div class="w-full">
                  <div class="lg:w-[30%] w-[50%] float-left leading-10 mt-2">
                    <span
                      class="inline-block float-left lg:text-lg text-sm lg:leading-10 leading-8"
                      >{{ $t("gameslobby.msg24") }}：</span
                    >
                    <img
                      v-for="(items, index) in item.ismora"
                      :key="index"
                      class="lg:h-8 lg:w-8 h-6 w-6 m-1 float-left"
                      :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`"
                      alt=""
                    />
                  </div>
                  <div class="lg:w-[30%] w-[50%] float-left leading-10 mt-2">
                    <span
                      class="inline-block float-left lg:text-lg text-sm lg:leading-10 leading-8"
                      >{{ $t("gameslobby.game36") }}：</span
                    >
                    <img
                      v-for="(items, index) in item.noismora"
                      :key="index"
                      class="lg:h-8 lg:w-8 h-6 w-6 m-1 float-left"
                      :src="`https://static.soulmeta.io/web/img/game-mora/mora${items}.webp`"
                      alt=""
                    />
                  </div>
                  <div class="lg:w-[40%] w-full float-left leading-10 mt-2">
                    <span
                      class="lg:hidden block text-left lg:text-sm text-xs w-1/2 float-left truncate"
                      >{{ $t("gameslobby.game36") }}：{{
                        item.resuleAddress
                      }}</span
                    >
                    <span
                      class="text-right lg:text-lg text-xs block lg:w-full lg:leading-10 w-1/2 float-right"
                      >{{ item.createTime }}</span
                    >
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div
      class="fixed lg:w-4/5 w-2/5 max-w-screen-sm bg-black/90 top-1/2 left-1/2 z-999 openS pb-8 lg:pb-20"
      v-show="displayshow"
    >
      <div class="lg:w-72 lg:h-24 w-36 h-10 mx-auto lg:mt-16 mt-8">
        <img
          class="lg:w-12 w-6 float-left pt-3 lg:pt-6 lg:mr-12 mr-6 cursor-pointer"
          src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-selectLeft.webp"
          alt=""
          @click="selectsoulNft(0)"
        />
        <div
          class="lg:w-24 lg:h-24 w-12 h-12 float-left lg:selectclick box-border"
        >
          <img
            :src="soulNftListimg"
            class="w-full h-full block rounded-full"
            alt=""
          />
        </div>
        <img
          class="lg:w-12 w-6 float-left pt-3 lg:pt-6 lg:ml-12 ml-6 cursor-pointer"
          src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-selectRight.webp"
          alt=""
          @click="selectsoulNft(1)"
        />
      </div>
      <img
        class="absolute top-6 right-6 w-5 lg:top-8 lg:right-8 lg:w-7 cursor-pointer"
        @click="
          displayshow = false;
          refresh(), (dogfallroomid = '');
        "
        src="https://static.soulmeta.io/web/img/game-mora/w-displayclose.webp"
        alt=""
      />
      <div
        class="w-full mx-auto overflow-hidden lg:py-16 py-6 px-[10%] relative"
      >
        <img
          class="lg:h-8 h-4 block mx-auto cursor-pointer absolute top-0 right-[10%]"
          src="https://static.soulmeta.io/web/img/2dnft-fight/nft2d-refresh.webp"
          alt=""
          @click="refresh()"
        />
        <div
          class="w-3/12 cursor-pointer relative p-4 float-left"
          @click="selectindex(0)"
          :class="select[0] != 0 ? 'selectback' : 'noselectback'"
        >
          <span
            v-show="select[0]"
            class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
            >{{ select[0] }}</span
          >
          <img
            class="lg:w-1/2 mx-auto lg:py-1/4 w-3/5 py-[20%]"
            src="https://static.soulmeta.io/web/img/game-mora/wstone.webp"
            alt=""
          />
        </div>
        <div
          class="w-3/12 cursor-pointer relative p-4 float-left mx-[12.5%]"
          @click="selectindex(1)"
          :class="select[1] != 0 ? 'selectback' : 'noselectback'"
        >
          <span
            v-show="select[1]"
            class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
            >{{ select[1] }}</span
          >
          <img
            class="lg:w-1/2 mx-auto lg:py-1/4 w-3/5 py-[20%]"
            src="https://static.soulmeta.io/web/img/game-mora/wscissors.webp"
            alt=""
          />
        </div>
        <div
          class="w-3/12 cursor-pointer relative p-4 float-left"
          @click="selectindex(2)"
          :class="select[2] != 0 ? 'selectback' : 'noselectback'"
        >
          <span
            v-show="select[2]"
            class="absolute -right-2 -top-2 w-6 h-6 lg:-right-5 lg:-top-5 lg:w-10 lg:h-10 text-center lg:leading-10 leading-6 rounded-full bg-red-700"
            >{{ select[2] }}</span
          >
          <img
            class="lg:w-1/2 mx-auto lg:py-1/4 w-3/5 py-[20%]"
            src="https://static.soulmeta.io/web/img/game-mora/wcloth.webp"
            alt=""
          />
        </div>
      </div>
      <div
        class="sm:w-96 w-4/5 sm:h-16 h-12 mx-auto rounded-md overflow-hidden mt-0"
        style="background-color: #272727"
      >
        <input
          class="block w-2/3 sm:w-72 border-0 outline-none sm:h-16 h-12 px-4 sm:text-lg text-sm float-left"
          type="text"
          v-model="amount"
          :disabled="amountdisbale"
          style="background-color: #272727"
        />
        <span
          class="sm:w-24 w-1/3 float-left block text-center sm:leading-8 leading-6 sm:my-4 my-3 border-l border-white"
          >SOUL</span
        >
      </div>
      <div class="w-full mx-auto lg:mt-16 mt-6">
        <div
          @click="toplay"
          class="w-4/5 rounded-full lg:h-12 h-10 mx-auto text-center lg:leading-lh-3 leading-10 font-bold lg:text-lg text-sm cursor-pointer bg-white text-black"
        >
          {{ $t("gameslobby.game14") }}
        </div>
      </div>
    </div>
    <div
      class="fixed lg:w-96 w-80 max-w-screen-sm bg-black/90 top-1/2 left-1/2 z-999 closeS p-6"
      v-show="closeShow"
    >
      <p class="text-lg text-center pt-6 pb-8">
        Are you sure you want to return to the main page?
      </p>
      <div class="w-full">
        <!-- {{ $t("acc.acc20") }} -->
        <strong
          class="w-[47%] cursor-pointer float-left block lg:text-lg text-sm text-center h-10 border border-white text-white rounded-full mr-[6%] lg:leading-10 leading-10"
          @click="closeShow = false"
          >Cancel</strong
        >
        <strong
          class="w-[47%] cursor-pointer float-left block lg:text-lg text-sm text-center h-10 border border-white bg-white text-black rounded-full lg:leading-10 leading-10"
          @click="$router.go(-1)"
          >Confirm</strong
        >
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss"></style>

<script>
export default {
  data() {
    return {
      closeShow: false,
      bodyStyle: {
        width:
          window.innerWidth < 1024
            ? window.innerHeight + "px"
            : window.innerWidth + "px",
        height:
          window.innerWidth < 1024
            ? window.innerWidth + "px"
            : window.innerHeight + "px",
        "transform-origin": window.innerWidth / 2 + "px",
      },
      itemSelect: 1,
      selectIndex: 0,
      combatsData: [
        {
          resuleStart: false,
          ismora: "1",
          noismora: "0",
          resuleAddress: "0x2e9770C48Ae2B6C7F9aF13b329e68c066D7549E3",
          _id: "62c7a4278fec64bf30721ac0",
          roomId: 2,
          player1: "0x3BD4D98b35Dda84B352990c69Bf2d4f199194b04",
          player1_RPS: "1",
          player1_token: "58",
          player2: "0x2e9770C48Ae2B6C7F9aF13b329e68c066D7549E3",
          player2_RPS: "0",
          player2_token: "38",
          bet: 4000000000000000000,
          winBet: 7200000000000000000,
          result: 1,
          combatID: 1657250776689,
          winner: 1,
          createTime: "2022-07-08T03:27:35.796Z",
        },
      ],
      select: [0, 0, 0],
      displayshow: false,
      clickindex: 1,
      amount: 0,
      soulNftListimg: "https://static.soulmeta.io/nft/3dnft/183.png",
    };
  },
  mounted() {},
  methods: {
    selectindex(e) {
      if (this.select[e] == 1) {
        let istwo = this.select.indexOf(2);
        let isthree = this.select.indexOf(3);
        if (istwo != -1) {
          this.select[istwo] = 1;
        }
        if (isthree != -1) {
          this.select[isthree] = 2;
        }
      }
      if (this.select[e] == 2) {
        let isthree = this.select.indexOf(3);
        this.select[isthree] = 2;
      }
      if (this.select[e] != 0) {
        this.select.splice(e, 1, 0);
        this.clickindex--;
        return;
      }
      this.select.splice(e, 1, this.clickindex);
      this.clickindex++;
    },
    // 点击刷新
    async refresh() {
      this.select = [0, 0, 0];
      this.clickindex = 1;
      if (!this.amountdisbale) {
        this.amount = 0;
      }
    },
  },
};
</script>
<style scoped>
.bodyBack {
  background: linear-gradient(135deg, #121820 0%, #1c2d3f 100%);
}
.roomBack {
  background: url("https://static.soulmeta.io/web/img/2dnft-fight/roomBack.webp") no-repeat center/100% 100%;
}
.nftBack {
  background: url("https://static.soulmeta.io/web/img/2dnft-fight/nft2d-nftBack.webp") no-repeat center/100%
    100%;
}
.roomBC {
  background: url("https://static.soulmeta.io/web/img/2dnft-fight/nft2d-room.webp") no-repeat center/100% 100%;
}
.openS {
  transform: translate(-50%, -50%);
  background: url("https://static.soulmeta.io/web/img/2dnft-fight/nft2d-openS.webp") no-repeat center/100% 100%;
}
.closeS {
  transform: translate(-50%, -50%);
  background: url("https://static.soulmeta.io/web/img/2dnft-fight/nft2d-closeBack.webp") no-repeat center/100%
    100%;
}

.scrollStyle::-webkit-scrollbar {
  width: 0px;
}
.scrollRoomStyle::-webkit-scrollbar {
  width: 4px;
}
.scrollRoomStyle::-webkit-scrollbar-thumb {
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 5px rgba(18, 24, 32, 1);
  background: #121820;
}
.scrollRoomStyle::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 5px rgba(28, 45, 63, 1);
  border-radius: 0;
  background: #1c2d3f;
}
.selectclick {
  border: 4px solid #8c8c8c;
  border-radius: 50%;
}
.selectback {
  border: 1px solid rgba(0, 0, 0, 0);
  background: url("https://static.soulmeta.io/web/img/game-mora/wdisselectback.webp")
    no-repeat center/100% 100%;
}
.selectclickt {
  background: url("https://static.soulmeta.io/web/img/game-mora/roomback2.webp")
    no-repeat center/100% 100%;
}

.noselectback {
  border: 1px solid #f9f9f9;
  box-sizing: border-box;
  border-radius: 10px;
}
</style>

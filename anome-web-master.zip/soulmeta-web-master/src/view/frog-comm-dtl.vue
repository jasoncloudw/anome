<template>
  <div class="min-h-full pb-20 bg-black">
    <div class="w-9/10 lg:w-200 xl:w-300 mx-auto">
      <Header class="hidden md:block" />

      <div class="py-5 flex justify-between items-center">
        <img class="w-3 cursor-pointer" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.push('/frog-clan')" />
        <div class="w-full pr-7 flex md:hidden justify-center">
          <div class="w-full flex items-center justify-center">
            <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            <div class="font-semibold">SOULMETA</div>
          </div>
        </div>
      </div>

      <div class="md:flex md:items-center md:mt-10">
        <div class="md:w-2/5 md:pr-12 xl:pr-24">
          <img class="rounded-t-xl" :src="'https://static.soulmeta.io/nft/smcl/' + info.imgId + '.png'" alt="" />
          <div class="p-2 md:p-3 text-sm rounded-b-xl bg-2D2">
            <div class="flex justify-between md:text-xl">
              <div>Corsair pistol</div>
              <div class="flex items-center"><img class="w-6 mr-1" src="https://static.soulmeta.io/web/img/frog/frog_icon.webp" alt="" />33.78 BNB</div>
            </div>
            <div class="mt-5 md:mb-3 flex items-center justify-between">
              <div class="flex items-center text-gray">
                {{ $t("frog.frog8") }}：0xiot...7aB2<img class="w-4 ml-1" src="https://static.soulmeta.io/web/img/acc/copy.webp" alt="" />
              </div>
              <div class="flex items-center text-gray">0xiot...7aB2<img class="w-4 ml-1" src="https://static.soulmeta.io/web/img/acc/copy.webp" /></div>
            </div>
          </div>
        </div>
        <div class="md:w-3/5">
          <div class="my-5 xl:my-10 flex items-center">
            <img class="w-20 rounded-full" :src="'https://static.soulmeta.io/nft/smcl/' + info.imgId + '.png'" alt="" />
            <div class="ml-3 md:ml-6 font-semibold md:text-2xl">SoulMeta Frog</div>
          </div>
          <div class="flex items-start justify-between">
            <div class="w-32 flex justify-between">
              <div class="pb-1 cursor-pointer md:text-xl" :class="navInfo === 1 ? 'border-b-2 border-red-600' : 'text-gray'" @click="navInfo = 1">
                {{ $t("frog.frog9") }}
              </div>
              <div class="pb-1 cursor-pointer md:text-xl" :class="navInfo === 2 ? 'border-b-2 border-red-600' : 'text-gray'" @click="navInfo = 2">
                {{ $t("frog.frog10") }}
              </div>
            </div>
            <div class="flex items-center justify-center">
              <img class="h-5 md:h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
              <div class="text-sm md:text-xl">SOULMETA</div>
            </div>
          </div>
          <div class="mt-5 text-sm md:text-xl">
            <div class="mb-3">{{ $t("frog.frog11") }}</div>
            <div class="mb-3 flex items-start justify-between">
              <div class="text-gray">{{ $t("frog.frog12") }}</div>
              <div class="text-gray">ERC721</div>
            </div>
            <div class="mb-3 flex items-start justify-between">
              <div class="text-gray">{{ $t("frog.frog13") }}</div>
              <div class="text-gray">BSC</div>
            </div>
            <div class="mb-3 flex items-start justify-between">
              <div class="text-gray">{{ $t("frog.frog14") }}</div>
              <div class="text-gray">0xc31...B3a94</div>
            </div>
          </div>
          <div
            class="w-48 xl:w-60 mx-auto mt-5 xl:mt-10 py-1 xl:py-3 text-center rounded bg-F02 md:text-xl cursor-pointer"
            @click="$store.commit('setSoon', true)"
          >
            {{ $t("frog.frog15") }}Soul
          </div>
        </div>
      </div>
    </div>
    <Footer class="hidden md:block" />
  </div>
</template>

<script>
import Header from "@/components/header.vue";
import Footer from "@/components/footer.vue";

export default {
  name: "fCDetail",
  components: {
    Header,
    Footer,
  },
  data() {
    return {
      info: {},
      navInfo: 1,
    };
  },
  created() {
    this.info.imgId = this.$route.query.imgId;
    this.info.teamId = this.$route.query.teamId;
  },
};
</script>

<style lang="scss" scoped></style>

<template>
  <div class="bg-black min-h-full">
    <img
      class="w-50 absolute top-10 left-20 cursor-pointer hidden md:block"
      src="https://static.soulmeta.io/web/img/nft-mall/nft-mall-logo.webp"
      alt=""
      @click="$router.back()"
    />
    <div class="w-9/10 md:w-200 xl:w-300 mx-auto pt-0 md:pt-20 pb-10 md:pb-0">
      <div class="flex justify-center items-center relative">
        <img
          class="block md:hidden absolute left-[5%] z-10 w-3 cursor-pointer"
          src="https://static.soulmeta.io/web/img/succ/return_icon.webp"
          alt=""
          @click="$router.back()"
        />
        <h2 class="text-xl md:text-3xl font-bold md:font-normal text-center py-10">{{ $t("nftmall.mall3") }}</h2>
      </div>
      <div class="red-line hidden md:block"></div>
      <div class="w-full md:w-4/5 md:flex md:justify-center mx-auto mt-0 md:mt-16">
        <div class="w-full md:w-1/2 pr-0 md:pr-[12%]">
          <div class="bg rounded-md">
            <div class="img-bg w-full rounded-md">
              <img
                class="w-1/2 md:w-3/5 py-8 md:py-10 h-full mx-auto"
                :src="'https://static.soulmeta.io/web/img/nft-mall/batch-of-prop-' + propData.key + '.webp'"
                alt=""
              />
            </div>
            <div class="p-8">
              <div class="flex items-center justify-between">
                <div class="text-sm md:text-xl">SoulMeta</div>
                <div class="flex items-center">
                  <span class="text-sm md:text-2xl mr-2 font-bold">{{ propData.price }}</span>
                  <span class="text-sm md:text-xl">SOUL</span>
                  <!-- <img class="w-3 md:w-4 h-auto" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" /> -->
                </div>
              </div>
              <div class="flex items-center justify-between">
                <div class="text-sm md:text-xl text-white">{{ $t("nftmall.mall1") }}</div>
                <div class="text-xs md:text-base">{{ $t("nftmall.mall2") }}:{{ propData.quantity }}</div>
              </div>
            </div>
          </div>
          <div
            class="btn-bg hidden md:flex items-center justify-center mt-16 h-14 rounded-full cursor-pointer text-sm md:text-xl"
            v-loading="loading"
            @click="buyProp"
          >
            <span>{{ $t("nftmall.mall10") }}</span>
            <span class="mr-2">&nbsp;{{ propData.price }}</span>
            <span>SOUL</span>
          </div>
        </div>
        <div class="w-full md:w-1/2">
          <div class="w-full">
            <!-- <div class="flex items-center">
            <div class="w-8 md:w-24 h-8 md:h-24 bg-[#222222] rounded-full flex items-center justify-center">
              <img class="w-1/2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
            </div>
            <p class="ml-6 text-[#E8136C] text-xs md:text-xl">Monochrome Stills</p>
          </div> -->
            <!-- <div class="text-base md:text-3xl py-3 pt-4 md:pt-0 md:py-7">{{ $t("nftmall.mall2") }}</div> -->
            <div class="relative mt-5 md:mt-0">
              <div class="text-xs md:text-xl h-20 md:h-48 max-h-28 overflow-x-auto c-scrollbar pr-5 pb-2 md:pb-4">
                {{ $t("nftmall.mall11") }}
              </div>
              <div class="absolute left-0 bottom-0 w-[98%] h-4 md:h-10 text-overflow-mask z-10"></div>
            </div>
          </div>
          <div class="mt-0">
            <!-- history -->
            <!-- <div class="pt-4 md:pt-10">
              <header class="flex items-center justify-between text-base md:text-xl font-bold">
                <div>{{ $t("nftmall.mall8") }}</div>
                <div class="text-center">{{ $t("nftmall.mall7") }}</div>
                <div class="text-right">{{ $t("nftmall.mall9") }}</div>
              </header>

              <div class="flex items-center justify-between py-2.5" v-for="item in 4" :key="item">
                <div class="rounded-full">
                  <img class="w-8 h-auto" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
                </div>
                <div>
                  <div class="text-center text-xs md:text-xl">2021-05-23 09:16:36</div>
                </div>
                <div class="text-right text-xs md:text-xl">0xbBA...9543</div>
              </div>
            </div> -->
            <!-- details -->
            <div class="pt-4 md:pt-10 text-xs md:text-xl" v-show="!active">
              <div class="mt-4">{{ $t("nftmall.mall12") }}</div>
              <div class="flex items-center mt-4">
                <p class="text-[#888888]">BSC</p>
              </div>
              <div class="mt-4">ID</div>
              <div class="flex items-center mt-4">
                <img
                  class="w-3 md:w-5 mr-2 md:mr-4 cursor-pointer"
                  src="https://static.soulmeta.io/web/img/nft-mall/copy2.webp"
                  alt=""
                  @click="doCopy(propId)"
                />
                <p class="text-[#E8136C]">{{ propId }}</p>
              </div>
              <div class="mt-4">{{ $t("nftmall.mall13") }}</div>
              <div class="flex items-center mt-4">
                <img
                  class="w-3 md:w-5 mr-2 md:mr-4 cursor-pointer"
                  src="https://static.soulmeta.io/web/img/nft-mall/copy2.webp"
                  alt=""
                  @click="doCopy(contractAddr)"
                />
                <p class="text-[#E8136C]">{{ contractAddr }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        class="btn-bg flex md:hidden items-center justify-center mt-8 h-14 rounded-full cursor-pointer text-sm md:text-xl"
        v-loading="loading"
        @click="buyProp"
      >
        <span>{{ $t("nftmall.mall10") }}</span>
        <span class="mr-2">&nbsp;{{ propData.price }}</span>
        <span>SOUL</span>
      </div>
    </div>
  </div>
</template>

<script>
import { getEther } from "@/plugins/ethers";
import { sliceDecimals } from "@/plugins/handleAmount";

export default {
  data() {
    return {
      active: 0,
      propData: {},
      contractAddr: "",
      loading: false,
    };
  },
  computed: {
    propId() {
      return this.$route.params.id;
    },
  },
  async created() {
    this.eth = await getEther();
    this.contractAddr = this.eth.c.prop1155.address;
    this.requestPropData();
  },
  methods: {
    async requestPropData() {
      let soulBala = await this.eth.c.soul.balanceOf(this.eth.c.lp.address);
      let usdtBala = await this.eth.c.usdt.balanceOf(this.eth.c.lp.address);

      let quantity = await this.eth.c.prop1155.balanceOf(this.eth.c.propCore.address, this.propId);
      let { prices, times } = await this.eth.c.propCore.propEffect(this.propId);
      // let price = soulBala.mul(this.eth.utils.parseEther(prices.toString())).div(usdtBala);
      let price =(0.1 * Math.pow(10, 18)).toString()  
           this.propData = {
        id: this.propId,
        key: times.toNumber(),
        quantity: quantity.toString(),
        price: sliceDecimals(this.eth.utils.formatEther(price)),
      };
    },

    async buyProp() {
      // let propNum = await this.eth.c.prop1155.balanceOf(this.$store.state.myAddr, this.propId);

      // if (this.propNum.gt(0)) {
      //   this.$message.error(this.$t("nftmall.mall14"));
      //   return;
      // }

      let soulBalance = await this.eth.c.soul.balanceOf(this.$store.state.myAddr);
      if (soulBalance.lt(this.eth.utils.parseEther(this.propData.price))) {
        this.$message.error(this.$t("msg.msg6"));
        return;
      }

      let invitorBind = await this.eth.c.controller.referrers(this.$store.state.myAddr);
      let invitorLink = window.sessionStorage.getItem("invitor");
      let invitor = 0;
      parseInt(invitorBind) ? (invitor = invitorBind) : (invitor = invitorLink);
      if (!parseInt(invitor)) {
        this.$message.error(this.$t("nftmall.mall15"));
        return;
      }

      this.loading = true;
      let approveStatus = await this.eth.c.soul.allowance(this.$store.state.myAddr, this.eth.c.propCore.address);
      if (approveStatus.eq(0)) {
        try {
          let approve = await this.eth.c.soul.approve(this.eth.c.propCore.address, this.eth.constants.MaxUint256);
          await approve.wait();
        } catch (e) {
          this.loading = false;
        }
      }

      try {
        let res = await this.eth.c.propCore.buyProp(invitor, this.propId);
        await res.wait();
        this.requestPropData();
      } catch (e) {
        this.loading = false;
      }
      this.loading = false;
    },
    doCopy(text) {
      this.$copyText(text).then(
        (e) => {
          this.$message.success("Copied");
        },
        function (e) {
          this.$message.error("Can not copy");
        }
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.bg {
  background: #c3193f;
}
.img-bg {
  background: linear-gradient(180deg, #f0213b 0%, #e8136c 100%);
}
.btn-bg {
  background: linear-gradient(to bottom, #f0213b, #cb115f);
}

.c-scrollbar {
  &::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  &::-webkit-scrollbar-track {
    background-color: #484848;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
  &::-webkit-scrollbar-thumb {
    background-color: #fff;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    border-radius: 10px;
  }
}

.text-overflow-mask {
  background: linear-gradient(to bottom, transparent, #000);
}
</style>

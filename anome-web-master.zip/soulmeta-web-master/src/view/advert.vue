<template>
  <div class="advert">
    <Header class="hidden lg:block" />

    <div class="py-5 px-4 flex lg:hidden justify-between items-center">
      <img class="w-3" src="https://static.soulmeta.io/web/img/succ/return_icon.webp" alt="" @click="$router.push('/')" />
      <div class="w-full pr-7 flex justify-center">
        <div class="w-full flex items-center justify-center">
          <img class="h-7 mr-2" src="https://static.soulmeta.io/web/img/home/logo.png" alt="" />
          <div class="font-semibold sm:text-xl">SOULMETA</div>
        </div>
      </div>
    </div>
    <div class="lg:w-200 xl:w-300 mx-auto">
      <div class="pt-4 md:pt-16 flex justify-center">
        <div class="banner w-9/12 sm:w-full pb-0 md:pb-7 flex justify-center flex-wrap rounded-3xl">
          <div class="py-4 px-6 text-sm md:text-base leading-4 md:leading-8">
            <p class="text-xs md:text-base text-right text-FFD pb-4">0.01*SOUL</p>
            {{ $t("adv.adv1") }}
            <div class="mt-3 text-xs md:text-base">{{ $t("adv.adv28") }}</div>
          </div>
          <div
            :class="isReceiveSoul ? 'bg-838' : 'bg-FFD'"
            class="w-40 mb-5 leading-7 md:leading-10 rounded-full text-sm md:text-base text-center cursor-pointer text-black"
            @click="cliamSoul"
          >
            {{ $t("adv.adv2") }}
          </div>
        </div>
        <div class="w-9/12 flex justify-center relative" v-show="false">
          <p class="absolute text-xs px-4 pt-4">{{ $t("adv.adv14") }}</p>
          <img src="https://static.soulmeta.io/web/img/airdrop/airdropBanner.webp" />
        </div>
      </div>
      <div class="relative text-center text-FFD my-4 mt-16 border-b border-6F6 pb-4 md:text-3xl">
        {{ $t("adv.adv3") }}
        <a class="flex justify-center text-9E9 text-xs absolute right-5 top-1.5 md:hidden" href="#intro"
          >{{ $t("adv.adv4") }}<i class="toIco"><img class="w-31% ml-1" src="https://static.soulmeta.io/web/img/airdrop/toIco.webp" /></i
        ></a>
      </div>
      <div class="md:grid sm:grid-cols-2 xl:grid-cols-3 md:gap-8 xl:gap-12 md:py-10">
        <div class="advItem border-b md:border-0 border-6F6 md:relative md:pb-16" v-for="(item, index) in videoProList" :key="index">
          <div class="video hidden md:block">
            <img class="w-full" :src="item.banner_url" />
          </div>
          <div class="py-3 md:pt-5 w-9/10 mx-auto flex justify-between items-center">
            <div class="flex justify-start items-center align-top">
              <div class="mr-2 text-center">
                <img class="w-14 md:h-auto inline-block rounded-full" :src="item.logo_url" />
              </div>
              <div class="text-sm md:text-base">
                {{ item.project_name }}<br />
                <!-- <span class="text-xs">xxxxxx</span> -->
              </div>
            </div>
            <div class="flex justify-center items-center">
              <span class="mr-2">{{ item.cur }}/{{ item.total }}</span>
              <span><img class="w-6" src="https://static.soulmeta.io/web/img/airdrop/coinImg.webp" /></span>
            </div>
          </div>
              <div v-if="item.startTime && (new Date().getTime() / 1000) % 86400 < item.startTime % 86400" class="w-9/10 mx-auto text-right text-sm">{{ $t('adv.adv29') }}: {{ countdown(item.startTime) }}</div>

          <div class="video block md:hidden">
            <img class="w-full" :src="item.banner_url" />
          </div>
          <div class="py-2 w-9/10 mx-auto break-words">
            <div class="text-sm py-2 break-all">
              <span>{{ item["desc_" + $i18n.locale] }}{{ item.contract_addr }}</span>
              <img
                v-if="item.contract_addr"
                class="w-4 ml-2 inline"
                src="https://static.soulmeta.io/web/img/soulH/copy_icon.webp"
                alt=""
                @click="doCopy(item.contract_addr)"
              />
            </div>
            <p class="text-xs">
              {{ $t("adv.adv5") }}🔗<a class="text-88B" :href="item.web_site" target="_blank">{{ item.web_site }}</a>
            </p>
          </div>
          <div class="flex justify-center my-4 md:absolute md:bottom-0 md:left-1/2 md:-translate-x-1/2">
            <div
              v-loading="loading"
              :class="item.cur === 0 || item.isReceive || item.started ? 'bg-838' : 'bg-FFD'"
              class="w-40 leading-7 md:leading-8 rounded-full text-sm text-center cursor-pointer"
              @click="item.total ? receiveAward(item) : $store.commit('setSoon', true)"
            >
              {{ $t("adv.adv2") }}
            </div>
          </div>
        </div>
      </div>

      <div class="py-4 px-4 bg-464 md:bg-transparent mt-4" id="intro">
        <h2 class="text-center text-sm md:text-2xl">{{ $t("adv.adv6") }}</h2>
        <p class="text-xs md:text-base py-2 md:py-4 pl-5 md:pl-0 w-9/10">
          {{ $t("adv.adv7") }}
        </p>
        <div class="flex justify-start text-xs md:text-base w-full mb-2 md:mb-4">
          <div class="w-4 md:w-5 h-4 md:h-5 md:leading-5 mr-2 rounded-full bg-FFE text-black text-center text-xs md:text-base md:mt-0.5">1</div>
          <div class="w-9/10">{{ $t("adv.adv8") }}</div>
        </div>
        <div class="flex justify-start text-xs md:text-base w-full mb-2 md:mb-4">
          <div class="w-4 md:w-5 h-4 md:h-5 md:leading-5 mr-2 rounded-full bg-FFE text-black text-center text-xs md:text-base md:mt-0.5">2</div>
          <div class="w-9/10">{{ $t("adv.adv9") }}</div>
        </div>
        <div class="flex justify-start text-xs md:text-base w-full mb-2 md:mb-4">
          <div class="w-4 md:w-5 h-4 md:h-5 md:leading-5 mr-2 rounded-full bg-FFE text-black text-center text-xs md:text-base md:mt-0.5">3</div>
          <div class="w-9/10">{{ $t("adv.adv10") }}</div>
        </div>
        <div class="flex justify-start text-xs md:text-base w-full mb-2 md:mb-4">
          <div class="w-4 md:w-5 h-4 md:h-5 md:leading-5 mr-2 rounded-full bg-FFE text-black text-center text-xs md:mt-0.5 md:text-base">4</div>
          <div class="w-9/10">{{ $t("adv.adv11") }}</div>
        </div>
      </div>
      <div class="fixed inset-0 z-50 bg-black bg-opacity-70" v-show="flag">
        <div class="mt-10 w-9/10 rounded-xl bg-6C7 m-auto relative pb-10">
          <a class="px-2 py-2 text-gray absolute left-1 font-bold text-xl">x</a>
          <h2 class="text-black pt-10 text-center">{{ $t("adv.adv12") }}xxx</h2>
          <div class="flex justify-center mt-6">
            <div class="w-40 leading-7 rounded-full text-sm text-center cursor-pointer bg-F02">
              {{ $t("adv.adv13") }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer />
  </div>
</template>

<script>
    import Footer from '@/components/footer.vue'
	  import Header from '@/components/header.vue'
    import { getEther } from '@/plugins/ethers'
    import { dateFormatUTC } from '@/plugins/formatTime.js'
    export default {
        name: 'advert',
        components: { Header, Footer },
        data() {
            return {
              flag:false,
              videoProList:[],
              loading: false,
              isReceiveSoul: false
            }
        },
        methods: {
          async cliamSoul(){
            let invitor = window.sessionStorage.getItem('invitor')
            if(!invitor){
              this.$message.error('Not available')
              return
            }
            try{
              let res = await this.eth.c.knight.setTeamsFrom(invitor)
              await res.wait()
              this.$message.success("Success")
            }catch(e){
              this.$message.error(e.data.message)
            }
          },
          async receiveAward (item) {
            let invitor = window.sessionStorage.getItem('invitor')
            if (parseInt(item.time) === parseInt(new Date().getTime() / 1000 / 86400) && item.cur === 0) {
              this.$message.error(this.$t('msg.msg12'))
              return
            }
            let balanceOf = await this.eth.c.soul.balanceOf(this.eth.myAddr)
           
            if (balanceOf.eq(0)) {
              this.$message.error(this.$t('msg.msg14'))
              return
            }
            let time = await this.eth.c.knight.userReceiveDate(item.project_id, this.eth.myAddr)
            if (parseInt(time) === parseInt(new Date().getTime() / 1000 / 86400)) {
              this.$message.error(this.$t('msg.msg13'))
              return
            }
            
            // let info = await this.eth.c.knight.productMap(item.project_id)
            if (item.started) {
              this.$message.error(this.$t('msg.msg17'))
              return
            }
            this.loading = true
            try {
              let res = await this.eth.c.knight.receiveProduct(invitor ? invitor : this.eth.constants.AddressZero, item.project_id)
              await res.wait()
              this.initData()
              this.$message.success("Success")
              this.loading = false
            } catch (error) {
              this.loading = false
            }
          },
          
          async initData () {
            let res = await this.$axios.get('/api/soul/project_list?page=1&page_num=12')
            if (res.status === 200 && res.data.resultCode === 0) {
              this.videoProList = res.data.data.rows
            }
            this.videoProList.length && this.videoProList.forEach(async item => {
              let info = await this.eth.c.knight.productMap(item.project_id)
              item.total = parseInt(info.fixedAmount)
              item.cur = parseInt(info.day) === parseInt(new Date().getTime() / 1000 / 86400) ? parseInt(info.surplusAmount) : item.total = parseInt(info.fixedAmount)
              item.time = parseInt(info.day)
              item.startTime = parseInt(info.startTime)
              item.started = (parseInt(info.startTime) > parseInt(new Date().getTime() / 1000) || parseInt(new Date().getTime() / 1000) > parseInt(info.endTime)) || (new Date().getTime() / 1000) % 86400 < info.startTime % 86400
              let time = await this.eth.c.knight.userReceiveDate(item.project_id, this.eth.myAddr)
              if (parseInt(time) === parseInt(new Date().getTime() / 1000 / 86400)) {
                item.isReceive = true
              }
            })
          },
          async doCopy (copyVal) {
            this.$copyText(copyVal).then((e) => {
                this.$message.success("Copied")
            }, function (e) {
                this.$message.error("Can not copy")
            })
          },
          countdown (startTime) {
            let down = parseInt(startTime % 86400 - (new Date().getTime() / 1000) % 86400)
            return dateFormatUTC(down, 'hh') + 'h ' +  dateFormatUTC(down, 'mm') + 'm ' +  dateFormatUTC(down, 'ss') + 's' 
          }
        },
        async created() {
            this.eth = await getEther();
            if (this.eth) {
              let userReceiveSoul = await this.eth.c.knight.userReceiveSoul(this.eth.myAddr)
              this.isReceiveSoul = userReceiveSoul
              this.initData()
            }
        },
    }
</script>
<style lang="scss" scoped>
.advert {
  background: #000;
}
.banner {
  background-image: linear-gradient(to right, #f26b39, #e84b43);
}
</style>

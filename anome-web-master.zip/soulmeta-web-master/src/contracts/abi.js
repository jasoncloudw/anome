import soulAbi from '@/contracts/soul_abi.json'
import casteAbi from '@/contracts/caste_abi.json'
import usdtAbi from '@/contracts/usdt_abi.json'
import erc721Abi from './erc721_abi.json'
import pondAbi from './pond_abi.json'
import soul1155Abi from './soul1155_abi.json'
import soul721Abi from './soul721_abi.json'
import teamAbi from './team_abi.json'
import releaseAbi from './release_abi.json'
import releaseRabbitAbi from './release_rabbit_abi.json'
import knightAbi from './knight_abi.json'
import bonusAbi from './bonus_abi.json'
import storeAbi from './store_abi.json'
import controllerAbi from './controller_abi.json'
import propCoreAbi from './prop_core_abi.json'
import prop1155Abi from './prop1155_abi.json'
import soulMinter721Abi from './soul_minter721_abi.json'
import soul3dnftAbi from './soul3dnft.json'
import timeBankNftAbi from './time_bank_nft.json'
import timeBankAbi from './time_bank.json'
import timeBankRateAbi from './time_bank_rate.json'
import socialWelfareAbi from './social_welfare.json'
import guessFistAbi from './guess_fist_abi.json'
import gametotalAbi from './gameTotal_abi.json'
import fishpondnftAbi from "./fishpondnft_abi.json";
import routerAbi from './router_abi.json'
import dividendAbi from './dividend_abi.json'
import chaebolnftAbi from './chaebolnft.json'
import offlineTeamAbi from './offline_team_abi.json'
import onlineTeamAbi from './online_team_abi.json'
import businessTeamAbi from './business_team_abi.json'
import privateTeamAbi from './private_team_abi.json'
import soultokenAbi from './soultoken_abi.json'
import randomAbi from './random_abi.json'
import worldcupAbi from './worldcup_abi.json'
import worldcupViewerAbi from './worldcupViewer_abi.json'
import soulReceiveAbi from './soul_receive.json'
import s2dNftAbi from './s2dNft_abi.json'
import s2dNftSaleAbi from './s2dNftSale_abi.json'
import kakaAbi from './kaka_abi.json'
import stiAbi from './sti_abi.json'
import iziAbi from './izi_abi.json'
import fistAbi from './fist_abi.json'
import gmtAbi from './gmt_abi.json'
export const abi = {
    soulAbi,
    casteAbi,
    usdtAbi,
    erc721Abi,
    pondAbi,
    soul1155Abi,
    soul721Abi,
    teamAbi,
    releaseAbi,
    releaseRabbitAbi,
    knightAbi,
    bonusAbi,
    storeAbi,
    controllerAbi,
    propCoreAbi,
    prop1155Abi,
    soulMinter721Abi,
    timeBankNftAbi,
    timeBankAbi,
    timeBankRateAbi,
    socialWelfareAbi,
    guessFistAbi,
    gametotalAbi,
    soul3dnftAbi,
    fishpondnftAbi,
    routerAbi,
    dividendAbi,
    chaebolnftAbi,
    offlineTeamAbi,
    onlineTeamAbi,
    businessTeamAbi,
    privateTeamAbi,
    soulReceiveAbi,
    s2dNftAbi,
    s2dNftSaleAbi,
    kakaAbi,
    stiAbi,
    iziAbi,
    fistAbi,
    gmtAbi,
    soultokenAbi,
    randomAbi,
    worldcupAbi,
    worldcupViewerAbi,
    soulReceiveAbi
}

export const prodAddrs = {
    soul: '0x9c2DcEB3fEBEC3b7245a0c2395aFdd92d9364862',
    soul1155: '0xf66d732FfAB25Ba63d652d7E30a914715B1f828E',
    soul721: '0x7ce1B5a9D0fc3EDA401Ff91439b78C743B8d4820',
    usdt: '0x55d398326f99059fF775485246999027B3197955',
    caste: '0xe7F2480E4CaFD9291a72bF4562Da876Abd9a4C28',
    rabbit: '0x068E775B5F09B6d047E235694f15f9e3E9445A56',
    fishNft721: '0x718199dcea4056907f7766f4215e5a72bc2925f1',
    rba721: '0x58F0683FC41B47e40c8B1E6FAD8f9da5c534F3e6',
    pond: '0x706Ab641486397156E036C0b684d804fed7A446D',
    medal: '0x1fB9faCcF5Cb6878D1b9a201ab8AA296418487B5',
    team: '0xD5549E08F3dBb74b8C8449ae0D20d834030178C4',
    release: '0xE848341abcdDCa8B2a7821B718d0fE8529AEEC5E',
    releaseRabbit: '0xFBF4226BAB743fA8168589Ec251D6440f91a30F5',
    knight: '0xBD388d295C5945eF58Abd25fF659DB1603cACF51',
    bonus: '0x8FA7A1017c2918680173c64239F4c896Fe59F701',
    lp: '0x18d503A9bc476dB7fBe0BC067aF4DB2cA71C2D1b',
    pancakeLp: '0x18d503A9bc476dB7fBe0BC067aF4DB2cA71C2D1b',
    store: '0x52d1aD18A878Cd4060c6a55340afbf191b4ee082',
    controller: '0x4aB4391678B02757B367801a2D746bcE49efDf80',
    propCore: '0x2C36E49e7a688abf05AA301167747009437cF48A',
    prop1155: '0x8d454fb28f46c850eD5ecc7B48D36B6D8058fB30',
    soulMinter721: '0xBe1399934bE5EfEd588778895d92b56841986040', // 3dnft
    soul3dnft: '0xBe1399934bE5EfEd588778895d92b56841986040',
    timeBankNft: '0x4D31a0BE0600D32D79879B62A18F5554123ec6B3',
    timeBank: '0x37702f43d507dc5B4A617d5A58e35c8a259DB81A',
    timeBankRate: '0x7Afb41B4F5860ecdA5B4a6bda8E33017213f4129',
    sm3d: '0xBe1399934bE5EfEd588778895d92b56841986040',
    socialWelfare: '0xF12eFE15b49217205E4439Eb5d53ffA927C1AcfB',
    guessFist: '0x27A7752979a946bef7A5234466200D47cD2Ad3c1',
    gameTotal:'0x251966180bF699579C5B3AaD91BA7d7CD62fb378', //游戏中心总数
    fishpondnft:'0x1377289e8C3Eca02D822EaCc38Dfc80A491Ce2F1',
    router: '0xB658e4e577A4f1AA228045F316497282C068eB6F',
    dividend:'0x9893a08BbFB92BBF05506dcDB7378fDB81206fbb',
    chaebolnft:'0xCb537FecEde73E8405c26d5Eeb13AE20EcAa6273',
    offlineTeam:'0x3F5B536e50858B01427b2B91830CfB9F6dcb9283',
    onlineTeam:'0x98b607293281859EDbB2ba7b1Bb932fF16d3eAb7',
    businessTeam:'0xeE174e4Cb9A9F7A3c79074DDDAb941Ca1aE20164',
    privateTeam:'0xba27001912e3F5aaFDB3FE9D12F1809462Ce5C30',
    soulReceive: '0x1e4a0Fa39080d0cB3D00703ff1e8CF9ccE5286Eb',
    s2dNft:'0x6F30471e4fD65Df3e2494b6B5bf7629B4C4C020b',
    s2dNftSale:'0x9Cc14CC09495701ffa44FE4541276bbb9aB7EaA8',
    kaka: '0x26a1BdFa3bb86b2744c4A42EBfDd205761d13a8a',
    sti: '0x4f5f7a7Dca8BA0A7983381D23dFc5eaF4be9C79a',
    izi: '0x60D01EC2D5E98Ac51C8B4cF84DfCCE98D527c747',
    fist: '0xc9882def23bc42d53895b8361d0b1edc7570bc6a',
    gmt:'0x3019bf2a2ef8040c242c9a4c5c4bd4c81678b2a1',
    soulToken: '0x9c2DcEB3fEBEC3b7245a0c2395aFdd92d9364862',
    random: '0xdAf97d6a6b3083E9a34700D7bE2966BF5769f5F8',
    worldCup: '0x11d75fB928Abe7cC288f448dca3982F35fC49d25',
    worldcupViewer: '0x96B280E665380385e37cB4D82EF867966409A5E1',
}

export const testAddrs = {
    soul: '0x448cb22f0174F316718BD9f82Cc88766bB06F7D4',
    soul1155: '0xD83710eE8902C2d59A951B3652480C1973e7e135',
    soul721: '0x87dF92816585A9e267F62eb028AB4A3B5cD1DD0B',
    usdt: '0x58efC89C4946AF64cdbF13A9BdCc2e6868315A53',
    caste: '0x8Bfb7FbcD7f189f35dE962fdCc79187251787397',
    rabbit: '0x2077Ce999305c4D140A0A0355B67aFc46E076F3f',
    fishNft721: '0x88dbcc9c7992fefeee94a82d51ea39e1165f8268',
    rba721: '0x40bd7ac24e5adef3c4444e6347dd3efd23b2533f',
    pond: '0x48E734FCE7cF2fA9055f88c7829C10b272523075',
    medal: '0x98b3D9902467E9388c96A1FBf6889eb7B9be35a7',
    team: '0x0E846a4ccb895D4A8d078F0Faf50dd4b5abD67a8',
    release: '0xE848341abcdDCa8B2a7821B718d0fE8529AEEC5E',
    releaseRabbit: '0xFBF4226BAB743fA8168589Ec251D6440f91a30F5',
    knight: '0x4C7c2b0f283c71e045AEBEa6F1c84491058C1aFa',
    bonus: '0x68892a5d91d5c3eceF74baCF98E64828B08109F0',
    lp: '0x8bd2c6860dCDAd7d187732A155De2aCc8e71F2B9',
    pancakeLp: '0x133547A644a94846771b094B6973077A7206C9AF',
    store: '0x0D9C0066E7591a3584ACDC837538684C49EAa142',
    controller: '0x66ba18034acA4EEBa0aB6166c19aBfB692Ba10C9',
    propCore: '0x58C6701AB45E4AD39e38Cc4fC87fd22B224E2b71',
    prop1155: '0xED058AE752026c30B55E6E8B0952F92A547bF6FF',
    soulMinter721: '0x9e621799337cb265d7737be160aa916be9c21c9c',
    soul3dnft: '0x9e621799337cb265d7737be160aa916be9c21c9c',
    timeBankNft: '0x34A85e3dE915CE3438971842844f133F2a699E1C',
    timeBank: '0xd136268477817Cb5BeeEF9AF7e2a09A28f6964C4',
    timeBankRate: '0x8D9115b76B04acF7627795B1433E0Ff04771C3D6',
    sm3d: '0x780c7ce934d8fb2454ba616ba0db6e4216a9ecbe',
    socialWelfare: '0xF6250d85f184ECbB117993f67C4c70a79F394c9c',
    guessFist: '0x8F832b79616dE67c3d0eeC75c97fB2d8F02A8324',
    gameTotal:'0x241836129a5A260e396e078e6e7bbF1773B2f7F4', //游戏中心总数
    fishpondnft:'0x88dbcc9c7992fefeee94a82d51ea39e1165f8268',
    router: '0x62fC544C734D6717550fD0aF5904b2D95f9658FC',
    dividend:'0x1EbE91F525563F0e566bC83f50D7078f8fac25A8',
    chaebolnft:'0xa5384AA09FBe1e1ad06EfB88110bcCF00105bf28',
    offlineTeam:'0xec09fb4494827Ab0b23aFA51cA47c0eBD757a279',
    onlineTeam:'0xe48BBEdFAfff80af50BAC94dF58Ed507b4c32a20',
    businessTeam:'0xC831a6424004C168cF796A172b9314d94e171A3F',
    privateTeam:'0x0d397f2b72cCb28EBf75cC92f4ccbB137f6fA97B',
    soulReceive:'0xCfdab59c7c5f5BdD433c3e0370dDE9c34628439d',
    s2dNft:'0x1D75aa31044C6998e5de8F0bd8CA3518D7107B6B',
    s2dNftSale:'0xAAB55cEc2578d869979ca27386AD6F1B3C39F32d',
    kaka: '0xC529341E0A13e6D539bCcC41D814eB24a50f35C5',
    sti: '0x03127eaEe421D72b066Cb7aA84363FbF407938F3',
    izi: '0x17fEF46b0D7e16a9a4d572a96aEcebfA5edB6Bce',
    fist: '0xa8F99e50ecfb04F02D4929078276aB5aFfBE0d9A',
    gmt:'0x97eBff4861b236Dc54e0935e5bc766C527dfF4B0',
    soulToken: '0xBd6a6E8b2fE724B8327348A518d4933fbc9bC01a',
    random: '0x20Ecd7a57ffee1ec98D0a05A508A152037D7f4F0',
    worldCup: '0x3FdC5fE50df8F1f1817aB800bDAc1A8662E14c4D',
    worldcupViewer: '0x58dA64771f4579a02DE79E7F2d4D0706685BD4C0',
}
